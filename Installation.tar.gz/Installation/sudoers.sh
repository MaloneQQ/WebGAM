#!/bin/bash

#Adds the apache user to the sudoers file but can only stop start or restart services.
#/etc/sudoers.d/services creates a seperate file so if it gets messed up sudo can still be used.
sudo sh -c "echo \"www-data ALL = NOPASSWD: /etc/init.d/apache2\" >> /etc/sudoers.d/services"
sudo sh -c "echo \"%www-data ALL = NOPASSWD: /etc/init.d/apache2\" >> /etc/sudoers.d/services"

#Adds the apache user to the sudoers file so it can edit the network settings
sudo sh -c "echo \"www-data ALL = NOPASSWD: /etc/network/interfaces\" >> /etc/sudoers.d/network"
sudo sh -c "echo \"%www-data ALL = NOPASSWD: /etc/network/interfaces\" >> /etc/sudoers.d/network"
sudo sh -c "echo \"www-data ALL = NOPASSWD: /bin/sed\" >> /etc/sudoers.d/network"
sudo sh -c "echo \"%www-data ALL = NOPASSWD: /bin/sed\" >> /etc/sudoers.d/network"
sudo sh -c "echo \"www-data ALL = NOPASSWD: /sbin/ifdown\" >> /etc/sudoers.d/network"
sudo sh -c "echo \"%www-data ALL = NOPASSWD: /sbin/ifdown\" >> /etc/sudoers.d/network"
sudo sh -c "echo \"www-data ALL = NOPASSWD: /sbin/ifup\" >> /etc/sudoers.d/network"
sudo sh -c "echo \"%www-data ALL = NOPASSWD: /sbin/ifup\" >> /etc/sudoers.d/network"
