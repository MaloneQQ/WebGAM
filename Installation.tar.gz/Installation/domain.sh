#!/bin/bash

GAMCALL="python /opt/GAM/gam.py"
MVFROM="/var/www/html/WebGam/bash/System"
MVTO="/var/www/html/WebGam/data_files/csv"

#Runs the gam command to get the Organizational Units info and then saves it as a csv into the folder that the script is located in
$GAMCALL info domain> $MVTO/domain.csv
###############################Change Permissions###########################
		chmod -R 500 $WebGamDir
		chmod -R 700 $WebGamDir/bash
		chmod +x $WebGamDir/bash/Users/*.sh
		chmod +x $WebGamDir/bash/Groups/*.sh
		chmod +x $WebGamDir/bash/OU/*.sh
		chmod +x $WebGamDir/bash/System/*.sh
		chmod -R 700 $WebGamDir/data_files
		chown -R www-data:www-data $WebGamDir
		chmod -R 766 $GAMDirectory
		chmod +x $GAMDirectory/*.py
		chown -R www-data:www-data $GAMDirectory
