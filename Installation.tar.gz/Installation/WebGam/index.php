<!DOCTYPE html>

<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="refresh" content="0; url=./controller/controller.php?main" />
    </head>
    <body></body>
</html>