//<script type="text/javascript">
function SwapDivsWithClick(div1,div2)
{
   d1 = document.getElementById(div1);
   d2 = document.getElementById(div2);
   if( d2.style.display == "none" )
   {
      d1.style.display = "none";
      d2.style.display = "block";
   }
   else
   {
      d1.style.display = "block";
      d2.style.display = "none";
   }
}

function swap(srcId,dstId)
{
    src = document.getElementById(srcId);
    dst = document.getElementById(dstId);

    index = src.selectedIndex;

    if(index != -1)
    {
        txt = src.options[ index ].text;
        value = src.options[ index ].value;

        dst.options[ dst.options.length] = new Option( txt, value );
        src.options[ index ] = null;
    }
}	

function selectAll(id)
{
    s = document.getElementById(id);

    for(i = 0; i < s.length; ++i)
    {
        s[i].selected = true;
    }
}
//</script>

