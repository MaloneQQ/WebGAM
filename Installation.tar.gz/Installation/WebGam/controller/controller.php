<?php

    session_start();

    require_once('../security/model.php');
    require_once '../model/model.php';
    require_once '../lib/formating.php';
    require_once '../lib/general_functions.php';

    if (isset($_POST['action'])) {  // check get and post
        $action = $_POST['action'];
    } else if (isset($_GET['action'])) {
        $action = $_GET['action'];
    } else {
        include "../view/home/main.php";  // default action
        exit();
    }
    
    if (!userIsAuthorized($action)) {
        if(!loggedIn()) {
            header("Location:../security/index.php?action=SecurityLogin&RequestedPage=" . urlencode($_SERVER['REQUEST_URI']));
        } else {
            include('../security/not_authorized.html');
        }
    } else {
        switch ($action) {
        //home
            case 'main':
                include "../view/home/$action.php";
                break;
        //users
            case 'users':
                include "../view/users/$action.php";
                break;
            case 'add_user':
                setAddUser();
                break;
            case 'process_add_user':
                processAddUser();
                break;
            case 'update_edit_user_form':
                if (isset($_GET['username'])) { setEditUser($_GET['username']); } //coming form users page
                else { $username = $_POST['UserName']; header("location: ../controller/controller.php?action=update_edit_user_form&username=$username"); } //changing user in edit user page
                break;
            case 'edit_user':
                setEditUser("none");
                break;
            case 'process_edit_user':
                processEditUser();
                break;
            case 'remove_user':
                setRemoveUser();
                break;
            case 'process_remove_user':
                processRemoveUser();
                break;
            case 'view_user':
                if (isset($_GET['username'])) { viewUser($_GET['username']); } //coming from users page
                else if (isset($_POST['SelectUserName'])) { $username = $_POST['SelectUserName']; header("location: ../controller/controller.php?action=view_user&username=$username"); } //changing user in view user page
                else { viewUser("none"); }
                break;
        //groups
            case 'groups':
                include "../view/groups/$action.php";
                break;
            case 'add_group':
                addGroup();
                break;
            case 'process_add_group':
                processAddEditGroup();
                break;
            case 'update_edit_group_form':
                if (isset($_GET['groupname'])) { editGroup($_GET['groupname']); } //coming from groups page
                else { $groupname = $_POST['GroupName']; header("location: ../controller/controller.php?action=update_edit_group_form&groupname=$groupname"); } //changing group in edit group page
                break;
            case 'edit_group':
                editGroup("none");
                break;
            case 'process_edit_group':
                processAddEditGroup();
                break;
            case 'remove_group':
                removeGroup();
                break;
            case 'process_remove_group':
                processRemoveGroup();
                break;
            case 'view_group':
                if (isset($_GET['groupname'])) { viewGroup($_GET['groupname']); } //comming from groups page
                else if (isset($_POST['SelectGroupName'])) { $groupname = $_POST['SelectGroupName'];  header("location: ../controller/controller.php?action=view_group&groupname=$groupname"); } //changing group in view group page
                else { viewGroup("none"); }
                break;
        //ous
            case 'ous':
                include "../view/ous/$action.php";
                break;
            case 'add_ou':
                addOU();
                break;
            case 'process_add_ou':
                processAddEditOU();
                break;
            case 'update_edit_ou_form':
                if (isset($_GET['ouname'])) { editOU($_GET['ouname']); } //coming from ous page
                else { $ouname = $_POST['OUName']; header("location: ../controller/controller.php?action=update_edit_ou_form&ouname=$ouname"); } //changing ou in edit ou page
                break;
            case 'edit_ou':
                editOU("none");
                break;
            case 'process_edit_ou':
                processAddEditOU();
                break;
            case 'remove_ou':
                removeOU();
                break;
            case 'process_remove_ou':
                processRemoveOU();
                break;
            case 'view_ou':       
                if (isset($_GET['ouname'])) { viewOU($_GET['ouname']); } //comming from ous page
                else if (isset($_POST['SelectOUName'])) { $ouname = $_POST['SelectOUName']; header("location: ../controller/controller.php?action=view_ou&ouname=$ouname"); } //changing ou in view ou page
                else { viewOU("none"); }
                break;
        //contacts
            case 'contacts':
                include "../view/contacts/$action.php";
                break;
        //system
            case 'system':
                include "../view/system/$action.php";
                break;    
            case 'networking':
                include "../view/system/$action.php";
                break;
            case 'systems':
                $restarting = false;
                include "../view/system/$action.php";
                break;
            case 'restart_server':
                restartServer();
                break;
            case 'restart_apache':
                restartApache();
                break;
            case 'process_networking':
                processNetworking();
                break;
        }
    }
  
//
// Users
//
    
    function setAddUser(){
        $mode="add";

        $username = "";
        $firstname = "";
        $lastname = "";
        $password = "";
        $verifypassword = "";
        $suspended = "";
        $changepassword = "";
        $adduserglobal = "";
        $admin = "";
        $company = "";
        $usertitle = "";
        $department = "";
        $streetaddress = "";
        $zip = "";
        $country = "";
        $addressLimit = maxAddresses(); //limits the number of addresses that can be added
        $phonetype = "";
        $phone = "";
        $phoneLimit = maxPhones(); //limits the number of phones that can be added
        $alias = "";
        $aliasLimit = maxAliases(); //limits the number of aliases that can be added
        $manager = "";
        $oldmanager = "";
        $domain = getDomain(); //get the server domain
        $aliasdomain = $domain;
        
        include "../view/users/add_edit_user.php";
    }
    
    //this could also be for process edit user
    //check mode for differences
    function processAddUser(){
        
        $mode = $_POST['Mode'];
        $username = $_POST['UserName'];
        $firstname = $_POST['FirstName'];
        $lastname = $_POST['LastName'];
        $password = $_POST['Password'];
        $verifypassword = $_POST['VerifyPassword'];
        $suspended = $_POST['Suspended'];
        $changepassword = $_POST['ChangePassword'];
        $adduserglobal = $_POST['AddUserGlobal'];
        $admin = $_POST['SetAdmin'];
        $ou = $_POST['OU'];
        $company = $_POST['Organization'];
        $organizationtype = $_POST['OrganizationType'];
        $usertitle = $_POST['UserTitle'];
        $department = $_POST['Department'];
        $addresstype = $_POST['AddressType'];
        $streetaddress = $_POST['StreetAddress'];
        $zip = $_POST['Zip'];
        $country = $_POST['Country'];
        $primaryaddress = $_POST['PrimaryAddress']; //returns the number address that is primary (default is 0)
        $addresscount = $_POST['AddressCount']; //number of extra addresses
        $phonetype = $_POST['PhoneType'];
        $phone = $_POST['Phone'];
        $primaryphone = $_POST['PrimaryPhone']; //returns the number phone that is primary (default is 0)
        $phonecount = $_POST['PhoneCount']; //number of extra phones
        $alias = $_POST['Alias'];
        $aliasdomain = $_POST['AliasDomain'];
        $aliascount = $_POST['AliasCount']; //number of extra aliases
        $manager = $_POST['Manager'];
        $imageinfo = $_FILES['UserImage'];
        
        $username = removeDoublePeriods($username);
        $alias = removeDoublePeriods($alias);
        
        $additionalAddresses = array();
        for ($i = 0; $i < $addresscount; $i++){
            $type = 'AddressType'.($i+1);
            $street = 'StreetAddress'.($i+1);
            $zipcode = 'Zip'.($i+1);
            $countrycode = 'Country'.($i+1);
            $additionalAddresses[$i] = array($_POST[$type], $_POST[$street], $_POST[$zipcode], $_POST[$countrycode]);
        }
        
        $additionalPhones = array();
        for ($i = 0; $i < $phonecount; $i++){
            $type = 'PhoneType'.($i+1);
            $number = 'Phone'.($i+1);
            $additionalPhones[$i] = array($_POST[$type], $_POST[$number]);
        }
        
        $additionalAliases = array();
        for ($i = 0; $i < $aliascount; $i++){
            $aliasemail = 'Alias'.($i+1);
            $aliasemaildomain = 'AliasDomain'.($i+1);
            $tempalias = removeDoublePeriods($_POST[$aliasemail]);
            $additionalAliases[$i] = array($tempalias, $_POST[$aliasemaildomain]);
        }
        
        //validation
        $errors = "";
        $errors .= checkLength($username, 1, 128, "\\n *Username is required and must not be longer than 128 characters in length.");
        //check that username isn't already in use
        $rows = getUsers();
        for ($i = 0; $i < count($rows); $i++){
            if ($username == $rows[$i]) { $errors .= "\\n *Username $username has already been taken."; }
        }
        //check for consecutive periods in a username
        //also check if the user needs an alias because of use of '.' in username
        $needsalias = False;
        $strlen = strlen( $username );
        for( $i = 0; $i <= $strlen; $i++ ) { 
            $char = substr( $username, $i, 1 );
            if ($char == '.') { $needsalias = True; } //the user will need an alias
            if ($i != 0){ //check for consecutive periods
                $lastchar = substr( $username, $i-1, 1 );
                if ($char == '.' && $lastchar == '.') {
                    $errors .= "\\n *You cannot have two consecutive periods in a username.";
                }
            }
        }
        if ($firstname != ""){
            $errors .= checkLength($firstname, 1, 60, "\\n *First name must not be longer than 60 characters in length.");
        }
        if ($lastname != ""){
            $errors .= checkLength($lastname, 1, 60, "\\n *Last name must not be longer than 60 characters in length.");
        }
        if ($password != ""){
            $errors .= checkLength($password, 8, 100, "\\n *Password is required and must be between 8 and 100 characters in length.");
        }
        if ($verifypassword != ""){
            $errors .= checkLength($verifypassword, 8, 100, "\\n *Password verification is required and must be between 8 and 100 characters in length.");
        }
        if ($password != $verifypassword){
            $errors .= "\\n *You must verify the password by entering the same password in both the password and verify password fields.";
        }
        if ($needsalias == True && $alias == ""){
            $errors .= "\\n *You must provide an email alias. If you add periods to the username an email alias is required.";
        }
        
        //image has been uploaded, now check its vlidity
        $validimage = false;
        if ($imageinfo['name'] != ""){
            $upload_err = processFormImageUpload($imageinfo, 250, $username);
            if ($upload_err == '') { $validimage = true; }
            $errors .= $upload_err;
        }
        
        if ($errors != ""){ //errors
            include "../view/users/add_edit_user.php"; 
        }else{ //good to go
            //create script
            //-username
            //-suspend
            //-ch pass
            //-glob acc list
            //-admin
            //-manager
            //if edit mode call update script and not create script
            $user_command = './create.sh -u "'.$username.'"';
            if ($suspended == "on") {
                $user_command .= ' -s "'.$suspended.'"';
            }
            if ($changepassword == "on") {
                $user_command .= ' -c "'.$changepassword.'"';
            }
            $user_command .= ' -g "'.$adduserglobal.'"';
            if ($admin == "on") {
                $user_command .= ' -a "'.$admin.'"';
            }
            if ($manager != "none") {
                $user_command .= ' -t manager -m "'.$manager.'"';
            }
            //create user GAM command
            $directory = gamPath().'bash/Users/';
            $command = $user_command;
            if (!debugMode()) { callGam($directory, $command); }
            
            //name script
            //-username
            //-first name
            //-last name
            $name_command = "";
            if ($firstname != "" || $lastname != ""){
                $name_command = './name.sh -u "'.$username.'"';
                if ($firstname != "") {
                    $name_command .= ' -f "'.$firstname.'"';
                }
                if ($lastname != "") {
                    $name_command .= ' -l "'.$lastname.'"';
                }
                
                //name GAM command
                $directory = gamPath().'bash/Users/';
                $command = $name_command;
                if (!debugMode()) { callGam($directory, $command); }
            }
            
            
            //password script
            //-username
            //-password
            $password_command = "";
            if ($password != "") {
                $password_command = './password.sh -u "'.$username.'"';
                $password_command .= ' -p "'.$password.'"';
                
                //password GAM command
                $directory = gamPath().'bash/Users/';
                $command = $password_command;
                if (!debugMode()) { callGam($directory, $command); }
            }
            
            //ous script in ous folder
            //-username
            //-ou
            $ou_command = "";
            if ($ou != "none"){
                $ou_command = './addToOU.sh -u "'.$username.'"';
                $ou_command .= ' -o "'.$ou.'"';
                
                //ou GAM command
                $directory = gamPath().'bash/Users/';
                $command = $ou_command;
                if (!debugMode()) { callGam($directory, $command); }
            }
            
            //organization script
            //-username
            //-organization
            //-title
            //-department
            //-primary
            $organization_command = "";
            if ($company != "" || $usertitle != "" || $department != ""){
                $organization_command .= './org.sh -u "'.$username.'"';
                if ($company != "") {
                    $organization_command .= ' -o "'.$company.'"';
                    $organization_command .= ' -y "'.$organizationtype.'"';
                }
                if ($usertitle != "") {
                    $organization_command .= ' -t "'.$usertitle.'"';
                }
                if ($department != "") {
                    $organization_command .= ' -d "'.$department.'"';
                }
                $organization_command .= ' -p "primary"';
                
                //organization GAM command
                $directory = gamPath().'bash/Users/';
                $command = $organization_command;
                if (!debugMode()) { callGam($directory, $command); }
            }
            
            //address script
            //-username
            //-street
            //-zip
            //-country
            //-primary
            $address_command = "";
            $allAddressCommands = array();
            if ($streetaddress != "" || $zip != ""){
                $address_command .= './address.sh -u "'.$username.'"';
                $address_command .= ' -t "'.$addresstype.'"';
                if ($streetaddress != ""){ $address_command .= ' -s "'.$streetaddress.'"'; }
                if ($zip != ""){ $address_command .= ' -o "'.$zip.'"'; }
                $address_command .= ' -c "'.$country.'"';
                if ($primaryaddress == 0) { $address_command .= ' -n "primary"'; }
                else { $address_command .= ' -n "notprimary"'; }
                
                //address GAM command
                $directory = gamPath().'bash/Users/';
                $command = $address_command;
                if (!debugMode()) { callGam($directory, $command); }
                
                $allAddressCommands[0] = $address_command;
                
                //do extra addresses if they exist
                if ($addresscount > 0){
                    for ($i = 0; $i < $addresscount; $i++){
                        if ($additionalAddresses[$i][1] != "" || $additionalAddresses[$i][2] != ""){
                            $address_command = "";
                            $address_command .= './address.sh -u "'.$username.'"';
                            $address_command .= ' -t "'.$additionalAddresses[$i][0].'"';
                            if ($additionalAddresses[$i][1] != ""){ $address_command .= ' -s "'.$additionalAddresses[$i][1].'"'; }
                            if ($additionalAddresses[$i][2] != ""){ $address_command .= ' -o "'.$additionalAddresses[$i][2].'"'; }
                            $address_command .= ' -c "'.$additionalAddresses[$i][3].'"';
                            if ($primaryaddress == ($i+1)){ $address_command .= ' -n "primary"'; }
                            else { $address_command .= ' -n "notprimary"'; }

                            //address GAM command
                            $directory = gamPath().'bash/Users/';
                            $command = $address_command;
                            $allAddressCommands[$i+1] = $command;
                            if (!debugMode()) { callGam($directory, $command); }
                        }
                    }
                }
            } 
            
            //phone script
            //-username
            //-phone type
            //-phone number
            //-primary
            $phone_command = "";
            $allPhoneCommands = array();
            if ($phone != "") {
                $phone_command .= './phone.sh -u "'.$username.'"';
		$phone_command .= ' -t "'.$phonetype.'"';
                $phone_command .= ' -n "'.$phone.'"';
                if ($primaryphone == 0){ $phone_command .= ' -p "primary"'; }
                else { $phone_command .= ' -p "notprimary"'; }
                
                //phone GAM command
                $directory = gamPath().'bash/Users/';
                $command = $phone_command;
                if (!debugMode()) { callGam($directory, $command); }
                
                $allPhoneCommands[0] = $phone_command;
                
                //do extra phones if they exist
                if ($phonecount > 0){
                    for ($i = 0; $i < $phonecount; $i++){
                        if ($additionalPhones[$i][1] != ""){
                            $phone_command = "";
                            $phone_command .= './phone.sh -u "'.$username.'"';
                            $phone_command .= ' -t "'.$additionalPhones[$i][0].'"';
                            $phone_command .= ' -n "'.$additionalPhones[$i][1].'"';
                            if ($primaryphone == ($i+1)){ $phone_command .= ' -p "primary"'; }
                            else { $phone_command .= ' -p "notprimary"'; }

                            //phone GAM command
                            $directory = gamPath().'bash/Users/';
                            $command = $phone_command;
                            $allPhoneCommands[$i+1] = $command;
                            if (!debugMode()) { callGam($directory, $command); }
                        }
                    }
                }
            }
            
            //alias script
            //-username
            //-alias@aliasdomain
            $alias_command = "";
            $allAliasCommands = array();
            if ($alias != ""){
                $alias_command .= './alias.sh -u "'.$username.'"';
                $alias_command .= ' -a "'.$alias.'@'.$aliasdomain.'"';
                
                //alias GAM command
                $directory = gamPath().'bash/Users/';
                $command = $alias_command;
                if (!debugMode()) { callGam($directory, $command); }
                
                $allAliasCommands[0] = $alias_command;
                
                if ($aliascount > 0){
                    for ($i = 0; $i < $aliascount; $i++){
                        if ($additionalAliases[$i][0] != ""){
                            $alias_command = "";
                            $alias_command .= './alias.sh -u "'.$username.'"';
                            $alias_command .= ' -a "'.$additionalAliases[$i][0].'@'.$additionalAliases[$i][1].'"';
                            
                            //alias GAM command
                            $directory = gamPath().'bash/Users/';
                            $command = $alias_command;
                            $allAliasCommands[$i+1] = $command;
                            if (!debugMode()) { callGam($directory, $command); }
                        }
                    }
                }
                
            }
            
            //picture command
            $picture_command = "";
            if ($validimage) { 
                $picture_command = './picture.sh '.$username.' '.$imageinfo['name'];
                $directory = gamPath().'bash/Users/';
                $command = $picture_command;
                if (!debugMode()) { callGam($directory, $command); }
            }
            
	    //update user CSV file
            if (!debugMode()) { callGam('/var/www/html/WebGam/bash/Users/', './userCSV.sh'); }

            if (!debugMode()) { header("Location:../controller/controller.php?action=users"); }         

            //for testing
            //only shows up in debug mode
            if (debugMode()) { 
                echo $mode."<br />";
                echo $username."<br />";
                echo $firstname."<br />";
                echo $lastname."<br />";
                echo $password."<br />";
                echo $verifypassword."<br />";
                echo $suspended."<br />";
                echo $changepassword."<br />";
                echo $adduserglobal."<br />";
                echo $admin."<br />";
                echo $ou."<br />";
                echo $company."<br />";
                echo $organizationtype."<br />";
                echo $usertitle."<br />";
                echo $department."<br />";
                echo $manager."<br />";
                echo $addresstype."<br />";
                echo $streetaddress."<br />";
                echo $zip."<br />";
                echo $country."<br />";
                if ($primaryaddress == 0) { echo "primary address<br />"; }
                echo $addresscount."<br />";
                if ($addresscount > 0){
                    for ($i = 0; $i < $addresscount; $i++){
                        if ($additionalAddresses[$i][1] != "" || $additionalAddresses[$i][2] != ""){
                            echo $additionalAddresses[$i][0]."<br />";
                            echo $additionalAddresses[$i][1]."<br />";
                            echo $additionalAddresses[$i][2]."<br />";
                            echo $additionalAddresses[$i][3]."<br />";
                            if ($primaryaddress == ($i+1)){ echo "primary address<br />"; }
                        }
                    }
                }
                echo $phonetype."<br />";
                echo $phone."<br />";
                if ($primaryphone == 0) { echo "primary phone<br />"; }
                echo $phonecount."<br />";
                if ($phonecount > 0){
                    for ($i = 0; $i < $phonecount; $i++){
                        if ($additionalPhones[$i][1] != ""){
                            echo $additionalPhones[$i][0]."<br />";
                            echo $additionalPhones[$i][1]."<br />";
                            if ($primaryphone == ($i+1)){ echo "primary phone<br />"; }
                        }
                    }
                }
                echo $alias."@".$aliasdomain."<br />";
                if ($aliascount > 0){
                    for ($i = 0; $i < $aliascount; $i++){
                        if ($additionalAliases[$i][0] != ""){
                            echo $additionalAliases[$i][0]."@".$additionalAliases[$i][1]."<br />";
                        }
                    }
                }
                echo $imageinfo['name'] + "<br />";

                echo "<br /> ".$user_command;
                echo "<br /> ".$name_command;
                echo "<br /> ".$organization_command;
                echo "<br /> ".$password_command;
                echo "<br /> ".$ou_command;
                for ($i = 0; $i < sizeof($allAddressCommands); $i++){
                    echo "<br />".$allAddressCommands[$i];
                }
                for ($i = 0; $i < sizeof($allPhoneCommands); $i++){
                    echo "<br />".$allPhoneCommands[$i];
                }
                for ($i = 0; $i < sizeof($allAliasCommands); $i++){
                    echo "<br />".$allAliasCommands[$i];
                }
                echo "<br />".$picture_command;
            }
        }
          
    }
    
    //read the csv file and set the values
    //reading should be done in model, and return an array
    //if a user is already set, the array contains the infor for just that user
    //if not, the array will contain the infor for the first user
    //also need an array of user names (email is defining in this case I think)
    function setEditUser($user){
        $mode = 'edit';
        
        if ($user != "none") 
        {
            $username = $user; //need to set a seperate variable here for use in view page
            $rows = getUserInfo($username);
        }
        else //get the first user 
        { 
            //groupname is none in this case so get the first one by default
            $users = getUsers();
            $username = $users[1]; //index 1 because first row is column names
            $rows = getUserInfo($username);
        }
        
        //need these for the javascript function
        //lets it know the limit to how many extras can be added
        $addressLimit = maxAddresses();
        $phoneLimit = maxPhones();
        $aliasLimit = maxAliases();
        
        //report the static types
        $username = $rows[0][0];
        $firstname = $rows[0][1];
        $lastname = $rows[0][2];
        $suspended = $rows[0][3];
        $changepassword = $rows[0][4];
        $adduserglobal = $rows[0][5];
        $admin = $rows[0][6];
        $ou = $rows[0][7];
        $company = $rows[0][8];
        $usertitle = $rows[0][9];
        $department = $rows[0][10];
        $manager = ""; // conditional if [11] == manager then set to [12]
        $addresstype = $rows[0][13];
        $streetaddress = ""; //if formatted exists, then use that, otherwise use street
        $zip = $rows[0][16];
        $country = $rows[0][17]; //based on the country code, return the full country
        $primaryaddress = $rows[0][18];
        $phonetype = $rows[0][19];
        $phone = $rows[0][20];
        $primaryphone = $rows[0][21];
        $alias = $rows[0][22];
        $domain = getDomain(); //get the server domain
        $aliasdomain = $domain;
        //$userimage = SOMETHING!;
        
        //for storage of found extra data
        //need a new array for each to make life easier in webpage use
        $extrarelations = $rows[1];
        $relationscount = count($extrarelations); //get count of relations array
        $extraaddresses = $rows[2];
        $addresscount = $rows[3]; //get count of address array
        $extraphones = $rows[4];
        $phonecount = $rows[5]; //get count of phone array
        $extraaliases = $rows[6];
        $aliascount = count($extraaliases); //get count of alias array
        
        //conditional formatting
        if ($firstname == 'Unknown') { $firstname = ''; }
        if ($lastname == 'Unknown') { $lastname = ''; }
        if ($suspended == 'TRUE' || $suspended == 'True') { $suspended = 'True'; } else { $suspended = 'False'; }
        if ($changepassword == 'TRUE' || $changepassword == 'True') { $changepassword = 'True'; } else { $changepassword = 'False'; }
        if ($adduserglobal == 'TRUE' || $adduserglobal == 'True') { $adduserglobal = 'True'; } else { $adduserglobal = 'False'; }
        if ($admin == 'TRUE' || $admin == 'True') { $admin = 'True'; } else { $admin = 'False'; }
        $ou = substr($ou, 1); //if ($ou == '') { $ou = 'None'; }   
        if ($rows[0][11] == 'manager') {  $split = removeDomain($rows[0][12]); $manager = $split[0]; $relationscount = 0; } $oldmanager = $manager;
        $addresstype = ucfirst($addresstype); //capitalize the first letter
        if ( $rows[0][15] != '' ) { $streetaddress = $rows[0][15]; } else if ( $rows[0][14] != '') { $streetaddress = $rows[0][14]; }
        $country = strtoupper($country); if ($country == '') { $country = 'US'; } $country = getCountryName($country);
        if ($primaryaddress == 'TRUE' || $primaryaddress == 'True') { $primaryaddress = 'True'; } else { $primaryaddress = 'False'; }
        if ($phonetype == '') { $phonetype = 'Mobile'; } $phonetype = ucfirst($phonetype); //capitalize the first letter
        //$phone = formatPhoneNumber($phone);
        if ($primaryphone == 'TRUE' || $primaryphone == 'True') { $primaryphone = 'True'; } else { $primaryphone = 'False'; }
        $split = removeDomain($rows[0][22]); $alias = $split[0]; $aliasdomain = $split[1];
        
        //conditional formatting for extras arrays
        for ($i = 1; $i <= $relationscount; $i++) {
            if ($extrarelations[$i][0] == 'manager') {  $split = removeDomain($extrarelations[$i][1]); $manager = $split[0]; break; }
        }
        for ($i = 1; $i <= $addresscount; $i++) {
            if ($extraaddresses[$i][0] == '') { $extraaddresses[$i][0] = 'other'; } $extraaddresses[$i][0] = ucfirst($extraaddresses[$i][0]); //capitalize the first letter
            if ($extraaddresses[$i][4] == '') { $extraaddresses[$i][4] = 'US'; } $extraaddresses[$i][4] = getCountryName($extraaddresses[$i][4]);
            if ($extraaddresses[$i][5] == 'TRUE' || $extraaddresses[$i][5] == 'True') { $extraaddresses[$i][5] = 'True'; } else { $extraaddresses[$i][5] = 'False'; }
        }
        for ($i = 1; $i <= $phonecount; $i++) {
            if ($extraphones[$i][0] == '') { $extraphones[$i][0] = 'Mobile'; } $extraphones[$i][0] = ucfirst($extraphones[$i][0]); //capitalize the first letter
            //$extraphones[$i][1] = formatPhoneNumber($extraphones[$i][1]);
            if ($extraphones[$i][2] == 'TRUE' || $extraphones[$i][2] == 'True') { $extraphones[$i][2] = 'True'; } else { $extraphones[$i][2] = 'False'; }
        }
        for ($i = 1; $i <= $aliascount; $i++) {
            $split = removeDomain($extraaliases[$i][0]); 
            $extraaliases[$i][0] = $split[0]; 
            $extraaliases[$i][1] = $split[1];
        }
        
        include "../view/users/add_edit_user.php";
    }
    
    function processEditUser(){

        $mode = $_POST['Mode'];
        $username = $_POST['UserName'];
        $firstname = $_POST['FirstName'];
        $lastname = $_POST['LastName'];
        $suspended = $_POST['Suspended'];
        $changepassword = $_POST['ChangePassword'];
        $adduserglobal = $_POST['AddUserGlobal'];
        $admin = $_POST['SetAdmin'];
        $ou = $_POST['OU'];
        $company = $_POST['Organization'];
        $organizationtype = $_POST['OrganizationType'];
        $usertitle = $_POST['UserTitle'];
        $department = $_POST['Department'];
        $addresstype = $_POST['AddressType'];
        $streetaddress = $_POST['StreetAddress'];
        $zip = $_POST['Zip'];
        $country = $_POST['Country'];
        $primaryaddress = $_POST['PrimaryAddress']; //returns the number address that is primary (default is 0)
        $addresscount = $_POST['AddressCount']; //number of extra addresses
        $phonetype = $_POST['PhoneType'];
        $phone = $_POST['Phone'];
        $primaryphone = $_POST['PrimaryPhone']; //returns the number phone that is primary (default is 0)
        $phonecount = $_POST['PhoneCount']; //number of extra phones
        $alias = $_POST['Alias'];
        $aliasdomain = $_POST['AliasDomain'];
        $aliascount = $_POST['AliasCount']; //number of extra aliases
        $manager = $_POST['Manager'];
        $oldmanager = $_POST['OldManager'];
        $imageinfo = $_FILES['UserImage'];
        
        $username = removeDoublePeriods($username);
        $alias = removeDoublePeriods($alias);
        $oldalias = '';
        if (isset($_POST['OldAlias'])) { $oldalias = $_POST['OldAlias']; }
        
        $additionalAddresses = array();
        $j = 0;
        for ($i = 0; $i < $addresscount; $i++){
            $type = 'AddressType'.($i+1);
            $street = 'StreetAddress'.($i+1);
            $zipcode = 'Zip'.($i+1);
            $countrycode = 'Country'.($i+1);
            
            if (isset($_POST[$type]) && isset($_POST[$street]) && isset($_POST[$zipcode]) && isset($_POST[$countrycode])) {
                $additionalAddresses[$j] = array($_POST[$type], $_POST[$street], $_POST[$zipcode], $_POST[$countrycode]);
                $j++;
            }
        }
        $addresscount = $j;
        
        $additionalPhones = array();
        $j = 0;
        for ($i = 0; $i < $phonecount; $i++){
            $type = 'PhoneType'.($i+1);
            $number = 'Phone'.($i+1);
            
            if (isset($_POST[$type]) && isset($_POST[$number])) {
                $additionalPhones[$j] = array($_POST[$type], $_POST[$number]);
                $j++;
            }
        }
        $phonecount = $j;
        
        $additionalAliases = array();
        $oldAliases = array();
        $j = 0;
        for ($i = 0; $i < $aliascount; $i++){
            $aliasemail = 'Alias'.($i+1);
            $aliasemaildomain = 'AliasDomain'.($i+1);
            
            if (isset($_POST[$aliasemail])) {
                $tempalias = removeDoublePeriods($_POST[$aliasemail]);
                $additionalAliases[$j] = array($tempalias, $_POST[$aliasemaildomain]);
                
                //need in order to delete old alias to create new alias (this is how replacing an alias has to be done)
                $oldAliases[$i] = '';
                $oldAliasEmail = 'OldAlias'.($i+1);
                if (isset($_POST[$oldAliasEmail])) { $oldAliases[$j] = $_POST[$oldAliasEmail]; }
                
                $j++;
            }
        }
        $aliascount = $j;
        
        $errors = "";
        if ($firstname != ""){
            $errors .= checkLength($firstname, 1, 60, "\\n *First name must not be longer than 60 characters in length.");
        }
        if ($lastname != ""){
            $errors .= checkLength($lastname, 1, 60, "\\n *Last name must not be longer than 60 characters in length.");
        }
        
        //image has been uploaded, now check its vlidity
        $validimage = false;
        if ($imageinfo['name'] != ""){
            $upload_err = processFormImageUpload($imageinfo, 250, $username);
            if ($upload_err == '') { $validimage = true; }
            $errors .= $upload_err;
        }
        
        if ($errors != ""){ //errors
            include "../view/users/add_edit_user.php"; 
        }else{ //good to go
            //create script
            //-username
            //-suspend
            //-ch pass
            //-glob acc list
            //-admin
            //-manager
            //if edit mode call update script and not create script
            $user_command = './update.sh -u "'.$username.'"';
            $user_command .= ' -s "'.$suspended.'"';
            $user_command .= ' -c "'.$changepassword.'"';
            $user_command .= ' -g "'.$adduserglobal.'"';
            $user_command .= ' -a "'.$admin.'"';
            if ($manager != "none") {
                $user_command .= ' -t "manager" -m "'.$manager.'"';
            } else {
                if ($oldmanager != ""){
                    $user_command .= ' -t "none" -m "'.$oldmanager.'"';  
                }
            }
            //create user GAM command
            $directory = gamPath().'bash/Users/';
            $command = $user_command;
            if (!debugMode()) { callGam($directory, $command); }
            
            //name script
            //-username
            //-first name
            //-last name
            $name_command = "";
            if ($firstname != "" || $lastname != ""){
                $name_command = './name.sh -u "'.$username.'"';
                if ($firstname != "") {
                    $name_command .= ' -f "'.$firstname.'"';
                }
                if ($lastname != "") {
                    $name_command .= ' -l "'.$lastname.'"';
                }
                
                //name GAM command
                $directory = gamPath().'bash/Users/';
                $command = $name_command;
                if (!debugMode()) { callGam($directory, $command); }
            }
            
            //ous script in ous folder
            //-username
            //-ou
            $ou_command = "";
            if ($ou != "none"){
                $ou_command = './addToOU.sh -u "'.$username.'"';
                $ou_command .= ' -o "'.$ou.'"';
                
                //ou GAM command
                $directory = gamPath().'bash/Users/';
                $command = $ou_command;
                if (!debugMode()) { callGam($directory, $command); }
            }
            
            //organization script
            //-username
            //-organization
            //-title
            //-department
            //-primary
            $organization_command = "";
//            $allOrganizationCommands = array();
            if ($company != "" || $usertitle != "" || $department != ""){
                $organization_command .= './org.sh -u "'.$username.'"';
                if ($company != "") {
                    $organization_command .= ' -o "'.$company.'"';
                    $organization_command .= ' -y "'.$organizationtype.'"';
                }
                if ($usertitle != "") {
                    $organization_command .= ' -t "'.$usertitle.'"';
                }
                if ($department != "") {
                    $organization_command .= ' -d "'.$department.'"';
                }
                $organization_command .= ' -p "primary"';
                
                //organization GAM command
                $directory = gamPath().'bash/Users/';
                $command = $organization_command;
                if (!debugMode()) { callGam($directory, $command); }
            }
            
            //address script
            //-username
            //-street
            //-zip
            //-country
            //-primary
            $address_command = "";
            $allAddressCommands = array();
            if ($streetaddress != "" || $zip != ""){
                $address_command .= './address.sh -u "'.$username.'"';
                $address_command .= ' -t "'.$addresstype.'"';
                if ($streetaddress != ""){ $address_command .= ' -s "'.$streetaddress.'"'; }
                if ($zip != ""){ $address_command .= ' -o "'.$zip.'"'; }
                $address_command .= ' -c "'.$country.'"';
                if ($primaryaddress == 0) { $address_command .= ' -n "primary"'; }
                else { $address_command .= ' -n "notprimary"'; }
                
                //address GAM command
                $directory = gamPath().'bash/Users/';
                $command = $address_command;
                if (!debugMode()) { callGam($directory, $command); }
                
                $allAddressCommands[0] = $address_command;
                
                //do extra addresses if they exist
                if ($addresscount > 0){
                    for ($i = 0; $i < $addresscount; $i++){
                        if ($additionalAddresses[$i][1] != "" || $additionalAddresses[$i][2] != ""){
                            $address_command = "";
                            $address_command .= './address.sh -u "'.$username.'"';
                            $address_command .= ' -t "'.$additionalAddresses[$i][0].'"';
                            if ($additionalAddresses[$i][1] != ""){ $address_command .= ' -s "'.$additionalAddresses[$i][1].'"'; }
                            if ($additionalAddresses[$i][2] != ""){ $address_command .= ' -o "'.$additionalAddresses[$i][2].'"'; }
                            $address_command .= ' -c "'.$additionalAddresses[$i][3].'"';
                            if ($primaryaddress == ($i+1)){ $address_command .= ' -n "primary"'; }
                            else { $address_command .= ' -n "notprimary"'; }

                            //address GAM command
                            $directory = gamPath().'bash/Users/';
                            $command = $address_command;
                            $allAddressCommands[$i+1] = $command;
                            if (!debugMode()) { callGam($directory, $command); }
                        }
                    }
                }
            } 
            
            //phone script
            //-username
            //-phone type
            //-phone number
            //-primary
            $phone_command = "";
            $allPhoneCommands = array();
            if ($phone != "") {
                $phone_command .= './phone.sh -u "'.$username.'"';
		$phone_command .= ' -t "'.$phonetype.'"';
                $phone_command .= ' -n "'.$phone.'"';
                if ($primaryphone == 0){ $phone_command .= ' -p "primary"'; }
                else { $phone_command .= ' -p "notprimary"'; }
                
                //phone GAM command
                $directory = gamPath().'bash/Users/';
                $command = $phone_command;
                if (!debugMode()) { callGam($directory, $command); }
                
                $allPhoneCommands[0] = $phone_command;
                
                //do extra phones if they exist
                if ($phonecount > 0){
                    for ($i = 0; $i < $phonecount; $i++){
                        if ($additionalPhones[$i][1] != ""){
                            $phone_command = "";
                            $phone_command .= './phone.sh -u "'.$username.'"';
                            $phone_command .= ' -t "'.$additionalPhones[$i][0].'"';
                            $phone_command .= ' -n "'.$additionalPhones[$i][1].'"';
                            if ($primaryphone == ($i+1)){ $phone_command .= ' -p "primary"'; }
                            else { $phone_command .= ' -p "notprimary"'; }

                            //phone GAM command
                            $directory = gamPath().'bash/Users/';
                            $command = $phone_command;
                            $allPhoneCommands[$i+1] = $command;
                            if (!debugMode()) { callGam($directory, $command); }
                        }
                    }
                }
            }
            
            //alias script
            //-username
            //-alias@aliasdomain
            $alias_command = "";
            $allAliasCommands = array();
            if ($alias != ""){
                $alias_command .= './alias.sh -u "'.$username.'"';
                $alias_command .= ' -a "'.$alias.'@'.$aliasdomain.'"';
                
                if ($oldalias != '' && $oldalias != $alias){
                    $directory = gamPath().'bash/Users/';
                    $command = "./removeAlias.sh -a $oldalias";
                    if (!debugMode()) { callGam($directory, $command); }
                    else { echo "<br />".$directory." ".$command."<br />"; }
                }
                
                //alias GAM command
                $directory = gamPath().'bash/Users/';
                $command = $alias_command;
                if (!debugMode()) { callGam($directory, $command); }
                
                $allAliasCommands[0] = $alias_command;
                
                if ($aliascount > 0){
                    for ($i = 0; $i < $aliascount; $i++){
                        if ($additionalAliases[$i][0] != ""){
                            
                            if ($oldAliases[$i] != '' && $oldAliases[$i] != $additionalAliases[$i][0]){
                                $directory = gamPath().'bash/Users/';
                                $command = "./removeAlias.sh -a $oldAliases[$i]";
                                if (!debugMode()) { callGam($directory, $command); }
                                else { echo "<br />".$directory." ".$command."<br />"; }
                            }
                            
                            $alias_command = "";
                            $alias_command .= './alias.sh -u "'.$username.'"';
                            $alias_command .= ' -a "'.$additionalAliases[$i][0].'@'.$additionalAliases[$i][1].'"';
                            
                            //alias GAM command
                            $directory = gamPath().'bash/Users/';
                            $command = $alias_command;
                            $allAliasCommands[$i+1] = $command;
                            if (!debugMode()) { callGam($directory, $command); }
                        }
                    }
                }
                
            }
            
            //picture command
            $picture_command = "";
            if ($validimage) { 
                $picture_command = './picture.sh '.$username.' '.$imageinfo['name'];
                $directory = gamPath().'bash/Users/';
                $command = $picture_command;
                if (!debugMode()) { callGam($directory, $command); }
            }
            
	    //update user CSV file
            if (!debugMode()) { callGam('/var/www/html/WebGam/bash/Users/', './userCSV.sh'); }

            if (!debugMode()) { header("Location:../controller/controller.php?action=users"); }         

            //for testing
            //only shows up in debug mode
            if (debugMode()) { 
                echo $mode."<br />";
                echo $username."<br />";
                echo $firstname."<br />";
                echo $lastname."<br />";
                echo $suspended."<br />";
                echo $changepassword."<br />";
                echo $adduserglobal."<br />";
                echo $admin."<br />";
                echo $ou."<br />";
                echo $company."<br />";
                echo $organizationtype."<br />";
                echo $usertitle."<br />";
                echo $department."<br />";
                echo $manager."<br />";
                echo $oldmanager."<br />";
                echo $addresstype."<br />";
                echo $streetaddress."<br />";
                echo $zip."<br />";
                echo $country."<br />";
                if ($primaryaddress == 0) { echo "primary address<br />"; }
                echo $addresscount."<br />";
                if ($addresscount > 0){
                    for ($i = 0; $i < $addresscount; $i++){
                        if ($additionalAddresses[$i][1] != "" || $additionalAddresses[$i][2] != ""){
                            echo $additionalAddresses[$i][0]."<br />";
                            echo $additionalAddresses[$i][1]."<br />";
                            echo $additionalAddresses[$i][2]."<br />";
                            echo $additionalAddresses[$i][3]."<br />";
                            if ($primaryaddress == ($i+1)){ echo "primary address<br />"; }
                        }
                    }
                }
                echo $phonetype."<br />";
                echo $phone."<br />";
                if ($primaryphone == 0) { echo "primary phone<br />"; }
                echo $phonecount."<br />";
                if ($phonecount > 0){
                    for ($i = 0; $i < $phonecount; $i++){
                        if ($additionalPhones[$i][1] != ""){
                            echo $additionalPhones[$i][0]."<br />";
                            echo $additionalPhones[$i][1]."<br />";
                            if ($primaryphone == ($i+1)){ echo "primary phone<br />"; }
                        }
                    }
                }
                echo $alias."@".$aliasdomain."<br />";
                echo $oldalias."<br />";
                if ($aliascount > 0){
                    for ($i = 0; $i < $aliascount; $i++){
                        if ($additionalAliases[$i][0] != ""){
                            echo $additionalAliases[$i][0]."@".$additionalAliases[$i][1]."<br />";
                            echo $oldAliases[$i]."<br />";
                        }
                    }
                }
                echo $imageinfo['name'] + "<br />";

                echo "<br /> ".$user_command;
                echo "<br /> ".$name_command;
                echo "<br /> ".$organization_command;
                echo "<br /> ".$ou_command;
                for ($i = 0; $i < sizeof($allAddressCommands); $i++){
                    echo "<br />".$allAddressCommands[$i];
                }
                for ($i = 0; $i < sizeof($allPhoneCommands); $i++){
                    echo "<br />".$allPhoneCommands[$i];
                }
                for ($i = 0; $i < sizeof($allAliasCommands); $i++){
                    echo "<br />".$allAliasCommands[$i];
                }
                echo "<br />".$picture_command;
            }
        }
    }
    
    function setRemoveUser(){
        include "../view/users/remove_user.php";
    }
    
    //remove any selected users from the remove user form
    function processRemoveUser(){
        
        $usercount = $_POST['UserCount'];
        
        //validation
        $errors = "";
        $removeSelected = False;
        
        //check to see if a user has actually been selected to remove
        for ($i = 1; $i <= $usercount; $i++){
            $postvalue = 'User'.$i;
            if ($_POST[$postvalue] != "keep") { $removeSelected = True; }
        } 
        
        if ($removeSelected == False) {
            $errors .= "\\n* You have not selected a user to remove.";
            include "../view/users/remove_user.php"; 
        } else { //good to go
            $users_to_delete = "";
            for ($i = 1; $i <= $usercount; $i++){
                $postvalue = 'User'.$i;
                if ($_POST[$postvalue] != "keep") {
                    $users_to_delete .= ' '.'"'.$_POST[$postvalue].'"';
                } 
            }
            
            //remove user GAM command
            $directory = gamPath().'bash/Users/';
            $command = './delete.sh'.$users_to_delete;
            if (!debugMode()) { callGam($directory, $command); }
            
            if (debugMode()) { echo $command."<br />"; }
            
            if (!debugMode()) { header("Location:../controller/controller.php?action=users"); }  
        }
        
    }
    
    function viewUser($user){
        if ($user != "none") 
        {
            $username = $user; //need to set a seperate variable here for use in view page
            $rows = getUserInfo($username);
        }
        else //get the first user 
        { 
            //groupname is none in this case so get the first one by default
            $users = getUsers();
            $username = $users[1]; //index 1 because first row is column names
            $rows = getUserInfo($username);
        }
        
        //report the static types
        $username = $rows[0][0];
        $firstname = $rows[0][1];
        $lastname = $rows[0][2];
        $suspended = $rows[0][3];
        $changepassword = $rows[0][4];
        $adduserglobal = $rows[0][5];
        $admin = $rows[0][6];
        $ou = $rows[0][7];
        $company = $rows[0][8];
        $usertitle = $rows[0][9];
        $department = $rows[0][10];
        $manager = ""; // conditional if [11] == manager then set to [12]
        $addresstype = $rows[0][13];
        $streetaddress = ""; //if formatted exists, then use that, otherwise use street
        $zip = $rows[0][16];
        $country = $rows[0][17]; //based on the country code, return the full country
        $primaryaddress = $rows[0][18];
        $phonetype = $rows[0][19];
        $phone = $rows[0][20];
        $primaryphone = $rows[0][21];
        $alias = $rows[0][22];
        //$userimage = SOMETHING!;
        
        //for storage of found extra data
        //need a new array for each to make life easier in webpage use
        $extrarelations = $rows[1];
        $relationscount = count($extrarelations); //get count of relations array
        $extraaddresses = $rows[2];
        $addresscount = $rows[3]; //get count of address array
        $extraphones = $rows[4];
        $phonecount = $rows[5]; //get count of phone array
        $extraaliases = $rows[6];
        $aliascount = count($extraaliases); //get count of alias array
        
        //conditional formatting
        if ($suspended == 'TRUE' || $suspended == 'True') { $suspended = 'True'; } else { $suspended = 'False'; }
        if ($changepassword == 'TRUE' || $changepassword == 'True') { $changepassword = 'True'; } else { $changepassword = 'False'; }
        if ($adduserglobal == 'TRUE' || $adduserglobal == 'True') { $adduserglobal = 'True'; } else { $adduserglobal = 'False'; }
        if ($admin == 'TRUE' || $admin == 'True') { $admin = 'True'; } else { $admin = 'False'; }
        //$ou = substr($ou, 1); //if ($ou == '') { $ou = 'None'; }   
        if ($rows[0][11] == 'manager') {  $split = removeDomain($rows[0][12]); $manager = $split[0]; $relationscount = 0; }
        $addresstype = ucfirst($addresstype); //capitalize the first letter
        if ( $rows[0][15] != '' ) { $streetaddress = $rows[0][15]; } else if ( $rows[0][14] != '') { $streetaddress = $rows[0][14]; }
        $country = strtoupper($country); $country = getCountryName($country);
        if ($primaryaddress == 'TRUE' || $primaryaddress == 'True') { $primaryaddress = 'True'; } else { $primaryaddress = 'False'; }
        $phonetype = ucfirst($phonetype); //capitalize the first letter
        $phone = formatPhoneNumber($phone);
        if ($primaryphone == 'TRUE' || $primaryphone == 'True') { $primaryphone = 'True'; } else { $primaryphone = 'False'; }
        $split = removeDomain($rows[0][22]); $alias = $split[0]; $aliasdomain = $split[1];
        
        //conditional formatting for extras arrays
        for ($i = 1; $i <= $relationscount; $i++) {
            if ($extrarelations[$i][0] == 'manager') {  $split = removeDomain($extrarelations[$i][1]); $manager = $split[0]; break; }
        }
        for ($i = 1; $i <= $addresscount; $i++) {
            $extraaddresses[$i][0] = ucfirst($extraaddresses[$i][0]); //capitalize the first letter
            $extraaddresses[$i][4] = getCountryName($extraaddresses[$i][4]);
            if ($extraaddresses[$i][5] == 'TRUE' || $extraaddresses[$i][5] == 'True') { $extraaddresses[$i][5] = 'True'; } else { $extraaddresses[$i][5] = 'False'; }
        }
        for ($i = 1; $i <= $phonecount; $i++) {
            $extraphones[$i][0] = ucfirst($extraphones[$i][0]); //capitalize the first letter
            $extraphones[$i][1] = formatPhoneNumber($extraphones[$i][1]);
            if ($extraphones[$i][2] == 'TRUE' || $extraphones[$i][2] == 'True') { $extraphones[$i][2] = 'True'; } else { $extraphones[$i][2] = 'False'; }
        }
        for ($i = 1; $i <= $aliascount; $i++) {
            $split = removeDomain($extraaliases[$i][0]); 
            $extraaliases[$i][0] = $split[0]; 
            $extraaliases[$i][1] = $split[1];
        }
        
        include "../view/users/view_user.php";
    }
      
//
// Groups
//
    
    function addGroup(){
        $mode = "add";
        
        $groupname = "";
        $groupemail = "";
        $groupdescription = "";
        $groupalias = "";
        $domain = getDomain();
        
        include "../view/groups/add_edit_group.php";
    }
    
    function processAddEditGroup(){
        $mode = $_POST['Mode'];
        //if (debugMode()) { print_r($_POST); }
        $groupname = $_POST['GroupName'];
        //$groupemail = $_POST['GroupEmail'];
        $groupdescription = $_POST['GroupDescription'];
        $groupalias = $_POST['GroupAlias'];
        $oldalias = '';
        if (isset($_POST['OldAlias'])) { $oldalias = $_POST['OldAlias']; }
        $groupaliasdomain = $_POST['GroupAliasDomain'];
        
        if ($groupname == ''){
            $groups = getGroups();
            $groupname = $groups[1];
        }
        
        $groupname = removeDoublePeriods($groupname);
        $groupemail = $groupname."@".getDomain();
        $groupalias = removeDoublePeriods($groupalias);
        
        $errors = "";
        
        //check if group name already in use
        if ($mode == 'add') {
            $rows = getGroups();
            for ($i = 0; $i < count($rows); $i++){
                $split = removeDomain($rows[$i]);
                if ($groupname == $split[0]) { $errors .= "\\n *Group name $groupname is already in use."; }
            }
        }

        if ($errors != ""){ //errors
            include "../view/groups/add_edit_group.php"; 
        } else { //good to go
            $membersadded = false;
            $membersremoved = false;
            if (isset($_POST['InGroup'])){
                $membersadded = true;
                $groupmembers = $_POST['InGroup'];
            }
            if (isset($_POST['NotInGroup'])){
                $membersremoved = true;
                $removedmembers = $_POST['NotInGroup'];
            }

            if ($oldalias != '' && $oldalias != $groupalias){
                $directory = gamPath().'bash/Groups/';
                $command = "./removeAlias.sh -a $oldalias";
                if (!debugMode()) { callGam($directory, $command); }
                else { echo "<br />".$directory." ".$command."<br />"; }
            }
  
            if ($mode == 'add') { $group_command = './create.sh -e "'.$groupemail.'" -n "'.$groupname.'"'; }
            else { $group_command = './update.sh -e "'.$groupemail.'" -n "'.$groupname.'"'; }
            if ($groupdescription != ""){
                $group_command .= ' -d "'.$groupdescription.'"';
            }
            if ($groupalias != ""){
                $group_command .= ' -a "'.$groupalias.'@'.$groupaliasdomain.'"';
            }

            //add group GAM command
            $directory = gamPath().'bash/Groups/';
            $command = $group_command;
            if (!debugMode()) { callGam($directory, $command); }

            //remove any members that need removed
            $directory = gamPath().'bash/Groups/';
            if ($membersremoved) {
                for ($i = 0; $i < count($removedmembers); $i++){
                    $command = './removeUsers.sh -g '.$groupemail.' -u '.$removedmembers[$i];
                    if (!debugMode()) { callGam($directory, $command); }
                    else { echo $directory.' '.$command.'<br />'; }
                }
            }
            //add members to the group
            $directory = gamPath().'bash/Users/';
            if ($membersadded) {
                for ($i = 0; $i < count($groupmembers); $i++) {
                    $command = './addToGroup.sh -g '.$groupemail.' -t member -u '.$groupmembers[$i];
                    if (!debugMode()) { callGam($directory, $command); }
                    else { echo $directory.' '.$command.'<br />'; }
                }
            }

            if (!debugMode()) { header("Location:../controller/controller.php?action=groups"); }

            //for testing
            //only shows up in bebug mode
            if (debugMode()) { 
                echo $groupname."<br />";
                echo $groupemail."<br />";
                echo $groupdescription."<br />";
                echo $groupalias."<br />";
                echo $groupaliasdomain."<br />";

                if ($membersadded) {
                    echo "Group Members: <br />";
                    for ($i = 0; $i < count($groupmembers); $i++){
                        echo $i.": ".$groupmembers[$i]."<br />";
                    }
                    echo "<br />";
                } else {
                    echo "No members added to the group<br />";
                }

                echo "<br />".$directory."<br />";
                echo $group_command."<br />";
            }
        }
    }
    
    function editGroup($group){
        $mode = "edit";
        
        if ($group != "none") 
        {
            $groupname = $group;
            $rows = getGroupInfo($groupname);
        }
        else //get the first group 
        { 
            //groupname is none in this case so get the first one by default
            $groups = getGroups();
            $groupname = $groups[1]; //index 1 because first row is column names
            $rows = getGroupInfo($groupname);
        }
        
        $groupname = $rows[0];
        $groupemail = $rows[1];
        $groupdescription = $rows[2];
        $groupalias = $rows[3];
        $groupaliasdomain = getDomain();
        $domain = getDomain();

        $split = removeDomain($groupalias);
        $groupalias = $split[0];
        $groupaliasdomain = $split[1];
        
        include "../view/groups/add_edit_group.php";
    }
    
    function removeGroup(){
        include "../view/groups/remove_group.php";
    }
    
    function processRemoveGroup(){
        $groupcount = $_POST['GroupCount'];
        
        //validation
        $errors = "";
        $removeSelected = False;
        
        //check to see if a group has actually been selected to remove
        for ($i = 1; $i <= $groupcount; $i++){
            $postvalue = 'Group'.$i;
            if ($_POST[$postvalue] != "keep") { $removeSelected = True; }
        } 
        
        if ($removeSelected == False) {
            $errors .= "\\n* You have not selected a group to remove.";
            include "../view/groups/remove_group.php"; 
        } else { //good to go
            $groups_to_delete = "";
            $groupnames = getGroups();
            $groupemails = getGroupEmails();
            for ($i = 1; $i <= $groupcount; $i++){
                $postvalue = 'Group'.$i;
                if ($_POST[$postvalue] != "keep") {
                    for ($j = 0; $j < count($groupnames); $j++){
                        if ($_POST[$postvalue] == $groupnames[$j]){
                            $groups_to_delete .= ' '.'"'.$groupemails[$j].'"';
                        }
                    } 
                } 
            }
            
            //remove user GAM command
            $directory = gamPath().'bash/Groups/';
            $command = './delete.sh'.$groups_to_delete;
            if (!debugMode()) { callGam($directory, $command); }
            
            if (debugMode()) { echo $command."<br />"; }
            
            if (!debugMode()) { header("Location:../controller/controller.php?action=groups"); }  
        }
    }
    
    function viewGroup($group){  
        if ($group != "none") 
        {
            $groupname = $group;
            $rows = getGroupInfo($groupname);
        }
        else //get the first group 
        { 
            //groupname is none in this case so get the first one by default
            $groups = getGroups();
            $groupname = $groups[1]; //index 1 because first row is column names
            $rows = getGroupInfo($groupname);
        }
        
        $groupname = $rows[0];
        $groupemail = $rows[1];
        $groupdescription = $rows[2];
        $groupalias = $rows[3];
        $split = removeDomain($groupalias);
        $groupalias = $split[0];
        $groupaliasdomain = $split[1];
        
        if ($groupdescription == "") { $groupdescription = ""; }
        if ($groupalias == "") { $groupalias = ""; }
        if ($groupaliasdomain == "") { $groupalias = ""; }
        
        include "../view/groups/view_group.php";
    }
    
//
// OUs
//
    
    function addOU(){
        $mode = "add";
        
        $ouname = "";
        $oudescription = "";
        $parentou = "";
	$oupath = "/";
        
        include "../view/ous/add_edit_ou.php";
    }
    
    function processAddEditOU(){
        $mode = $_POST['Mode'];
        //if (debugMode()) { print_r($_POST); echo '<br /><br />';}
        $ouname = $_POST['OUName'];
        $oudescription = $_POST['OUDescription'];
        $parentou = $_POST['ParentOU'];
	$oupath = $_POST['OUpath'];
        
        if ($ouname == ''){
            $ous = getOUs();
            $ouname = $ous[1];
            $oupaths = getOUpaths();
            $oupath = $oupaths[1];
        }
        
        $ouname = removeDoublePeriods($ouname);
        
        $errors = "";
        
        //check if ou name already in use
        if ($mode == 'add') {
            $rows = getOUs();
            for ($i = 0; $i < count($rows); $i++){
                if ($ouname == $rows[$i]) { $errors .= "\\n *OU name $ouname is already in use."; }
            }
        }

        if ($errors != ""){ //errors
            include "../view/ous/add_edit_ou.php"; 
        }else{ //good to go
            $membersadded = false;
            if (isset($_POST['InOU'])){
                $membersadded = true;
                $oumembers = $_POST['InOU'];
            }  
            $membersremoved = false;
            if (isset($_POST['NotInOU'])){
                $tempremovedmembers = $_POST['NotInOU'];
                $removedmembers = array();
                $tempoupath = substr($oupath, 1);
                $currentMembers = getOUmembers($tempoupath);
                $index = 0;
                for ($i = 0; $i < count($tempremovedmembers); $i++){
                    for ($j = 0; $j < count($currentMembers[0]); $j++){
                        if ($tempremovedmembers[$i] == $currentMembers[0][$j]) 
                        { 
                            $removedmembers[$index] = $tempremovedmembers[$i];
                            $index++;
                            $membersremoved = true;
                        }
                    }
                } 
            }

            if ($mode == 'add') { $ou_command = './create.sh -o "'.$ouname.'" -d "'.$oudescription.'"'; }
            else { $ou_command = './update.sh -o "'.$oupath.'" -d "'.$oudescription.'"'; }
            $ou_command .= ' -p "'.$parentou.'"';

            //add ou GAM command
            $directory = gamPath().'bash/OU/';
            $command = $ou_command;
            if (!debugMode()) { callGam($directory, $command); }

            //remove members from ou
            $directory = gamPath().'bash/Users/';
            if ($membersremoved) {
                for ($i = 0; $i < count($removedmembers); $i++) {
                    $command = './addToOU.sh -o / -u '.$removedmembers[$i];
                    if (!debugMode()) { callGam($directory, $command); }
                    else { echo $directory.' '.$command.'<br />'; }
                }
                if (debugMode()) { echo '<br />'; }
            }
            //add members to the ou
            $directory = gamPath().'bash/Users/';
            if ($membersadded) {
                for ($i = 0; $i < count($oumembers); $i++) {
                    if ($parentou != "/"){ $command = './addToOU.sh -o '.$parentou.'/'.$ouname.' -u '.$oumembers[$i]; }
                    else { $command = './addToOU.sh -o /'.$ouname.' -u '.$oumembers[$i]; }
                    if (!debugMode()) { callGam($directory, $command); }
                    else { echo $directory.' '.$command.'<br />'; }
                }
                if (debugMode()) { echo '<br />'; }
            }

            if (!debugMode()) { 
	        //GAM currently does not have a working parent OU feature
	        //report if parent OU does not change
	        $currentOU = getOUInfo($ouname);
                if ($currentOU[2] != $parentou){
                    header("Location:../controller/controller.php?action=ous&gam_error=true"); 
                } else {
		    header("Location:../controller/controller.php?action=ous"); 
		}
	    }

            //for testing
            //only shows up in debug mode
            if (debugMode()) { 
                echo $ouname."<br />";
                echo $oudescription."<br />";
                echo $parentou."<br />";

                if ($membersadded){
                    echo "OU Members: <br />";
                    for ($i = 0; $i < count($oumembers); $i++){
                        echo $i.": ".$oumembers[$i]."<br />";
                    }
                    echo "<br />";
                } else {
                    echo "No members added to the ou<br />";
                }

                echo "<br />".$directory."<br />";
                echo $ou_command."<br />";
            }
        }
    }
    
    function editOU($ou){
        $mode = "edit";
        
        if ($ou != "none") 
        {
            $ouname = $ou;
            $rows = getOUInfo($ouname);
        }
        else //get the first group 
        { 
            //groupname is none in this case so get the first one by default
            $ous = getOUs();
            $ouname = $ous[1]; //index 1 because first row is column names
            $rows = getOUInfo($ouname);
        }
        
        $ouname = $rows[0];
        $oudescription = $rows[1];
        $parentou = $rows[2];
	$oupath = $rows[3];
        if ($parentou == '/') { $parentou = ""; }
        
        include "../view/ous/add_edit_ou.php";
    }
    
    function removeOU(){
        include "../view/ous/remove_ou.php";
    }
    
    function processRemoveOU(){
        $oucount = $_POST['OUCount'];
        
        //validation
        $errors = "";
        $removeSelected = False;
        
        //check to see if an ou has actually been selected to remove
        for ($i = 1; $i <= $oucount; $i++){
            $postvalue = 'OU'.$i;
            if ($_POST[$postvalue] != "keep") { $removeSelected = True; }
        } 
        
        if ($removeSelected == False) {
            $errors .= "\\n* You have not selected an OU to remove.";
            include "../view/ous/remove_ou.php"; 
        } else { //good to go
            $ous_to_delete = "";
            $ounames = getOUs();
            $oupaths = getOUpaths();
            $ouparents = getOUparents();
            
            $deletedoupaths = array();
            
            $k = 0;
            for ($i = 1; $i <= $oucount; $i++){
                $postvalue = 'OU'.$i;
                if ($_POST[$postvalue] != "keep") {
                    for ($j = 0; $j < count($ounames); $j++){
                        if ($_POST[$postvalue] == $ounames[$j]){
                            $ous_to_delete .= ' '.$oupaths[$j];
                            $deletedoupaths[$k] = $oupaths[$j];
                            $k++;
                        }
                        if ($oupaths[$i] == $ouparents[$j]){
                            $errors .= "\\n* You cannot delete an OU that is a parent to another OU without deleting that child OU first.";
                            break;
                        }
                    }
                } 
            }
            
            //move all the users from the OU first
            $directory = gamPath().'bash/Users/';
            for ($j = 0; $j < count($deletedoupaths); $j++){
                $oupath = substr($deletedoupaths[$j], 1);
                $sets = getOUmembers($oupath); //get the ou members
                for ($i = 0; $i < count($sets[0]); $i++){
                    $command = "./addToOU.sh -o / -u ".$sets[0][$i];
                    if (!debugMode()) { callGam($directory, $command); }
                    else { echo $directory." ".$command."<br />"; }
                }
            }
            
            //remove user GAM command
            if ($errors != ''){
                include "../view/ous/remove_ou.php";
            } else {
                $directory = gamPath().'bash/OU/';
                $command = './delete.sh'.$ous_to_delete;
                if (!debugMode()) { callGam($directory, $command); }

                if (debugMode()) { echo $command."<br />"; }

                if (!debugMode()) { header("Location:../controller/controller.php?action=ous"); }
            }
        }
    }
    
    function viewOU($ou){
        
        if ($ou != "none") 
        {
            $ouname = $ou;
            $rows = getOUInfo($ouname);
        }
        else //get the first group 
        { 
            //groupname is none in this case so get the first one by default
            $ous = getOUs();
            $ouname = $ous[1]; //index 1 because first row is column names
            $rows = getOUInfo($ouname);
        }
        
        $ouname = $rows[0];
        $oudescription = $rows[1];
        $parentou = $rows[2];
	$oupath = $rows[3];         
        
        if ($parentou == "" || $parentou == '/') { $parentou = "none"; }
        
        include "../view/ous/view_ou.php";
    }
    
//
// Other
//
    
    //process any network settings
    function processNetworking(){
        $address = $_POST['Address'];
        $netmask = $_POST['Netmask'];
        $gateway = $_POST['Gateway'];
        $dns1 = $_POST['DNS1'];
        $dns2 = $_POST['DNS2'];
        $dns3 = $_POST['DNS3'];
        
        if ($address == "" && $netmask == "" && $gateway == "" && $dns1 == "" && $dns2 == "" && $dns3 == "") { //something must be set
            $errors = "\\n *You must set one of the options to submit the form.";
            include "../view/system/networking.php";
        }
        
        $network_command = "";
        $dns_command = "";
        
        if ($address != "") { $network_command .= " -a $address"; }
        if ($netmask != "") { $network_command .= " -n $netmask"; }
        if ($gateway != "") { $network_command .= " -g $gateway"; }
        
        if ($dns1 != "") { $dns_command .= " $dns1"; }
        if ($dns2 != "") { $dns_command .= " $dns2"; }
        if ($dns3 != "") { $dns_command .= " $dns3"; }
        
        //networking command
        if ($network_command != ""){ //make sure there is something to the command
            $directory = gamPath().'bash/System/';
            $command = './network.sh'.$network_command;
            if (!debugMode()) { callGam($directory, $command); }
            if (debugMode()) { echo $directory." ".$command."<br />"; }
        }
        
        //dns command
        if ($dns_command != ""){ //make sure there is something to the command
            $directory = gamPath().'bash/System/';
            $command = './nameserver.sh'.$dns_command;
            if (!debugMode()) { callGam($directory, $command); }
            if (debugMode()) { echo $directory." ".$command."<br />"; }
        }
        
        //restart the network
        if ($network_command != "" || $dns_command != ""){
            $directory = gamPath().'bash/System/';
            $command = './restartNetwork.sh';
            if (!debugMode()) { callGam($directory, $command); }
            if (debugMode()) { echo $directory." ".$command."<br />"; }
        }
        
        if (!debugMode()) { header("Location:../controller/controller.php?action=system"); }
    }
    
    //restart the server
    function restartServer(){
        $restarting = true;
        if (!debugMode()) { include "../view/system/systems.php"; }
        
        $directory = gamPath().'bash/System/';
        $command = './power.sh restart';
        if (!debugMode()) { callGam($directory, $command); }
        else { echo $directory." ".$command; }
    }
    
    //restart apache
    function restartApache(){
        $restarting = true;
        if (!debugMode()) { include "../view/system/systems.php"; }
        
        $directory = gamPath().'bash/System/';
        $command = './restartApache.sh';
        if (!debugMode()) { callGam($directory, $command); }
        else { echo $directory." ".$command; }
    }
    
    //upload an image and validate it
    function processFormImageUpload($image_info, $minsize, $username) {
        $upload_errors = ""; 
        $bad_upload = false;
        
        $maxsize = 1000; //image can't be larger than this or else upload will fail
        $allowed = array('gif','png','jpg','jpeg');
        $uploadfile = '../data_files/pictures/' . $username . '.png';
        $ext = pathinfo($uploadfile, PATHINFO_EXTENSION);
        if(!in_array($ext,$allowed)) {
            $upload_errors .= "\\n *There was an error uploading your file. You must upload a PNG, JPG, or GIF file.";
            $bad_upload = true;
        }
        
        //tmp_name is null when the image is too large, so make sure it isn't
        if ($image_info['tmp_name'] != '') { list($width, $height) = getimagesize($image_info['tmp_name']); }
        else { $width = 1001; $height = 1001; } //force image to be to big because it is too big and we can't get the size
            
        if (!$bad_upload) {
             if ($image_info['error'] == UPLOAD_ERR_NO_FILE) {
                $upload_errors .= "\\n *Upload Error: No file chosen";
                $bad_upload = true;
            } else if ($width < $minsize || $height < $minsize) {
                $upload_errors .= "\\n *Upload Error: User images must be at least a size of 250px X 250px.";
                $bad_upload = true;
            } else if ($width > $maxsize || $height > $maxsize) {
                $upload_errors .= "\\n *Upload Error: User images can't be any larger than 1000px on a side.";
                $bad_upload = true;
            } else if (move_uploaded_file($image_info['tmp_name'], $uploadfile)){
                //$image_info = resize_image($uploadfile, $minsize, $minsize); //make the image the correct size
                //$upload_errors .= "";
            } else {
                $bad_upload = true;
                $upload_errors .= "\\n *The image upload incountered an error.";
            }
        }
        
        return $upload_errors;
    }
    
     
?>

