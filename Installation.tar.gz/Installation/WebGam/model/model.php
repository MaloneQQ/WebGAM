<?php
    require_once '../lib/general_functions.php';

    //connect to security database
    function getDBConnection() {          
        $dsn = 'mysql:host=localhost;dbname=WebGAM';
        $username = 'root';
        $password = 'W3bG@m';

        try {
            $db = new PDO($dsn, $username, $password);
        } catch (PDOException $e) {
            $error_message = $e->getMessage();
            include '../view/includes/error_page.php';
            die;
        }
        return $db;
    }

//
//get data from CSV
//

//users

    //read the users csv file
    //return an array of the user information for the given user
    function getUserInfo($username){
        
        //the username comming in has the domain attatched, so remove it
        $split = removeDomain($username);
        $username = $split[0];
        
        //download Users CSV
        if (!debugMode()) { callGam('/var/www/html/WebGam/bash/Users/', './userCSV.sh'); }
        
        //for debugging purposes, setting this value to true will echo out the data read from the csv file
        //it will also echo out all the information for the user that was requested
        //set to false when not debugging and when WebGAM is in actual use (or release mode or whatever)
        $echo_data = echoData();
        
        //this array holds the data for a user
        //first column is the heading in the user csv that we are looking for
        //second column is whether or not the haeding could be found in the csv file
        //third column is the column index that the data can be found
        //forth column is an array of values for the data found under that column
        $static_headings = array(
            array ('primaryEmailLocal', false, 0, array()),          // 0  user name
            array ('name.givenName', false, 0, array()),             // 1  first name
            array ('name.familyName', false, 0, array()),            // 2  last name
            array ('suspended', false, 0, array()),                  // 3  suspended
            array ('changePasswordAtNextLogin', false, 0, array()),  // 4  change password next login
            array ('includeInGlobalAddressList', false, 0, array()), // 5  include in global address list
            array ('isAdmin', false, 0, array()),                    // 6  administrator
            array ('orgUnitPath', false, 0, array()),                // 7  ou
            array ('organizations.0.name', false, 0, array()),       // 8  company
            array ('organizations.0.title', false, 0, array()),      // 9  title
            array ('organizations.0.department', false, 0, array()), // 10 department
            array ('relations.0.type', false, 0, array()),           // 11 check if this is manager
            array ('relations.0.value', false, 0, array()),          // 12 if above value was manager, than this is the manager
            array ('addresses.0.type', false, 0, array()),           // 13 address type
            array ('addresses.0.streetAddress', false, 0, array()),  // 14 street address
            array ('addresses.0.formatted', false, 0, array()),      // 15 street address if not in above
            array ('addresses.0.postalCode', false, 0, array()),     // 16 zip code
            array ('addresses.0.countryCode', false, 0, array()),    // 17 country code
            array ('addresses.0.primary', false, 0, array()),        // 18 primary address
            array ('phones.0.type', false, 0, array()),              // 19 phone type
            array ('phones.0.value', false, 0, array()),             // 20 phone number
            array ('phones.0.primary', false, 0, array()),           // 21 primary phone
            array ('nonEditableAliases.0', false, 0, array())        // 22 alias
        );
        $staticsize = 23;
        $relationsindex = 11;
        $addressesindex1 = 12;
        $addressesindex2 = 13;
        $phonesindex = 20;
        $aliasesindex = 22;
        
        //the next four loops hold similar data as above, but for types that can have multiple values
        
        //manager
        //there can only be one manager, but manager is found in with relations, and there can be multiple relations
        $manager_headings = array();
        for ($i = 1; $i <= 10; $i += 1){
            $manager_headings[$i] = array(
                array('relations.'.$i.'.type', false, 0, array()), //check if this is manager
                array('relations.'.$i.'.value', false, 0, array()) //if above value was manager, than this is the manager
            );
        }
        $managerextras = 2;
        
        //addresses
        $address_headings = array();
        for ($i = 1; $i <= maxAddresses(); $i++){
            $address_headings[$i] = array(
                array ('addresses.'.$i.'.type', false, 0, array()),          //address type
                array ('addresses.'.$i.'.streetAddress', false, 0, array()), //street address
                array ('addresses.'.$i.'.formatted', false, 0, array()),     //street address if not in above
                array ('addresses.'.$i.'.postalCode', false, 0, array()),    //zip code
                array ('addresses.'.$i.'.countryCode', false, 0, array()),   //country code
                array ('addresses.'.$i.'.primary', false, 0, array())        //primary address
            );
        }
        $addressextras = 6;
        
        //phones
        $phone_headings = array();
        for ($i = 1; $i <= maxPhones(); $i++){
            $phone_headings[$i] = array(
                array ('phones.'.$i.'.type', false, 0, array()),   //phone type
                array ('phones.'.$i.'.value', false, 0, array()),  //phone number
                array ('phones.'.$i.'.primary', false, 0, array()) //primary phone
            );
        }
        $phoneextras = 3;
        
        //aliases
        $alias_headings = array();
        for ($i = 1; $i <= maxAliases(); $i++){
            $alias_headings[$i] = array('nonEditableAliases.'.$i, false, 0, array()); //alias
        }
        
        //redaing the csv file
        $csv_file = '../data_files/csv/user.csv';
	$readfile = fopen($csv_file, 'rb');
	$i = 0; 
        $num_columns = 0;
        $num_rows = 0;
	$rows = array();
	while (($data = fgetcsv($readfile)) !== FALSE) {
            $num_columns = count($data);
            try {
                $rows[$i] = array ();
                for ($j = 0; $j < $num_columns; $j++){
                    $rows[$i][$j] = $data[$j];
                }
                $i++; 
                $num_rows = $i; //will not include 0
            } catch (PDOException $e) {
                $error_message = $e->getMessage();
                die;
            }
        }
        
        //$rows now has a 2-D array of the csv file
        //go through the headings to see what matches can be found
        for ($i = 0; $i < $num_columns; $i++){
            //check through the static headings
            for ($j = 0; $j < count($static_headings); $j++){
                if ($rows[0][$i] == $static_headings[$j][0]){
                    $static_headings[$j][1] = true; //heading was found
                    $static_headings[$j][2] = $i; //column index of found heading
                }
            }
        }
        
        //check for possible multiple values next, which may not need to do
        //check through the relations (if they are in the csv)
        $extrarelations = 0;
        if ($static_headings[$relationsindex][1] == true){
            for ($i = 0; $i < $num_columns; $i++){
                for ($j = 1; $j <= count($manager_headings); $j++){
                    for ($k = 0; $k < $managerextras; $k++){
                        if ($rows[0][$i] == $manager_headings[$j][$k][0]){
                            $manager_headings[$j][$k][1] = true; //heading was found
                            $manager_headings[$j][$k][2] = $i; //column index of found heading
                            $extrarelations++;
                        }
                    } 
                }
            }
        }
        
        //check through the addresses (if they are in the csv)
        $extraaddresses = 0;
        if ($static_headings[$addressesindex1][1] == true || $static_headings[$addressesindex2][1] == true){
            for ($i = 0; $i < $num_columns; $i++){
                for ($j = 1; $j <= count($address_headings); $j++){
                    for ($k = 0; $k < $addressextras; $k++){
                        if ($rows[0][$i] == $address_headings[$j][$k][0]){
                            $address_headings[$j][$k][1] = true; //heading was found
                            $address_headings[$j][$k][2] = $i; //column index of found heading
                            $extraaddresses++;
                        }
                    } 
                }
            }
        }
        
        //check through the phones (if they are in the csv)
        $extraphones = 0;
        if ($static_headings[$phonesindex][1] == true){
            for ($i = 0; $i < $num_columns; $i++){
                for ($j = 1; $j <= count($phone_headings); $j++){
                    for ($k = 0; $k < $phoneextras; $k++){
                        if ($rows[0][$i] == $phone_headings[$j][$k][0]){
                            $phone_headings[$j][$k][1] = true; //heading was found
                            $phone_headings[$j][$k][2] = $i; //column index of found heading
                            $extraphones++;
                        }
                    } 
                }
            }
        }
        
        //check through the aliases (if they are in the csv)
        $extraaliases = 0;
        if ($static_headings[$aliasesindex][1] == true){
            for ($i = 0; $i < $num_columns; $i++){
                for ($j = 1; $j <= count($alias_headings); $j++){
                    if ($rows[0][$i] == $alias_headings[$j][0]){
                        $alias_headings[$j][1] = true; //heading was found
                        $alias_headings[$j][2] = $i; //column index of found heading
                        $extraaliases++;
                    }
                }
            }
        }
        
//        //for testing, just printing out everything from csv
//        for ($i = 0; $i < $num_rows; $i++){
//            echo "<br /><br />$i: <br />";
//            for ($j = 0; $j < $num_columns; $j++){
//                if ($rows[$i][$j] == '') { echo 'none<br />'; }
//                else { echo $rows[$i][$j].'<br />'; }  
//            }
//        }
        
        if ($echo_data) { echo '<br />Static Reads<br />'; }
        //set the values in static headings by looping through the top array 
        for ($i = 1; $i < $num_rows; $i++){
            if ($echo_data) { echo "<br /><br />$i: <br />"; }
            for ($j = 0; $j < $staticsize; $j++){
                if ($static_headings[$j][1] == true){
                    $static_headings[$j][3][$i] = $rows[$i][$static_headings[$j][2]];
                    if ($echo_data) { if ($rows[$i][$static_headings[$j][2]] == '') { echo '<div class="form_left">'.$static_headings[$j][0].'</div><br />'; }
                    else { echo '<div class="form_left">'.$static_headings[$j][0].'</div>'.$rows[$i][$static_headings[$j][2]].'<br />'; } } 
                }
            }
        }
        
        if ($echo_data) { echo '<br /><br />Relations Reads<br />';
        echo 'Extra Relations: '.$extrarelations.'<br /><br />'; }
        //set the values in managers
        if ($extrarelations != 0){
            for ($i = 1; $i < $num_rows; $i++){
                if ($echo_data) { echo "<br />$i: <br />"; }
                for ($j = 0; $j < $extrarelations; $j++){
                    for ($k = 0; $k < $managerextras; $k++){
                        if ($manager_headings[$j][$k][1] == true){
                            $manager_headings[$j][$k][3][$i] = $rows[$i][$manager_headings[$j][$k][2]];
                            if ($echo_data) { if ($rows[$i][$manager_headings[$j][$k][2]] == '') { echo '<div class="form_left">'.$manager_headings[$j][$k][0].'</div><br />'; }
                            else { echo '<div class="form_left">'.$manager_headings[$j][$k][0].'</div>'.$rows[$i][$manager_headings[$j][$k][2]].'<br />'; } } 
                        }
                    }
                }
            }
        }
        
        if ($echo_data) { echo '<br />Address Reads<br />';
        echo 'Extra Addresses: '.$extraaddresses.'<br />'; }
        //set the values in addresses
        if ($extraaddresses != 0){
            for ($i = 1; $i < $num_rows; $i++){
                if ($echo_data) { echo "<br />$i: <br />"; }
                for ($j = 1; $j <= $extraaddresses; $j++){
                    for ($k = 0; $k < $addressextras; $k++){
                        if ($address_headings[$j][$k][1] == true){
                            $address_headings[$j][$k][3][$i] = $rows[$i][$address_headings[$j][$k][2]];
                            if ($echo_data) { if ($rows[$i][$address_headings[$j][$k][2]] == '') { '<div class="form_left">'.$address_headings[$j][$k][0].'</div><br />'; }
                            else { echo '<div class="form_left">'.$address_headings[$j][$k][0].'</div>'.$rows[$i][$address_headings[$j][$k][2]].'<br />'; } }
                        }
                    }
                }
            }
        }
        
        //set the values in phones
        if ($echo_data) { echo '<br /><br />Phone Reads<br />';
        echo 'Extra Phones: '.$extraphones.'<br />'; }
        if ($extraphones != 0){
            for ($i = 1; $i < $num_rows; $i++){
                if ($echo_data) { echo "<br />$i: <br />"; }
                for ($j = 1; $j <= $extraphones; $j++){
                    for ($k = 0; $k < $phoneextras; $k++){
                        if ($phone_headings[$j][$k][1] == true){
                            $phone_headings[$j][$k][3][$i] = $rows[$i][$phone_headings[$j][$k][2]];
                            if ($echo_data) { if ($rows[$i][$phone_headings[$j][$k][2]] == '') { '<div class="form_left">'.$phone_headings[$j][$k][0].'</div><br />'; }
                            else { echo '<div class="form_left">'.$phone_headings[$j][$k][0].'</div>'.$rows[$i][$phone_headings[$j][$k][2]].'<br />'; } }
                        }
                    }
                }
            }
        }
        
        if ($echo_data) { echo '<br /><br />Alias Reads<br />';
        echo 'Extra Aliases: '.$extraaliases.'<br />'; }
        //set the values in aliases
        if ($extraaliases != 0){
            for ($i = 1; $i < $num_rows; $i++){
                for ($j = 1; $j <= $extraaliases; $j++){
                    if ($alias_headings[$j][1] == true){
                        $alias_headings[$j][3][$i] = $rows[$i][$alias_headings[$j][2]];
                        if ($echo_data) { if ($alias_headings[$j][3][$i] == '') { echo '<div class="form_left">'.$alias_headings[$j][0].'</div><br />'; }
                        else { echo '<div class="form_left">'.$alias_headings[$j][0].'</div>'.$rows[$i][$alias_headings[$j][2]].'<br />'; } }
                    }
                } 
            }
        }
        
        //all the possible data has been extracted
        
        //loop through the static data and record the index of the matching user
        //if there is no match then use index 1 for the first user
        $user_index = 1; //1 by default because that is the row the first user is in the static datas
        for ($i = 1; $i <= count($static_headings[0][3]); $i++){
            if ($echo_data) { echo '<br />'.$static_headings[0][3][$i].' : '.$username; }
            if ($static_headings[0][3][$i] == $username) { $user_index = $i; }
        }
        if ($echo_data) { echo '<br />User Index: '.$user_index.'<br />'; }
        
        //user index has been found
        //for static data, the index is the exact number for the data
        //for extra data, the index is $user_index - 1 (because reading started at row 1)
        if ($echo_data) { echo '<br />User '.$user_index.' Information:<br />'; }
        $user_info = array();
        //loop through static, loop through 2nd arrays, get index [3][$user_index]
        $user_info[0] = array();
        for ($i = 0; $i < count($static_headings); $i++){
            if ($static_headings[$i][1]) { //we should see if the data actually exists, meaning the header must exsist
                $user_info[0][$i] = $static_headings[$i][3][$user_index]; //use exisiting data
            } else { 
                $user_info[0][$i] = ""; //header is not in csv file, so default to null
            }
            if ($echo_data) { echo '<div class="form_left">'.$i.': '.$static_headings[$i][0].'</div>'.$user_info[0][$i].'<br />'; }
        }
        
        //get extra managers for the user
        $user_info[1] = array();
        for ($i = 1; $i < count($manager_headings); $i++){
            for ($j = 0; $j < count($manager_headings[$i]); $j++){
                if ($manager_headings[$i][$j][1] == true){
                    if ($manager_headings[$i][$j][3][$user_index] != ''){
                        $user_info[1][$i] = $manager_headings[$i][$j][3][$user_index];
                        if ($echo_data) { echo '<div class="form_left">'.$i.': '.$manager_headings[$i][$j][0].'</div>'.$manager_headings[$i][$j][3][$user_index].'<br />'; }
                    } 
                }
            }
        }
        
        //get extra addresses for the user
        $user_info[2] = array();
        $extradata = false;
        for ($i = 1; $i < count($address_headings); $i++){ //loop through the address headings
            $user_info[2][$i] = array();
            for ($j = 0; $j < count($address_headings[$i]); $j++){
                if ($address_headings[$i][$j][1] == true){
                    if ($address_headings[$i][$j][3][$user_index] != ''){
                        $user_info[2][$i][$j] = $address_headings[$i][$j][3][$user_index];
                        if ($echo_data) { echo '<div class="form_left">'.$i.'-'.$j.': '.$address_headings[$i][$j][0].'</div>'.$user_info[2][$i][$j].'<br />'; }
                        $extradata = true;    
                    }
                }
                else 
                {
                    $user_info[2][$i][$j] = '';
                }
            }
        }
        
        //get a count of the addresses with actual data
        $addresscount = 0;
        if ($extradata) {
            for ($i = 1; $i <= count($user_info[2]); $i++) {
                $datapresent = false;
                for ($j = 0; $j < count($user_info[2][$i]); $j++) {
                    if ($user_info[2][$i][$j] != '') {
                        if ($echo_data) { echo '<div class="form_left">'.$i.'-'.$j.': '.$address_headings[$i][$j][0].'</div>'.$user_info[2][$i][$j].'<br />'; }
                        $datapresent = true;
                    } 
                } 
                if ($datapresent) { $addresscount++; }
            }
        }
        $user_info[3] = $addresscount;
        
        //get extra phones for the user
        $user_info[4] = array();
        $extradata = false;
        for ($i = 1; $i < count($phone_headings); $i++){
            $user_info[4][$i] = array();
            for ($j = 0; $j < count($phone_headings[$i]); $j++){
                if ($phone_headings[$i][$j][1] == true){
                    if ($phone_headings[$i][$j][3][$user_index] != ''){
                        $user_info[4][$i][$j] = $phone_headings[$i][$j][3][$user_index];
                        if ($echo_data) { echo '<div class="form_left">'.$i.'-'.$j.': '.$phone_headings[$i][$j][0].'</div>'.$user_info[4][$i][$j].'<br />'; }
                        $extradata = true; 
                    }
                }
                else 
                {
                    $user_info[4][$i][$j] = '';
                }
            }
        }
        
        //get a count of the phones with actual data
        $phonecount = 0;
        if ($extradata) {
            for ($i = 1; $i <= count($user_info[4]); $i++) {
                $datapresent = false;
                for ($j = 0; $j < count($user_info[4][$i]); $j++) {
                    if ($user_info[4][$i][$j] != '') {
                        if ($echo_data) { echo '<div class="form_left">'.$i.'-'.$j.': '.$phone_headings[$i][$j][0].'</div>'.$user_info[4][$i][$j].'<br />'; }
                        $datapresent = true;
                    } 
                } 
                if ($datapresent) { $phonecount++; }
            }
        }
        $user_info[5] = $phonecount;
        
        //get extra aliases for the user
        $user_info[6] = array();
        for ($i = 1; $i < count($alias_headings); $i++){
            if ($alias_headings[$i][1] == true){
                if ($alias_headings[$i][3][$user_index] != ''){
                    $user_info[6][$i] = array();
                    $user_info[6][$i][0] = $alias_headings[$i][3][$user_index];
                    $user_info[6][$i][1] = ''; //hold a spot for the domain
                    if ($echo_data) { echo '<div class="form_left">'.$i.': '.$alias_headings[$i][0].'</div>'.$user_info[6][$i].'<br />'; }
                }
            }
        }
        
        //return an array of the static values for the user, extra manager, address, phone, and alias values
        return $user_info;
    }

    //read the users csv file
    //return an array of all the user names
    function getUsers(){

        //download User CSV
        if (!debugMode()) { callGam('/var/www/html/WebGam/bash/Users/', './userCSV.sh'); }       
        
        //reading the csv file
        $csv_file = '../data_files/csv/user.csv';
	$readfile = fopen($csv_file, 'rb');
	$i = 0; 
        $num_columns = 0;
        $num_rows = 0;
	$usercsvrows = array();
	while (($data = fgetcsv($readfile)) !== FALSE) {
            $num_columns = count($data);
            try {
                $usercsvrows[$i] = array ();
                for ($j = 0; $j < $num_columns; $j++){
                    $usercsvrows[$i][$j] = $data[$j];
                }
                $i++; 
                $num_rows = $i; //will not include 0
            } catch (PDOException $e) {
                $error_message = $e->getMessage();
                die;
            }
        }
        
        //look for the username column index
        $username_column_index = 0;
        for ($i = 0; $i < $num_columns; $i++){
            if ($usercsvrows[0][$i] == 'primaryEmailLocal'){
                $username_column_index = $i;
            }
        }
        
        //populate an array of users
        $rows = array();
        for ($i = 0; $i < $num_rows; $i++){
            $rows[$i] = $usercsvrows[$i][$username_column_index];
        }
        
        return $rows;
    }
    
//groups
    
    //read the groups csv file
    //return array of the group information of the given group
    function getGroupInfo($groupname){
        
        //download Groups CSV
        if (!debugMode()) { callGam('/var/www/html/WebGam/bash/Groups/', './groupCSV.sh'); }
        
        $namecolumn = array(false, 0, 'Name');
        $emailcolumn = array(false, 0, 'Email');
        $discriptioncolumn = array(false, 0, 'Description');
        $aliascolumn = array(false, 0, 'Aliases');
        
        $csv_file = '../data_files/csv/groups.csv';
	$readfile = fopen($csv_file, 'rb');
	$row = 0; 
	$rows = array('', '', '', '');
	while (($data = fgetcsv($readfile)) !== FALSE) {
            try {
                if ($row == 0){
                    for ($column = 0; $column < count($data); $column++){
                        if ($data[$column] == $namecolumn[2]) { $namecolumn[0] = true; $namecolumn[1] = $column; }
                        if ($data[$column] == $emailcolumn[2]) { $emailcolumn[0] = true; $emailcolumn[1] = $column; }
                        if ($data[$column] == $discriptioncolumn[2]) { $discriptioncolumn[0] = true; $discriptioncolumn[1] = $column; }
                        if ($data[$column] == $aliascolumn[2]) { $aliascolumn[0] = true; $aliascolumn[1] = $column; }
                    }
                }
                if ($data[$namecolumn[1]] == $groupname){ //we have a match, so get that groups information
                    if ($namecolumn[0] == true) { $rows[0] = $data[$namecolumn[1]]; }              //group name
                    if ($emailcolumn[0] == true) {$rows[1] = $data[$emailcolumn[1]]; }             //group email
                    if ($discriptioncolumn[0] == true) {$rows[2] = $data[$discriptioncolumn[1]]; } //group description
                    if ($aliascolumn[0] == true) {$rows[3] = $data[$aliascolumn[1]]; }             //group alias
                }
                $row++;
            } catch (PDOException $e) {
                $error_message = $e->getMessage();
                die;
            }
        }
        
        return $rows;
    }
    
    //read the groups csv file
    //return an array of the group names
    function getGroups(){
        
        //download Groups CSV
        if (!debugMode()) { callGam('/var/www/html/WebGam/bash/Groups/', './groupCSV.sh'); }
        
        $namecolumn = array(false, 0, 'Name'); //header for group name column we want. see if found, and set column value
        
        $csv_file = '../data_files/csv/groups.csv';
	$readfile = fopen($csv_file, 'rb');
	$row = 0; 
	$rows = array();
	while (($data = fgetcsv($readfile)) !== FALSE) {
            try {
                if ($row == 0) {
                    for ($column = 0; $column < count($data); $column++){
                        if ($data[$column] == $namecolumn[2]) { $namecolumn[0] = true; $namecolumn[1] = $column; }
                    }
                }
                if ($namecolumn[0] == true){ //we have a match, so get that groups information
                    $rows[$row] = $data[$namecolumn[1]]; 
                }
                $row++;
            } catch (PDOException $e) {
                $error_message = $e->getMessage();
                die;
            }
        }
        
        return $rows;
    }
    
    //read the csv file
    //return an array of group emails
    function getGroupEmails(){
        
        //download Groups CSV
        if (!debugMode()) { callGam('/var/www/html/WebGam/bash/Groups/', './groupCSV.sh'); }
        
        $namecolumn = array(false, 0, 'Email'); //header for group name column we want. see if found, and set column value
        
        $csv_file = '../data_files/csv/groups.csv';
	$readfile = fopen($csv_file, 'rb');
	$row = 0; 
	$rows = array();
	while (($data = fgetcsv($readfile)) !== FALSE) {
            try {
                if ($row == 0) {
                    for ($column = 0; $column < count($data); $column++){
                        if ($data[$column] == $namecolumn[2]) { $namecolumn[0] = true; $namecolumn[1] = $column; }
                    }
                }
                if ($namecolumn[0] == true){ //we have a match, so get that groups information
                    $rows[$row] = $data[$namecolumn[1]]; 
                }
                $row++;
            } catch (PDOException $e) {
                $error_message = $e->getMessage();
                die;
            }
        }
        
        return $rows;
    }
    
    //get all the usernames that exists
    //read through the groups csv file and get all the users for that group
    //return a list of all users in the group, and all users not in the group
    function getGroupMembers($groupname){
        $users = getUsers(); //get a full list of users to check againts
        
        $usersincsv = array(); //hold the users in the group
        $usersout = array(); //hold the users not in the group
        
        //download Groups CSV
        if (!debugMode()) { callGam('/var/www/html/WebGam/bash/Groups/', './groupCSV.sh'); }
        
        $namecolumn = array(false, 0, 'Name');
        $memberscolumn = array(false, 0, 'Members');
        
        $csv_file = '../data_files/csv/groups.csv';
	$readfile = fopen($csv_file, 'rb');
        $row = 0;
        //read the csv file
	while (($data = fgetcsv($readfile)) !== FALSE) {
            try {
                if ($row == 0) { 
                    for ($column = 0; $column < count($data); $column++){
                        if ($data[$column] == $namecolumn[2]) { $namecolumn[0] = true; $namecolumn[1] = $column; }
                        if ($data[$column] == $memberscolumn[2]) { $memberscolumn[0] = true; $memberscolumn[1] = $column; }
                    }
                }
                if ($namecolumn[0] == true && $data[$namecolumn[1]] == $groupname){ //we have a match, so get that groups information
                    $usersincsv = split("\n", $data[$memberscolumn[1]]); //group members
                }
                $row++;
            } catch (PDOException $e) {
                $error_message = $e->getMessage();
                die;
            }
        }
        
        //get all of the users that were taken from csv
        for ($i = 0; $i < count($usersincsv); $i++){
            $userexists = false;
            for ($j = 1; $j < count($users); $j++){
                $split = removeDomain($usersincsv[$i]);
                $usersincsv[$i] = $split[0];
                if ($usersincsv[$i] == $users[$j]) { $users[$j] = ''; $userexists = true;}
            }
            if (!$userexists) { $usersincsv[$i] = ''; }
        }
        
        $usersin = array(); //will only have users that currently exists in the groups
        for ($i = 0, $j = 0; $i < count($usersincsv); $i++){
            if ($usersincsv[$i] != '') { $usersin[$j] = $usersincsv[$i]; $j++; }
        }
        for ($i = 1, $j = 0; $i < count($users); $i++){
            if ($users[$i] != '') { $usersout[$j] = $users[$i]; $j++; }
        }
        
        return array($usersin, $usersout);
        
        //return and array with list of users in, and list of users out
    }
    
//ous
    
    //read the ous csv file
    //return array of the ou information of the given ou
    function getOUInfo($ouname){
        
        //download OUs CSV
        if (!debugMode()) { callGam('/var/www/html/WebGam/bash/OU/', './ouCSV.sh'); }
        
        $namecolumn = array(false, 0, 'Name');
        $discriptioncolumn = array(false, 0, 'Description');
        $parentcolumn = array(false, 0, 'Parent');
	$pathcolumn = array(false, 0, 'Path');
        
        $csv_file = '../data_files/csv/orgs.csv';
	$readfile = fopen($csv_file, 'rb');
	$row = 0; 
	$rows = array('', '', '', '');
	while (($data = fgetcsv($readfile)) !== FALSE) {
            try {
                if ($row == 0) {
                    for ($column = 0; $column < count($data); $column++){
                        if ($data[$column] == $namecolumn[2]) { $namecolumn[0] = true; $namecolumn[1] = $column; }
                        if ($data[$column] == $discriptioncolumn[2]) { $discriptioncolumn[0] = true; $discriptioncolumn[1] = $column; }
                        if ($data[$column] == $parentcolumn[2]) { $parentcolumn[0] = true; $parentcolumn[1] = $column; }
			if ($data[$column] == $pathcolumn[2]) { $pathcolumn[0] = true; $pathcolumn[1] = $column; }
                    }
                }
                if ($data[$namecolumn[1]] == $ouname){ //we have a match, so get that groups information
                    if ($namecolumn[0] == true) { $rows[0] = $data[$namecolumn[1]]; }               //ou name
                    if ($discriptioncolumn[0] == true) { $rows[1] = $data[$discriptioncolumn[1]]; } //ou description
                    if ($parentcolumn[0] == true) { $rows[2] = $data[$parentcolumn[1]]; }           //ou parent
		    if ($pathcolumn[0] == true) { $rows[3] = $data[$pathcolumn[1]]; }               //ou path
                }
                $row++;
            } catch (PDOException $e) {
                $error_message = $e->getMessage();
                die;
            }
        }
        
        return $rows;
    }
    
    //read the organizations csv file
    //return an array of the organization names
    function getOUs(){
        
        //download Organization CSV
        if (!debugMode()) { callGam('/var/www/html/WebGam/bash/OU/', './ouCSV.sh'); }
        
        $namecolumn = array(false, 0, 'Name'); //header for ou name column we want. see if found, and set column value
        
        $csv_file = '../data_files/csv/orgs.csv';
	$readfile = fopen($csv_file, 'rb');
	$row = 0; 
	$rows = array();
	while (($data = fgetcsv($readfile)) !== FALSE) {
            try {
                if ($row == 0) {
                    for ($column = 0; $column < count($data); $column++){
                        if ($data[$column] == $namecolumn[2]) { $namecolumn[0] = true; $namecolumn[1] = $column; }
                    }
                }
                if ($namecolumn[0] == true){ //we have a match, so get that groups information
                    $rows[$row] = $data[$namecolumn[1]]; 
                }
                $row++;
            } catch (PDOException $e) {
                $error_message = $e->getMessage();
                die;
            }
        }
        
        return $rows;
    }
    
    //read the organizations csv file
    //return an array of the organization full paths
    function getOUpaths(){
        
        //download Organization CSV
        if (!debugMode()) { callGam('/var/www/html/WebGam/bash/OU/', './ouCSV.sh'); }
        
        $namecolumn = array(false, 0, 'Path'); //header for ou name column we want. see if found, and set column value
        
        $csv_file = '../data_files/csv/orgs.csv';
	$readfile = fopen($csv_file, 'rb');
	$row = 0; 
	$rows = array();
	while (($data = fgetcsv($readfile)) !== FALSE) {
            try {
                if ($row == 0) {
                    for ($column = 0; $column < count($data); $column++){
                        if ($data[$column] == $namecolumn[2]) { $namecolumn[0] = true; $namecolumn[1] = $column; }
                    }
                }
                if ($namecolumn[0] == true){ //we have a match, so get that groups information
                    $rows[$row] = $data[$namecolumn[1]]; 
                }
                $row++;
            } catch (PDOException $e) {
                $error_message = $e->getMessage();
                die;
            }
        }
        
        return $rows;
    }
    
    //read the organizations csv file
    //return an array of the organizations that are parents
    function getOUparents(){
        
        //download Organization CSV
        if (!debugMode()) { callGam('/var/www/html/WebGam/bash/OU/', './ouCSV.sh'); }
        
        $namecolumn = array(false, 0, 'Parent'); //header for ou name column we want. see if found, and set column value
        
        $csv_file = '../data_files/csv/orgs.csv';
	$readfile = fopen($csv_file, 'rb');
	$row = 0; 
	$rows = array();
	while (($data = fgetcsv($readfile)) !== FALSE) {
            try {
                if ($row == 0) {
                    for ($column = 0; $column < count($data); $column++){
                        if ($data[$column] == $namecolumn[2]) { $namecolumn[0] = true; $namecolumn[1] = $column; }
                    }
                }
                if ($namecolumn[0] == true){ //we have a match, so get that groups information
                    $rows[$row] = $data[$namecolumn[1]]; 
                }
                $row++;
            } catch (PDOException $e) {
                $error_message = $e->getMessage();
                die;
            }
        }
        
        return $rows;
    }
    
    //read the users csv file and for each user with an ou
    //check to see if that ou matches the passed in ou and add user to list of users in ou
    //generate a list of users not in ou
    function getOUmembers($ouname){
        $users = getUsers(); //get a full list of users to check againts
        $usersin = array(); //hold the users in the ou
        $usersout = array(); //hold the users not in the ou
        
        //download Users CSV
        if (!debugMode()) { callGam('/var/www/html/WebGam/bash/Users/', './userCSV.sh'); }
        
        $namecolumn = array(false, 0, 'primaryEmailLocal');
        $oucolumn = array(false, 0, 'orgUnitPath');
        
        $csv_file = '../data_files/csv/user.csv';
	$readfile = fopen($csv_file, 'rb');
        $row = 0;
        $i = 0; //keep an index for $usersin
        //read the csv file
	while (($data = fgetcsv($readfile)) !== FALSE) {
            try {
                if ($row == 0) { 
                    for ($column = 0; $column < count($data); $column++){
                        if ($data[$column] == $namecolumn[2]) { $namecolumn[0] = true; $namecolumn[1] = $column; }
                        if ($data[$column] == $oucolumn[2]) { $oucolumn[0] = true; $oucolumn[1] = $column; }
                    }
                }
                if ($oucolumn[0] == true){
                    $userou = substr($data[$oucolumn[1]], 1);
                    if ($userou == $ouname) { $usersin[$i] = $data[$namecolumn[1]]; $i++; }
                }
                $row++;
            } catch (PDOException $e) {
                $error_message = $e->getMessage();
                die;
            }
        }
        
        //get all of the users that were taken from csv
        for ($i = 0; $i < count($usersin); $i++){
            for ($j = 1; $j < count($users); $j++){
                if ($usersin[$i] == $users[$j]) { $users[$j] = ''; }
            }
        }
        
        for ($i = 1, $j = 0; $i < count($users); $i++){
            if ($users[$i] != '') { $usersout[$j] = $users[$i]; $j++; }
        }
        
        return array($usersin, $usersout);
        
    }
//other
    
    //read the servers domain
    function getDomain(){
        $csv_file = '../data_files/csv/domain.csv';
	$readfile = fopen($csv_file, 'rb');
	while (($data = fgetcsv($readfile)) !== FALSE) {
            try {
                $domain_data = $data[0];
                break;
            } catch (PDOException $e) {
                $error_message = $e->getMessage();
                die;
            }
        }
        
        $front = ""; 
        $back = "";
        $foundbreak = false;
        $strlen = strlen( $domain_data );
        for( $i = 0; $i <= $strlen; $i++ ) { 
            $char = substr( $domain_data, $i, 1 );
            if ($char == ':') { $foundbreak = true; }
            else 
            { 
                if (!$foundbreak) { $front .= $char; }
                else { $back .= $char; }
            }
        }
        
        $domain = substr($back, 1);
        
        return $domain;
    }
    
    //read the country codes csv file
    //return an array of the country codes and the corresponding country
    function getCountryCodes(){       
        $csv_file = '../data_files/csv/country_codes.csv';
	$readfile = fopen($csv_file, 'rb');
	$i = 0; 
	$rows = array();
	while (($data = fgetcsv($readfile)) !== FALSE) {
            try {
                $rows[$i] = array ($data[0], $data[1]); 
                $i++;
            } catch (PDOException $e) {
                $error_message = $e->getMessage();
                die;
            }
        }
        
        return $rows;
    }
    
    //given a country code, returns the full country name
    function getCountryName($countryCode) {
        $csv_file = '../data_files/csv/country_codes.csv';
	$readfile = fopen($csv_file, 'rb');
	$i = 0; 
	while (($data = fgetcsv($readfile)) !== FALSE) {
            try {
                if ($data[1] == $countryCode) { return $data[0]; } //found a match
                $i++;
            } catch (PDOException $e) {
                $error_message = $e->getMessage();
                die;
            }
        }
        
        return $countryCode; //did not find a match
    }
    
    //read the phone types csv file
    //return an array of the phone types and their corresponding display name
    function getPhoneTypes(){       
        $csv_file = '../data_files/csv/phone_types.csv';
	$readfile = fopen($csv_file, 'rb');
	$i = 0; 
	$rows = array();
	while (($data = fgetcsv($readfile)) !== FALSE) {
            try {
                $rows[$i] = array ($data[0], $data[1]); 
                $i++;
            } catch (PDOException $e) {
                $error_message = $e->getMessage();
                die;
            }
        }
        
        return $rows;
    }
      
?>
