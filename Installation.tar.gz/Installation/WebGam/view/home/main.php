<?php
    $title = "WebGAM - Home";
    $folder = "home";
    require '../view/includes/header_include.php';
?>

<div class='form'>

<br />
<h1 class="text_center">WebGAM</h1>
<br /><br />

    <?php 
        $manual = 0;
        $section = 0;
        if (isset($_GET['manual'])) { $manual = $_GET['manual']; }
        if (isset($_GET['section'])) { $section = $_GET['section']; }
    ?>
    <?php if ($manual == 0) { ?>
        Welcome to WebGAM, a friendly user interface to the command line Google 
        Apps Manager tool, GAM. <br />
        <br />
        For those of you new WebGAM, you can follow the basic user's manual by 
        selecting any of the topics in the manual index below. If you are unfamiliar 
        with GAM, we suggest you read the more in-depth user's guide included in 
        WebGAM's documentation. <br />
        <br />
        <br />
        <h3>WebGAM User's Manual</h3>
        <br />
        <?php require '../view/includes/manual_index_include.php'; ?>
    <?php } else if ($manual == 1 && $section == 0) { ?>
        <h3>1. Introduction</h3>
        <br />
        So here in WebGAM, we have most of the basic functionality that you would 
        find in GAM, but in an easier to use interface. From WebGAM you can manage 
        your Google Apps account by performing functions on users, groups, and 
        organizational units (OU's).<br />
        <br />
        Want to add a new group? Go to the Groups 
        page. Just fired an employee and need to delete them? Head on over to 
        the Users page. Want to place the new guy you just hired into an OU? 
        Go ahead and do it on the OU page. <br />
        <br />
        With the help of this guide, you should by the end be able to perform all 
        of these tasks and more. The navigation at the bottom of each page of 
        this manual will guide you through. If you ever need to get back to 
        the home page of WebGAM, just click the WebGAM logo at the top left of the 
        screen.<br />
        <br />
        It is suggested that as you go through this guide that you have WebGAM 
        open in another window so that as we walk through the basics of each page 
        you will be able to get a better feel for what is being talked about.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=0&section=0'>< WebGAM Home Page</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=2&section=0'>2. Users ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 2 && $section == 0) { ?>
        <h3>2. Users</h3>
        <br />
        In WebGAM there are four main functions you can perform on users; add, 
        edit, delete, and view. To perform any user function, just select one 
        of the options available to you in the tool bar at the top of your screen.<br />
        <br />
        If you have users already connected to your Google Apps account, you should 
        see a list of those users on the users home page. Next to each users name 
        are the options to view or edit that user. These view and edit links will 
        take you to the same location as the view and edit links on the tool bar, 
        except they will take you directly to the edit and view pages for that 
        specific user.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=1&section=0'>< 1. Introduction</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=2&section=1'>2.1 Adding Users ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 2 && $section == 1) { ?>
        <h3>2.1 Adding Users</h3>
        <br />
        On the add user page you will be given a form in which to fill out all of 
        the new users information. You will be required to provide a valid username 
        and password. All of the other fields are optional, except in one special case. 
        If you input a username containing a period, then you must provide an alias 
        for that user.<br />
        <br />
        Now you may be wondering, how can I add an alias? There is no form input 
        for that. Well, in order to tidy up the form a bit, we put in some spoilers 
        to hide much of the un-required fields. Simply click on the heading 
        for aliases, and you should now see inputs for that option. Company 
        information, addresses, and phones have the same functionality.<br />
        <br />
        So most form inputs are quite basic and easy to understand, but others 
        need a little explanation. You can upload an image for a user by clicking 
        the choose file button. Just select any image that you have of that user 
        and it should load right on up. There are some restrictions though. Images 
        must be in PNG, JPG, or GIF format, and can be no larger than 1000 pixels on a side.<br />
        <br />
        Below the image upload, are four check box options. You can suspend the user 
        for whatever reason by selecting suspend. If you want to have the user 
        change their password the next time they login, select that option. Selecting 
        add user global will add the new user to your company's global address list. If you 
        want to make your new user an administrator, do so by selecting that option.<br />
        <br />
        Company information, addresses and phones should be easy enough to understand, 
        but aliases could be unfamiliar territory. An alias is just a secondary 
        email address in which users can have their company emails sent or forwarded 
        to. You may see the buttons which allow you to add or remove aliases, and that 
        is also true for addresses and phones. You can add up to ten of each.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=2&section=0'>< 2. Users</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=2&section=2'>2.2 Editing Users ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 2 && $section == 2) { ?>
        <h3>2.2 Editing Users</h3>
        <br />
        At some point a user's information may change, or you have more information 
        you want to add. The edit users page is the place to do it. The form here is 
        similar to the add users page. There are some minor differences though. Any 
        information about a user that already exists can be edited, but it may not 
        be deleted. Why is that? Well GAM currently does not have the capability 
        to delete information, so as an interface to GAM, whatever GAM can't do, 
        WebGAM can't do.<br />
        <br />
        At the top of the edit form, you will notice a drop down selection box 
        with the current user selected. If you would like to edit a different user 
        than just select that other user from the drop down box, and you will be 
        taken to the edit page for that user.<br />
        <br />
        The other difference from the add form is the inability to set the username. 
        Once a user has been created, that username is set for good. So if you notice 
        when creating a user that their username does suit your tastes, or you just 
        simply made a mistake in the name you just can't live with, go ahead and 
        delete that user and try again.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=2&section=1'>< 2.1 Adding Users</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=2&section=3'>2.3 Removing Users ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 2 && $section == 3) { ?>
        <h3>2.3 Removing Users</h3>
        <br />
        Removing a user is quite an easy task, even if telling that employee they 
        are fired isn't. To remove a user, just simply select the check box next 
        to the name of the user you want to remove, click submit, and that's it. 
        If you're laying off multiple employees, just select as many users as you 
        want from this form, click submit, and problem solved.
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=2&section=2'>< 2.2 Editing Users</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=2&section=4'>2.4 Viewing Users ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 2 && $section == 4) { ?>
        <h3>2.4 Viewing Users</h3>
        <br />
        If ever you want to view the current information you have on a user, like 
        an address for billing, or their organizational unit, or maybe you just 
        can't remember what they look like and need to refresh your memory, then 
        the view user page is the place for you. The layout of this page is similar 
        to the add and edit user pages, just without the form inputs. <br />
        <br />
        Similar to the edit page, the current user will be selected in a drop down 
        selection box at the top of the page. To view a different user, just select them 
        from the drop down box.<br />
        <br />
        If you are on the view page, and you notice that a user's information has 
        changed and you would like to edit it, just simply click on edit in the 
        tool bar at the top of the page. You will be directed to the edit user page 
        for the user that you were just viewing, so no need to go looking for them.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=2&section=3'>< 2.3 Removing Users</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=3&section=0'>3. Groups ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 3 && $section == 0) { ?>
        <h3>3. Groups</h3>
        <br />
        Just like with users, there are four main functions that can be performed 
        on groups, add, edit, remove and view. The general functionality of these 
        options are quite similar to the functions for users, with the only difference 
        being the data.<br />
        <br />
        If you already have groups in your Google Apps account, then you should 
        see a list of those groups on the groups home page. Next to each group 
        will be links to view or edit that group, taking you directly to the corresponding 
        page for the group.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=2&section=4'>< 2.4 Viewing Users</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=3&section=1'>3.1 Adding Groups ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 3 && $section == 1) { ?>
        <h3>3.1 Adding Groups</h3>
        <br />
        On the add group page, you will be able to fill out the basic information 
        about the group, and add members to the group. This form is much less 
        intimidating than the form for users, but there are still some inputs that need 
        to be explained.<br />
        <br />
        There are two required fields, the group name of course, and a group email 
        address. Unlike in the users page, you can add periods to a group name 
        without being forced to add an alias. You have the option of adding an email 
        alias to the group, and also adding a description to the group, which is 
        recommended, but not required.<br />
        <br />
        The next thing to go over is how to add users to the new group. The last 
        form input you will see are to multiple selection boxes, one labeled users 
        in group, and the other labeled users not in group. By default, no users 
        are in the new group you are creating, so the users in group box should 
        be empty. The users not in group box should contain every user in your 
        Google Apps account. To add users to a group, click on the user you want 
        to add from the users not in group box, then click on the << button. This 
        should move the user over into the users in group box. If you decide you want 
        to take a user out of the group, then select them from the users in group 
        box, and slick the >> button to take them out.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=3&section=0'>< 3. Groups</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=3&section=2'>3.2 Editing Groups ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 3 && $section == 2) { ?>
        <h3>3.2 Editing Groups</h3>
        <br />
        The edit group page has the same form as in the add group page, but like 
        how the edit user page works, the data for a currently selected group is 
        already filled onto the form. Like in the edit user form, data that is already 
        populated cannot be removed only edited. However, you will be able to 
        add or remove users from the group in the same manner as discussed on the 
        previous manual page.<br />
        <br />
        Again, like with editing users, the group name is un-editable. The group 
        if you want to edit a different group, then you can select that group from 
        the drop down box at the top of the form.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=3&section=1'>< 3.1 Adding Groups</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=3&section=3'>3.3 Removing Groups ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 3 && $section == 3) { ?>
        <h3>3.3 Removing Groups</h3>
        <br />
        So you have a group, and you've decided you have no use for it anymore, 
        maybe because you are consolidating groups, or because that group is just 
        useless, and you don't need it any more. Then just check the box next to 
        group your cutting, and click that submit button. Just like in the remove 
        user page, you can select and remove multiple groups at once.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=3&section=2'>< 3.2 Editing Groups</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=3&section=4'>3.4 Viewing Groups ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 3 && $section == 4) { ?>
        <h3>3.4 Viewing Groups</h3>
        <br />
        If all you wish to do is view the information about a group, then go to 
        the view group page. All the group data will be listed for your viewing 
        pleasure without those pesky input boxes getting in the way. Just like 
        on the edit group page, you can view a different group by selecting it 
        from the drop down box at the top of the page. If you want to edit the 
        current group that you are viewing, then click edit in the tool bar and 
        you will be taken straight to the edit page for the current group.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=3&section=3'>< 3.3 Removing Groups</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=4&section=0'>4. OUs ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 4 && $section == 0) { ?>
        <h3>4. OUs</h3>
        <br />
        OUs work in the same manner as users and groups. There are the four basic 
        functions, and if OUs exists within you Google Apps account, you will 
        see links to view and edit the existing OUs on the OU home page.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=3&section=4'>< 3.4 Viewing Groups</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=4&section=1'>4.1 Adding OUs ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 4 && $section == 1) { ?>
        <h3>4.1 Adding OUs</h3>
        <br />
        If you have begun to notice the pattern here, then you would know that the 
        add OU page will have a form for you to enter the basic information for a 
        new OU.<br />
        <br />
        The required fields are an OU name, and an OU description. If you already 
        have OUs within your Google Apps account, then you will be able to assign 
        a parent OU to your new OU. By default the new OU will not have a parent.<br />
        <br />
        Next you will be able to add users to the OU, if you so desire. This will 
        work similarly to how users are added into groups. Simply select the user 
        which you want to add from the users not in ou selection box, then click 
        the << button to transfer the user over to the users in ou box. To remove 
        a user from an OU, just select the users you want to remove in the users 
        in ou selection box, then click the >> button to move those users back to 
        the users not in ou box.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=4&section=0'>< 4. OUs</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=4&section=2'>4.2 Editing OUs ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 4 && $section == 2) { ?>
        <h3>4.2 Editing OUs</h3>
        <br />
        Much like edit users and groups, the information of the OU that you want 
        edit will be populated into the edit OU form. Again, you will not be able 
        to delete any information that already exists for the OU, but you will be 
        able to remove existing members from the OU and add new ones. Add and remove 
        users form the OU the same way as you would on the add ou page. Again, you 
        can edit a different OU by using the selection box at the top of the form.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=4&section=1'>< 4.1 Adding OUs</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=4&section=3'>4.3 Removing OUs ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 4 && $section == 3) { ?>
        <h3>4.3 Removing OUs</h3>
        <br />
        So if you have read through all the documentation, you should know the drill 
        for removing things from WebGAM. To remove OUs, check the boxes next to the 
        names of any OU you wish to remove, click the submit button, and the OUs 
        will be no more.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=4&section=2'>< 4.2 Editing OUs</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=4&section=4'>4.4 Viewing OUs ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 4 && $section == 4) { ?>
        <h3>4.4 Viewing OUs</h3>
        <br />
        Viewing an OU will simply output all of the OUs information in a nice text 
        format, if you couldn't have guessed by now. Just as before, if you notice 
        something that you would like to edit about the OU in which you are currently 
        viewing, then click edit in the tool bar, and you will be on the edit page 
        for that OU. Again, you can use the selection box at the top of the page 
        to view a different OU.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=4&section=3'>< 4.3 Removing OUs</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=5&section=0'>5. System ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 5 && $section == 0) { ?>
        <h3>5. System</h3>
        <br />
        Now onto something a bit more different than users, groups and ous: system 
        settings. Systems settings are not a part of GAM, but they are nice things 
        to be able to control. There are two options, network settings, and system 
        services. As you may see on the home page for systems, there is already 
        a short description for the two options, but we will go into more detail 
        in this manual.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=4&section=4'>< 4.4 Viewing OUs</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=5&section=1'>5.1 Network Settings ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 5 && $section == 1) { ?>
        <h3>5.1 Network Settings</h3>
        <br />
        In network settings you will be able to edit your servers IP address, subnet 
        mask, and gateway address, as well as add up to three domain name servers. 
        Once clicking the submit button, your network will restart in order to 
        let these changes take place. This should not take long and you may not 
        even notice the restart, but it is always safe to wait a second or two to 
        let this take place.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=5&section=0'>< 5. System</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=5&section=2'>5.2 System Services ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 5 && $section == 2) { ?>
        <h3>5.2 System Services</h3>
        <br />
        The system services page has two simple buttons to restart services. They 
        are restart server, and restart apache. These buttons do exactly what you 
        would expect. Clicking restart server will restart your server. So make 
        sure you save any of your current work that is open in other applications 
        on the server. Don't say I didn't warn you. Restarting the server will take 
        a few minutes obviously, so just sit back and relax. The restart apache 
        button restarts the apache server. This is a soft restart, and will take 
        place rather quickly, so you should be fine going forward in WebGAM as soon 
        as you find yourself redirected to the restart confirmation page.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=5&section=1'>< 5.1 Network Settings</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=6&section=0'>6. Security ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 6 && $section == 0) { ?>
        <h3>6. Security</h3>
        <br />
        Now that you have WebGAM setup, you don't want just anybody strolling on 
        in and messing with your Google Apps account do You? During installation 
        you already interacted with the security system by having to login using 
        the default user name admin, and password admin, before editing these values.<br />
        <br />
        If you have not changed the default password at this point do so now. There 
        is no point in having a security system if you don't lock the doors.<br />
        <br />
        The security system has three main functions, managing local WebGAM users 
        managing WebGAM functions, and managing WebGAM user roles.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=5&section=2'>< 5.2 System Services</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=6&section=1'>6.1 Manage WebGAM Users ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 6 && $section == 1) { ?>
        <h3>6.1 Manage WebGAM Users</h3>
        <br />
        There are three functions for handling local WebGAM users; adding, editing, 
        and removing (doesn't that sound familiar). Local WebGAM users are in no 
        way related to any users that you add into Google Apps from the users page.
        These will just be users that can login to your local WebGAM system.<br />
        <br />
        To add a user, simply click the add user link. You will be redirected to 
        a form in which you will be asked to fill out five required fields. First 
        name, last name, and email are not used often, but it is nice to know who 
        your local WebGAM users are, and how to contact them if need be. Username 
        and password however are how the user will log into the local WebGAM system. 
        As WebGAM is initially set up, any new users you add will not have any 
        permissions on WebGAM, so you will need to add those by editing the user.<br />
        <br />
        To edit a user, just click the edit link by the users name, from the manage 
        users page in the security control panel. You will see a similar form as 
        on the add users page, with the addition of being able to add roles to the 
        user. As WebGAM is set up by default, guest will only have the privileges  
        to do anything that anyone not logged into the system could do. So if you 
        want your local user to be able to do anything, then make them an admin, 
        which will allow them to to everything within the scope of WebGAM.<br />
        <br />
        To delete a local user, check the box next to the user you wish to delete 
        from the manager users page, and click delete. You can delete multiple users 
        at a time by selecting multiple users at once before clicking delete.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=6&section=0'>< 6. Security</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=6&section=2'>6.2 Manage WebGAM Functions ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 6 && $section == 2) { ?>
        <h3>6.2 Manage WebGAM Functions</h3>
        <br />
        Functions are the actions that a local WebGAM user can perform. These are 
        more important for WebGAM developers to understand. See the developers guide 
        for more information.<br />
        <br />
        As an admin, you can only view the current functions. This is a safety 
        measure to make sure that only developers have access to functions, because 
        functions are only useful to developers. If you want to know more about 
        functions, see the developers guide.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=6&section=1'>< 6.1 Manage WebGAM Users</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=6&section=3'>6.3 Manage WebGAM Roles ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } else if ($manual == 6 && $section == 3) { ?>
        <h3>6.3 Manage WebGAM Roles</h3>
        <br />
        Roles are the types of users that your local WebGAM system will have. 
        Different roles allow different types of users to have access to different 
        actions (via the functions previously discussed) that a user is authorized 
        to perform.<br />
        <br />
        By default there are three types of users; admins, developers and guests. 
        Guests have the authority of users who aren't logged into the local WebGAM 
        system, which basically means they can't do anything. Admins have authority 
        to do everything within WebGAM, but do not have the authority to add, edit, 
        or delete functions or roles within the security system. Developers have 
        the authority to do everything.<br />
        <br />
        As an admin you do not have the ability to add, edit or delete roles, only 
        view them. If you want to learn more about roles, again, see the developers 
        guide.<br />
        <br />
        Well this concludes the user's guide for WebGAM. If you are still having 
        difficulties understanding the functionality of this tool, then I would 
        advise you to read the full user's manual, which includes more detail, as 
        well as the developers guide, which would help you better understand how 
        WebGAM works.<br />
        <br /><br />
        <div class='manual_left'><a href='../controller/controller.php?action=main&manual=6&section=2'>< 6.2 Manage WebGAM Functions</a></div>
        <div class='manual_right'><a href='../controller/controller.php?action=main&manual=0&section=0'>WebGAM Home Page ></a></div>
        <div id='clearable'></div>
        <br /><br /><br /><br />
    <?php } ?>

</div>

<?php
    $filename = '../view/home/main.php';
    require '../view/includes/footer_include.php';
?>
