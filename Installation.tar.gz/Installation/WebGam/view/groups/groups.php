<?php
    $title = "WebGAM - Groups";
    $folder = "groups";
    require '../view/includes/header_include.php';
?>

<div class="remove_form">
    
    <br /><h1 class=text_center>Groups</h1><br /><br />
        
    <?php 
    $rows = getGroups();
    for ($i = 1; $i < count($rows); $i++){ ?>
        <label class="remove_form_left"><?php echo $rows[$i]; ?></label>
        <input type="hidden" name="Group<?php echo $i; ?>" value="keep"/>
        <a class="form_input" href="./controller.php?action=view_group&groupname=<?php echo $rows[$i]; ?>">view</a>
        <a class="form_input_right" href="./controller.php?action=update_edit_group_form&groupname=<?php echo $rows[$i]; ?>">edit</a>
        <div id="clearable"></div>
    <?php } ?>
    <br /><br />
    
</div>
		
<?php
    $filename = '../view/groups/groups.php';
    require '../view/includes/footer_include.php';
?>