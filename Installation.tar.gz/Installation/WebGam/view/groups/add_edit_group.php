<?php
    if ($mode == "add"){
        $title = "WebGAM - Add Group";
    } else {
        $title = "WebGAM - Edit Group";
    } 
    $folder = "groups";
    require '../view/includes/header_include.php';
?>
    
<div class="form">

    <br />
    <?php if ($mode == "add"){
        echo "<h1 class=\"text_center\">Add Group</h1>";
    } else {
        echo "<h1 class=\"text_center\">Edit Group</h1>";
    } ?>
    <br /><br />
    
    <?php if ($mode == "edit"){ ?>
    <?php $groupname = $_GET['groupname']?>
    <form enctype="multipart/form-data" action="./controller.php?action=update_edit_group_form" method="post" name="UpdateEditGroupForm">
        <label class="form_left">Group Name<span class="required">*</span></label>
        <select id="GroupName" name="GroupName" class="singleselect" onchange="UpdateEditGroupForm.submit();" method="post" tabindex="10">
            <?php 
            $rows = getGroups();
            for ($i = 1; $i < count($rows); $i++){ 
                $split = removeDomain($rows[$i]);
                if ($groupname == $rows[$i]) { echo "<option value=".$rows[$i]." selected>".$split[0]."</option>"; }
                else { echo "<option value=".$rows[$i].">".$split[0]."</option>"; }
            } ?>
        </select>
    </form>
    <?php } ?>
    
    <?php if ($mode == "add"){ ?>
        <form enctype="multipart/form-data" action="./controller.php?action=process_add_group" onsubmit="selectAll('InGroup'); selctAll('NotInGroup');" method="post">
    <?php } else { ?>  
        <form enctype="multipart/form-data" action="./controller.php?action=process_edit_group" onsubmit="selectAll('InGroup'); selectAll('NotInGroup');" method="post">  
        <input type="hidden" id="GroupName" name="GroupName" value="<?php echo $groupname; ?>"/>
    <?php } ?>
    
        <input type="hidden" name="Mode" value="<?php echo $mode; ?>"/>
            
        <?php if ($mode == "add"){ ?>
            <label class="form_left">Group Name<span class="required">*</span></label>
            <input 
                type="text" 
                id="GroupName"                   
                class="form_input"             
                name="GroupName"                 
                title="Enter the name of the Group" 
                pattern="^[a-zA-Z0-9_.+-]+$"
                placeholder="e.g. Nurses"         
                size="32"                       
                maxlength="60"                  
                tabindex="10"                   
                value="<?php echo htmlspecialchars($groupname); ?>"                        
                required                         
            />
        <?php } ?>

<!--        <label class="form_left">Group Email<span class="required">*</span></label>
        <input 
            type="text" 
            id="GroupEmail"                   
            class="form_input"             
            name="GroupEmail"                 
            title="Enter the email of the group" 
            pattern="^[a-zA-Z0-9_.+-]+$"
            placeholder=""         
            size="32"                       
            maxlength="60"                  
            tabindex="20"                   
            value="<?php //$split = removeDomain($groupemail); echo htmlspecialchars($split[0]); ?>"                        
            required                         
        />
        <div id="clearable"></div>
        <br />-->
        <?php if($mode == 'add'){ ?><label>Note: The group name will also be the group email</label><br /> <?php } ?>
        <br />
        
        <label class="form_left">Group Description</label>
        <input 
            type="text" 
            id="GroupDescription"                   
            class="form_input"             
            name="GroupDescription"                 
            title="Enter the description of the group"  
            placeholder=""         
            size="32"                       
            maxlength="128"                  
            tabindex="30"                   
            value="<?php echo htmlspecialchars($groupdescription); ?>"
            <?php if ($groupdescription != '') { echo "required"; } ?>
        />
        
        <input type="hidden" name="OldAlias" id="OldAlias" value="<?php echo htmlspecialchars($groupalias); ?>"/>
        <label class="form_left">Alias</label>
        <input 
            type="text" 
            id="GroupAlias"                   
            class="form_input"             
            name="GroupAlias"                 
            title="Enter the group alias"   
            pattern="^[a-zA-Z0-9_.+-]+$"
            placeholder="e.g. aliasEmail"         
            size="32"                       
            maxlength="60"                  
            tabindex="50"                   
            value="<?php echo htmlspecialchars($groupalias); ?>" 
            <?php if ($groupalias != '') { echo "required"; } ?>
        /><br /><br /> 

        <input type="hidden" name="GroupAliasDomain" id="GroupAliasDomain" value="<?php $domain = getDomain(); echo htmlspecialchars($domain); ?>"/>
        <br />        

        <label class="form_left">Group Members</label><br /><br />
        <table><tr>
            <td>
                Users In Group<br/>
                <select id="InGroup" name="InGroup[]" size="10" class="selector" multiple="multiple">
                    <?php
                        if ($mode == 'edit') {
                            $sets = getGroupMembers($groupname); //get the group members
                            for ($i = 0; $i < count($sets[0]); $i++){
                                echo '<option value="'.$sets[0][$i].'">'.$sets[0][$i].'</option>';
                            }
                        }
                    ?>
                </select>                
            </td>

            <td>
                <input type="button" value=">>" onclick="swap('InGroup','NotInGroup')"><br/>
                <br/>
                <input type="button" value="<<" onclick="swap('NotInGroup','InGroup')"><br/>
            </td>

            <td>
            Users Not In Group<br/>
            <select id="NotInGroup" name="NotInGroup[]" size="10" class="selector" multiple="multiple">
                <?php 
                    $rows = getUsers();
                    for ($i = 1; $i < count($rows); $i++){
                        if ($mode == 'add') { echo "<option value=".$rows[$i].">".$rows[$i]."</option>"; }
                    }
                    if ($mode == 'edit') {
                        $sets = getGroupMembers($groupname); //get the group members
                        for ($i = 0; $i < count($sets[1]); $i++){
                            echo '<option value="'.$sets[1][$i].'">'.$sets[1][$i].'</option>';
                        }
                    }
                ?>
            </select>                
            </td>
        </tr></table>
        <br/>
        
        <input
            type="submit"
            id="SubmitForm"
            class="submit_button"
            name="SubmitForm"
            title="Submit the form"	
	    value="Submit"
            tabindex="50"
            required   
        />
        
        <br /><br />
        
    </form>
	
</div>
    
<script>
    <?php
        if (!empty($errors)){
            echo "alert(\"Please correct the following errors:\\n$errors\");";
        }
    ?>
</script>
    
<?php
    $filename = '../view/groups/add_edit_group.php';
    require '../view/includes/footer_include.php';
?>
