<?php
    $title = "WebGAM - View Group";
    $folder = "groups";
    require '../view/includes/header_include.php';
?>

<div class="form">

    <br /><h1 class="text_center">View Group</h1><br /><br />
    
    <label class="form_left">Group Name</label>
    <?php $groupname = $_GET['groupname']?>
    <form enctype="multipart/form-data" action="./controller.php?action=view_group" method="post" name="ChangeGroupForm">
        <select id="SelectGroupName" class="singleselect" name="SelectGroupName" onchange="ChangeGroupForm.submit();" method="post" tabindex="10">
            <?php 
            $rows = getGroups();
            for ($i = 1; $i < count($rows); $i++){
                $split = removeDomain($rows[$i]);
                if ($groupname == $rows[$i]) { echo "<option value=".$rows[$i]." selected>".$split[0]."</option>"; }
                else { echo "<option value=".$rows[$i].">".$split[0]."</option>"; }
            }?>
        </select>
    </form>

    <label class="form_left">Group Email</label>
    <label class="form_input"><?php echo $groupemail; ?></label>
    <div id="clearable"></div><br />
    
    <label class="form_left">Description</label>
    <textarea class="form_input" rows="2" cols="32" disabled><?php echo $groupdescription; ?></textarea>
    
    <label class="form_left">Alias</label>
    <label class="form_input"><?php echo $groupalias; ?></label>
    <div id="clearable"></div>
    
    <label class="form_left">Alias Domain</label>
    <label class="form_input"><?php echo $groupaliasdomain; ?></label>
    <div id="clearable"></div><br />
    
    <label class="form_left">Group Members</label>
    <select id="GroupMembers" name="GroupMembers[]" size="10" class="form_input selector" multiple="multiple">
        <?php 
            //only add the users who are in the group
            $sets = getGroupMembers($groupname);
            for ($i = 0; $i < count($sets[0]); $i++){
                echo '<option value="'.$sets[0][$i].'">'.$sets[0][$i].'</option>';
            }
        ?>
    </select> 
    
</div>            

<?php
    $filename = '../view/groups/view_group.php';
    require '../view/includes/footer_include.php';
?>
