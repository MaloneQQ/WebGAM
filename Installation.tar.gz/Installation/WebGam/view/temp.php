<?php
    $title = "WebGAM - ";
    $folder = "";
    require '../view/includes/header_include.php';
?>

<?php require '../view/includes/construction_include.php'; ?>
		
<?php
    $filename = '../view/folder_in_view/file_name.php';
    require '../view/includes/footer_include.php';
?>
