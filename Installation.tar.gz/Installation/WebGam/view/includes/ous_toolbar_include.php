<nav>
    <ul><li><a href="../controller/controller.php?action=add_ou">Add</a></li></ul> 
        <ul><li><a href="../controller/controller.php?action=update_edit_ou_form&ouname=<?php echo $ouname; ?>">Edit</a></li></ul>
        <ul><li><a href="../controller/controller.php?action=remove_ou">Remove</a></li></ul>
        <ul><li><a href="../controller/controller.php?action=view_ou&ouname=<?php echo $ouname; ?>">View</a></li></ul>
    <ul><li></li></ul>
</nav>	