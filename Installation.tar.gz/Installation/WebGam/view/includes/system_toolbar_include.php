<nav>
    <ul><li><a href="../controller/controller.php?action=networking">Networking</a></li></ul> 
    <ul><li><a href="../controller/controller.php?action=systems">System</a></li></ul>
    <ul><li></li></ul>
</nav>	