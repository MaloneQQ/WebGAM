<?php 
    $tab = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
?>

<a href='../controller/controller.php?action=main&manual=1&section=0'>1. Introduction</a><br />
<a href='../controller/controller.php?action=main&manual=2&section=0'>2. Users</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=2&section=1'>2.1 Adding Users</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=2&section=2'>2.2 Editing Users</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=2&section=3'>2.3 Removing Users</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=2&section=4'>2.4 Viewing Users</a><br />
<a href='../controller/controller.php?action=main&manual=3&section=0'>3. Groups</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=3&section=1'>3.1 Adding Groups</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=3&section=2'>3.2 Editing Groups</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=3&section=3'>3.3 Removing Groups</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=3&section=4'>3.4 Viewing Groups</a><br />
<a href='../controller/controller.php?action=main&manual=4&section=0'>4. OUs</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=4&section=1'>4.1 Adding OUs</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=4&section=2'>4.2 Editing OUs</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=4&section=3'>4.3 Removing OUs</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=4&section=4'>4.4 Viewing OUs</a><br />
<a href='../controller/controller.php?action=main&manual=5&section=0'>5. System</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=5&section=1'>5.1 Network Settings</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=5&section=2'>5.2 System Services</a><br />
<a href='../controller/controller.php?action=main&manual=6&section=0'>6. Security</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=6&section=1'>6.1 Manage WebGAM Users</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=6&section=2'>6.2 Manage WebGAM Functions</a><br />
<?php echo $tab; ?><a href='../controller/controller.php?action=main&manual=6&section=3'>6.3 Manage WebGAM Roles</a><br />
<br />
<br />