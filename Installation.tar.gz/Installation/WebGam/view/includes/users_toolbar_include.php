<nav>
    <ul><li><a href="../controller/controller.php?action=add_user">Add</a></li></ul> 
    <ul><li><a href="../controller/controller.php?action=update_edit_user_form&username=<?php echo $username; ?>">Edit</a></li></ul>
    <ul><li><a href="../controller/controller.php?action=remove_user">Remove</a></li></ul>
    <ul><li><a href="../controller/controller.php?action=view_user&username=<?php echo $username; ?>">View</a></li></ul>
    <ul><li></li></ul>
</nav>		

		
	