<nav>
    <ul><li><a href="../controller/controller.php?action=add_group">Add</a></li></ul> 
    <ul><li><a href="../controller/controller.php?action=update_edit_group_form&groupname=<?php echo $groupname; ?>">Edit</a></li></ul>
    <ul><li><a href="../controller/controller.php?action=remove_group">Remove</a></li></ul>
    <ul><li><a href="../controller/controller.php?action=view_group&groupname=<?php echo $groupname; ?>">View</a></li></ul>
    <ul><li></li></ul>
</nav>	