<!DOCTYPE html>

<html lang="en">
  
<head>
    <meta charset="utf-8" />
    <title><?php echo $title; ?></title>
    <link rel="stylesheet" href="../css/main.css">
    <link rel="shortcut icon" href="../images/favicon.ico" />
    <script src="../js/jquery-2.1.3.min.js"></script>
    <script src="../js/main.js"></script>
</head>

<body>
    <div class="wrapper">
        <div class="sidebar">
            <nav>
                <a href="../controller/controller.php?action=main"><div class="company_image"><image src="../images/CompanyImage.png" style="height: 100px;" alt=""/></div></a>
                <?php 
                    if (!isset($username)) {
                        $temp = getUsers();
                        $username = $temp[1];
                    }
                    if (!isset($groupname)) {
                        $temp = getGroups();
                        $groupname = $temp[1];
                    }
                    if (!isset($ouname)) {
                        $temp = getOUs();
                        $ouname = $temp[1];
                    }
                ?>
                <ul><li><a href="../controller/controller.php?action=users&username=<?php echo $username; ?>">Users</a></li></ul> 
                <br/>
                <ul><li><a href="../controller/controller.php?action=groups&groupname=<?php echo $groupname; ?>">Groups</a></li></ul> 
                <br/>
                <ul><li><a href="../controller/controller.php?action=ous&ouname=<?php echo $ouname; ?>">OUs</a></li></ul> 
                <br/>
                <!--<ul><li><a href="../controller/controller.php?action=contacts">Contacts</a></li></ul> 
                <br/>-->
                <ul><li><a href="../controller/controller.php?action=system">System</a></li></ul> 
                <br/>
                <ul><li><a href="../security/index.php">Security</a></li></ul> 
                <br/>
            </nav>
        </div>

        <div class="main">
            <div class="back_bar"></div>
            <div class="toolbar">
                <?php 
                    //depending on what we are working with, select the appropriate toolbar
                    if ($folder == "users") { require '../view/includes/users_toolbar_include.php'; }
                    else if ($folder == "groups") { require '../view/includes/groups_toolbar_include.php'; }
                    else if ($folder == "ous") { require '../view/includes/ous_toolbar_include.php'; }
                    else if ($folder == "system") { require '../view/includes/system_toolbar_include.php'; }
                    else if ($folder == "security") { require '../view/includes/security_toolbar_include.php'; }
                ?>	
            </div>
            <div class="login_bar">
                <?php $tab = "&nbsp;&nbsp;&nbsp;&nbsp;"; ?>
                <?php if (!loggedIn()) { ?>
                    <a href="../security/index.php?action=SecurityLogin&RequestedPage=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>">Login</a><?php echo $tab.$tab; ?>
                <?php } else { ?>
                    <?php echo $_SESSION['UserName'].$tab; ?>
                    <a href="../security/index.php?action=SecurityLogOut&RequestedPage=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>">Log out</a>
                    <?php echo $tab.$tab; ?>
                <?php } ?>
            </div>
            
            <section id="content">
            

       
        
