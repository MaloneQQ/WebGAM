
<nav>
<?php if (userIsAuthorized("SecurityManageUsers")) {  ?>
        <ul><li><a href="../security/index.php?action=SecurityManageUsers">Users</a></li></ul>
<?php } 
    if (userIsAuthorized("SecurityManageFunctions")) {  ?>
       <ul><li><a href="../security/index.php?action=SecurityManageFunctions">Functions</a></li></ul>
<?php } 
    if (userIsAuthorized("SecurityManageRoles")) {  ?>
        <ul><li><a href="../security/index.php?action=SecurityManageRoles">Roles</a></li></ul>
<?php }
    if (loggedIn()) {  ?>
        <ul><li><a href="../security/index.php?action=SecurityLogOut">Log Out</a></li></ul>
<?php } else { 
        echo "<ul><li><a href=\"../security/index.php?action=SecurityLogin&RequestedPage=" . urlencode($_SERVER['REQUEST_URI']) . "\">Log In</a></li></ul>";
} ?>
    <ul><li></li></ul>
</nav>	