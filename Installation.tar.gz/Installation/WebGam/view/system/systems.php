<?php
    $title = "WebGAM - System Settings";
    $folder = "system";
    require '../view/includes/header_include.php';
?>

<div class="small_form">

    <?php if ($restarting) { ?>
    <br /><h1 class="text_center">Restarting System Service</h1>
    <br /><br />
    <div>*This is a cached page. Please wait for the service to restart.</div><br />
    <div>*An Apache restart should only take a few seconds.</div><br />
    <div>*A server restart will take a few minutes. Please wait a few minutes before continuing use of WebGAM.</div><br />
    <?php } else {?>
    
    <br /><h1 class="text_center">Restart System Services</h1>
    <br /><br />
    
    <label class="small_form_left">Restart Server</label>
    <form enctype="multipart/form-data" action="./controller.php?action=restart_server" method="post" name="RestartServer">
        <input
            type="submit"
            id="SubmitServer"
            class="small_submit"
            name="SubmitForm"
            title="Submit the form"	
	    value="Restart Server"
            tabindex="220"
            required   
        />  
    </form><div id="clearable"></div><br />
    
    <label class="small_form_left">Restart Apache</label>
    <form enctype="multipart/form-data" action="./controller.php?action=restart_apache" method="post" name="RestartApache">
        <input
            type="submit"
            id="SubmitApache"
            class="small_submit"
            name="SubmitForm"
            title="Submit the form"	
	    value="Restart Apache"
            tabindex="220"
            required   
        /> 
    </form><div id="clearable"></div><br /><br />
    <?php } ?>
</div>

<?php
    $filename = '../view/system/systems.php';
    require '../view/includes/footer_include.php';
?>