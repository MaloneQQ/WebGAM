
<?php
    $title = "WebGAM - Networking"; 
    $folder = "system";
    require '../view/includes/header_include.php';
?>

<div class="form">
    <br />
    <h1 class="text_center">Edit Network Settings</h1><br /><br />

    <form enctype="multipart/form-data" action="./controller.php?action=process_networking" method="post">

        <label class="form_left">Address</label>
        <input 
            type="text" 
            id="Address"                   
            class="form_input"             
            name="Address"                 
            title="Enter a valid IP address" 
            pattern="((^|\.)((25[0-5])|(2[0-4]\d)|(1\d\d)|([1-9]?\d))){4}$"
            placeholder="e.g. 192.123.45.6"         
            size="32"                       
            maxlength="15"     
            autofocus="true"
            tabindex="10"                   
            value=""                                                
        /><br />

        <label class="form_left">Netmask</label>
        <input 
            type="text" 
            id="Netmask"                   
            class="form_input"             
            name="Netmask"                 
            title="Enter a valid netmask address" 
            pattern="((^|\.)((25[0-5])|(2[0-4]\d)|(1\d\d)|([1-9]?\d))){4}$"
            placeholder="e.g. 255.255.255.0"         
            size="32"    
            maxlength="15" 
            tabindex="20"                   
            value=""                                                
        /><br />

        <label class="form_left">Gateway</label>
        <input 
            type="text" 
            id="Gateway"                   
            class="form_input"             
            name="Gateway"                 
            title="Enter a valid gateway address" 
            pattern="((^|\.)((25[0-5])|(2[0-4]\d)|(1\d\d)|([1-9]?\d))){4}$"
            placeholder="e.g. 192.321.54.6"         
            size="32"    
            maxlength="15" 
            tabindex="30"                   
            value=""                                                
        /><br /><br />

        <label class="form_left">DNS 1</label>
        <input 
            type="text" 
            id="DNS1"                   
            class="form_input"             
            name="DNS1"                 
            title="Enter a valid DNS address" 
            pattern="((^|\.)((25[0-5])|(2[0-4]\d)|(1\d\d)|([1-9]?\d))){4}$"
            placeholder="e.g. 15.8.45.6"         
            size="32"    
            maxlength="15" 
            tabindex="40"                   
            value=""                                                
        /><br />

        <label class="form_left">DNS 2</label>
        <input 
            type="text" 
            id="DNS2"                   
            class="form_input"             
            name="DNS2"                 
            title="Enter a valid DNS address" 
            pattern="((^|\.)((25[0-5])|(2[0-4]\d)|(1\d\d)|([1-9]?\d))){4}$"
            placeholder="e.g. 15.8.45.7"         
            size="32"    
            maxlength="15" 
            tabindex="50"                   
            value=""                                                
        /><br />

        <label class="form_left">DNS 3</label>
        <input 
            type="text" 
            id="DNS3"                   
            class="form_input"             
            name="DNS3"                 
            title="Enter a valid DNS address" 
            pattern="((^|\.)((25[0-5])|(2[0-4]\d)|(1\d\d)|([1-9]?\d))){4}$"
            placeholder="e.g. 15.8.45.8"         
            size="32"    
            maxlength="15" 
            tabindex="60"                   
            value=""                                                
        /><br />

        <br /> 
        <input
            type="submit"
            id="SubmitForm"
            class="submit_button"
            name="SubmitForm"
            title="Submit the form"	
	    value="Submit"
            tabindex="220"
            required   
        />

    </form>
    <br /><br />

<script>
    <?php
        if (!empty($errors)){
            echo "alert(\"Please correct the following errors:\\n$errors\");";
        }
    ?>
</script>

<?php
    $filename = '../view/system/networking.php';
    require '../view/includes/footer_include.php';
?>
