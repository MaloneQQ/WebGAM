<?php
    $title = "WebGAM - System";
    $folder = "system";
    require '../view/includes/header_include.php';
?>

<br />
<h1 class="text_center">System Settings</h1>
<br /><br />
<div class="remove_form">
    Select an option from the tool bar to edit system settings.<br /><br /> Edit network 
    settings, including the IP address, gateway, subnet mask, and DNS, by 
    selecting the networking option.<br /><br /> Restart the server and the apache server 
    by selecting system.
</div>
		
<?php
    $filename = '../view/system/system.php';
    require '../view/includes/footer_include.php';
?>