<?php
    if ($mode == "add"){
        $title = "WebGAM - Add User";
    } else {
        $title = "WebGAM - Edit User";
    }  
    $folder = "users";
    require '../view/includes/header_include.php';
?>

<div class="form">
    <br />
    <?php if ($mode == "add"){
        echo "<h1 class=\"text_center\">Add User</h1>";
    } else {
        echo "<h1 class=\"text_center\">Edit User</h1>";
    } ?>
    <br /><br />
    
    <?php if ($mode == "edit"){ ?>
        <?php $username = $_GET['username']?>
        <form enctype="multipart/form-data" action="./controller.php?action=update_edit_user_form" method="post" name="UpdateEditUserForm">
            <label class="form_left">User Name<span class="required">*</span></label>
            <select id="UserName" name="UserName" onchange="UpdateEditUserForm.submit();" method="post">
                <?php 
                    $rows = getUsers();
                    for ($i = 1; $i < count($rows); $i++){
                    if ($username == $rows[$i]) { echo "<option value=".$rows[$i]." selected>".$rows[$i]."</option>"; }
                    else { echo "<option value=".$rows[$i].">".$rows[$i]."</option>"; }
                }?>
            </select>
        </form>
    <?php } ?>
    
    <!--<form enctype="multipart/form-data" action="./controller.php?action=process_add_user" onsubmit="return confirm('Are you sure you want to submit?');" method="post">-->
    <?php if ($mode == "add"){ ?>
        <form enctype="multipart/form-data" action="./controller.php?action=process_add_user" method="post">
    <?php } else { ?>  
        <form enctype="multipart/form-data" action="./controller.php?action=process_edit_user" method="post">  
        <input type="hidden" id="UserName" name="UserName" value="<?php echo $username; ?>"/>
    <?php } ?>
        
        <input type="hidden" name="Mode" value="<?php echo $mode; ?>"/>
        
        <?php if ($mode == "add") { ?>
            <label class="form_left">User Name<span class="required">*</span></label>
            <input 
                type="text" 
                id="UserName"                   
                class="form_input"             
                name="UserName"                 
                title="Enter the user name using letters, numbers, _, -, +, ', and non-consecutive .'s" 
                pattern="^[a-zA-Z0-9_.+-]+$"
                placeholder="e.g. johnsmith"         
                size="32"                       
                maxlength="128"     
                autofocus="true"
                tabindex="9"                   
                value="<?php echo htmlspecialchars($username); ?>"                        
                required                         
            /><br />
        <?php }?>

        <label class="form_left">First Name</label>
        <input 
            type="text" 
            id="FirstName"                   
            class="form_input"             
            name="FirstName"                 
            title="Enter the users first name" 
            placeholder="e.g. John"         
            size="32"                       
            maxlength="60"                  
            tabindex="10"                   
            value="<?php echo htmlspecialchars($firstname); ?>"    
            <?php if ($firstname != '') { echo "required"; } ?>
        /><br />
        <label class="form_left">Last Name</label>
        <input 
            type="text" 
            id="LastName"                   
            class="form_input"             
            name="LastName"                 
            title="Enter the users last name" 
            placeholder="e.g. Smith"         
            size="32"                       
            maxlength="60"                  
            tabindex="30"                   
            value="<?php echo htmlspecialchars($lastname); ?>"  
            <?php if ($lastname != '') { echo "required"; } ?>
        /><br /><br />

        <?php if($mode == "add") { ?>
            <label class="form_left">Password<span class="required">*</span></label>
            <input 
                type="password" 
                id="Password"                   
                class="form_input"             
                name="Password"                 
                title="Enter the users password" 
                placeholder=""         
                size="32"  
                minlength="8"
                maxlength="100"                  
                tabindex="40"                   
                value="<?php echo htmlspecialchars($password); ?>" 
                required
            /><br />

            <label class="form_left">Verify Password<span class="required">*</span></label>
            <input 
                type="password" 
                id="VerifyPassword"                   
                class="form_input"             
                name="VerifyPassword"                 
                title="Re-Enter the users password" 
                placeholder=""         
                size="32"                       
                minlength="8"
                maxlength="100"                 
                tabindex="50"                   
                value="<?php echo htmlspecialchars($verifypassword); ?>"      
                required
            /><br /><br />
        <?php } ?>

        <?php if ($mode == 'edit') { ?>
            <label class="form_left">Current User Image</label>
            <?php if (file_exists('../data_files/pictures/'.$username.'.png')) {  ?>
            <div class="form_input"><img src="../data_files/pictures/<?php echo $username; ?>.png" alt="Error displaying image." height="250" width="250" /></div>
            <?php } else { ?><label class="form_input">No image has been uploaded</label><?php }?>
            <div id="clearable"></div><br />
        <?php } ?>
            
        <label class="form_left">Upload User Image</label>
        <input 
            type="file"
            id="UserImage" 
            class="form_input" 
            name="UserImage" 
            title="Upload an image for the user" 
            tabindex="210"
        />
        <input type="hidden" name="UploadType" value="ImageFile">
        <br /><br />
            
        <label class="form_left">Suspended</label>
        <input type="hidden" name ="Suspended" value = "off"/>
        <input
            type="checkbox" 
            id="Suspended"                   
            class="form_input"             
            name="Suspended"  
            tabindex="60"                
            value="on"
            <?php if($suspended == 'True') { echo 'checked'; } ?>
        /><br />
        <div id="clearable"></div>

        <label class="form_left">Change Password Next Login</label>
        <input type="hidden" name ="ChangePassword" value = "off"/>
        <input
            type="checkbox" 
            id="ChangePassword"                   
            class="form_input"             
            name="ChangePassword"                                 
            tabindex="70"                
            value="on" 
            <?php if($changepassword == 'True') { echo 'checked'; } ?>
        /><br />
        
        <label class="form_left">Global Address List</label>
        <input type="hidden" name ="AddUserGlobal" value = "off"/>
        <input
            type="checkbox" 
            id="AddUserGlobal"                   
            class="form_input"             
            name="AddUserGlobal"                                 
            tabindex="80"                
            value="on"   
            <?php if($adduserglobal == 'True') { echo 'checked'; } ?>
        /><br />

        <label class="form_left">Admin</label>
        <input type="hidden" name ="SetAdmin" value = "off"/>
        <input
            type="checkbox" 
            id="SetAdmin"                   
            class="form_input"             
            name="SetAdmin"                                 
            tabindex="90"                
            value="on"    
            <?php if($admin == 'True') { echo 'checked'; } ?>
        /><br /><br />

        <label class="form_left">Organizational Unit</label>
        <select id="OU" name="OU" tabindex="100">
            <option value="/" selected>-- None --</option>
            <?php 
                $fullou = "/".$ou;
                $rows = getOUs();
                $parents = array();
                for ($i = 1; $i < count($rows); $i++){
                    $ouread = getOUInfo($rows[$i]);
                    $parents[$i-1] = $ouread[3]; //get the current ou parentfrom the array of ous
                }
                for ($i = 0; $i < count($parents); $i++){
                    if ($fullou == $parents[$i]) { echo "<option value=\"".$fullou."\" selected>".$fullou."</option>"; }
                    else { echo "<option value=\"".$parents[$i]."\">".$parents[$i]."</option>"; }
                }
            ?>
        </select><br /><br />

        <label class="spoiler" onclick="if(document.getElementById('CompanyInfoSpoiler').style.display=='none') {
            document.getElementById('CompanyInfoSpoiler').style.display='' }
            else { document.getElementById('CompanyInfoSpoiler').style.display='none' } ">Company Information</label>
        <div id="clearable"></div><br />
        
        <?php if($mode == 'add'){ ?> <div id="CompanyInfoSpoiler" style="display:none">
        <?php } else { ?> <div id="CompanyInfoSpoiler" style="display:"> <?php } ?>
            <label class="form_left">Company</label>
            <input 
                type="text" 
                id="Organization"                   
                class="form_input"             
                name="Organization"                 
                title="Enter The Users Organization"   
                placeholder="e.g. Tool Testing"         
                size="32"                       
                maxlength="128"                  
                tabindex="102"                   
                value="<?php echo htmlspecialchars($company); ?>"     
                <?php if ($company != '') { echo "required"; } ?>
            /><br />

            <!--<label class="form_left">Organization Type</label>
            <select id="OrganizationType" name="OrganizationType" tabindex="107">
                <option value="domain_only">Domain Only</option>
                <option value="school">School</option>
                <option value="unknown">Unknown</option>
                <option value="work">Work</option>
            </select><br />-->
            <input type="hidden" id="OrganizationType" name="OrganizationType" value="work" tabindex="107" />

            <label class="form_left">Title</label>
            <input 
                type="text" 
                id="UserTitle"                   
                class="form_input"             
                name="UserTitle"                 
                title="Enter The Users Title"   
                placeholder="e.g. Group Manager"         
                size="32"                       
                maxlength="128"                  
                tabindex="110"                   
                value="<?php echo htmlspecialchars($usertitle); ?>"     
                <?php if ($usertitle != '') { echo "required"; } ?>
            /><br />

            <label class="form_left">Department</label>
            <input 
                type="text" 
                id="Department"                   
                class="form_input"             
                name="Department"                 
                title="Enter The Users Department"   
                placeholder="e.g. Accounting"         
                size="32"                       
                maxlength="128"                  
                tabindex="120"                   
                value="<?php echo htmlspecialchars($department); ?>" 
                <?php if ($department != '') { echo "required"; } ?>
            /><br />

            <!--
            populate from list of users, not including the current user (if in edit mode)
            -->
            <input type="hidden" name="OldManager" id="OldManager" value="<?php echo $oldmanager; ?>"/>
            
            <label class="form_left">Manager</label>
            <select id="Manager" name="Manager" tabindex="210">
                <option value="none" class="noneSelect" selected>-- None --</option>
                <?php 
                    $rows = getUsers();
                    for ($i = 1; $i < count($rows); $i++){
                        //echo "<option value=".$rows[$i].">".$rows[$i]."</option>";
                        
                        echo "<option value=".$rows[$i];
                        if ($mode == 'edit' && $manager == $rows[$i]) { echo " selected"; }
                        echo ">".$rows[$i]."</option>";
                    }
                ?>
            </select><br />

            <!--
            <label class="form_left">Primary Organization</label>
            <input type="hidden" id="PrimaryOrganization" name="PrimaryOrganization" value="0"/>
            <input 
                type="radio" 
                id="PrimaryOrganization"                   
                class="form_input"             
                name="PrimaryOrganization"                                 
                tabindex="103"                
                value="0" 
                checked
            /><br /><div id="clearable"></div>

            <input type="hidden" id="OrganizationCount" name="OrganizationCount"/>

            <div id="NewOrganizationContainer"></div>
            <div class="form_left"><input value="Add Organization" id="NewOrganization" type="button"  onClick="addOrganization()"></div>
            <div class="form_input"><input value="Remove Organization" id="DeleteOrganization" type="button"  onClick="removeOrganization()"></div>
            <div id="clearable"></div><br />
            -->
        </div><br />
        
<script>
   
    /*var organizationCount = 1;
    var organizationTypeID = 'NewOrganization'.concat(organizationCount);

    function addOrganization(){      
        var newOrganization = 
            '<div id="NewOrganization' + organizationCount + '"><br />'+
                '<label class="form_left">Organization</label>'+
                '<input '+ 
                    'type="text"'+ 
                    'id="Organization' + organizationCount + '"'+                   
                    'class="form_input"'+             
                    'name="Organization' + organizationCount + '"'+                 
                    'title="Enter The Users Organization"'+   
                    'placeholder="e.g. Tool Testing"'+         
                    'size="32"'+                       
                    'maxlength="128"'+                  
                    'tabindex="102"'+                   
                    'value=""'+                        
                '/><br />'+
                '<input type="hidden" id="OrganizationType' + organizationCount + '" name="OrganizationType' + organizationCount + '" value="work" tabindex="107" />'+
                '<label class="form_left">Title</label>'+
                '<input '+ 
                    'type="text"'+ 
                    'id="UserTitle' + organizationCount + '"'+                   
                    'class="form_input"'+             
                    'name="UserTitle' + organizationCount + '"'+                 
                    'title="Enter The Users Title"'+   
                    'placeholder="e.g. Group Manager"'+         
                    'size="32"'+                       
                    'maxlength="128"'+                  
                    'tabindex="110"'+                  
                    'value=""'+                        
                '/><br />'+
                '<label class="form_left">Department</label>'+
                '<input '+ 
                    'type="text"'+ 
                    'id="Department' + organizationCount + '"'+                   
                    'class="form_input"'+             
                    'name="Department' + organizationCount + '"'+                 
                    'title="Enter The Users Department"'+   
                    'placeholder="e.g. Accounting"'+         
                    'size="32"'+                       
                    'maxlength="128"'+                  
                    'tabindex="120"'+                   
                    'value=""'+                        
                '/><br />'+
                '<label class="form_left">Primary Organization</label>'+
                '<input '+ 
                    'type="radio"'+ 
                    'id="PrimaryOrganization"'+                   
                    'class="form_input"'+             
                    'name="PrimaryOrganization"'+                                 
                    'tabindex="103"'+                
                    'value="' + organizationCount + '"'+ 
                '/><br /><div id="clearable"></div>'+
            '</div>';
    
        var organizationLimit = <?php //echo $organizationLimit; ?>;
        if (organizationCount < organizationLimit){
            var title = document.getElementById('NewOrganization').value;
            var node = document.createElement('div');        
            node.innerHTML = newOrganization;       
            document.getElementById('NewOrganizationContainer').appendChild(node); 
            document.getElementById('OrganizationCount').value = organizationCount; 
        }
        
        organizationCount++; 
    }
    
    function removeOrganization(){        
        if (organizationCount > 1){
            organizationCount--;
            organizationTypeID = 'NewOrganization'.concat(organizationCount);
            var elementToRemove = document.getElementById(organizationTypeID);
            elementToRemove.remove();
            document.getElementById('OrganizationCount').value = organizationCount;
        }  
    }*/
    
</script>
        
        <label class="spoiler" onclick="if(document.getElementById('AddressSpoiler').style.display=='none') {
            document.getElementById('AddressSpoiler').style.display='' }
            else { document.getElementById('AddressSpoiler').style.display='none' } ">Addresses</label>
        <div id="clearable"></div><br />

        <?php if($mode == 'add'){ ?> <div id="AddressSpoiler" style="display:none">
        <?php } else { ?> <div id="AddressSpoiler" style="display:"> <?php } ?>
            <label class="form_left">Address 1</label><div id="clearable"></div>
            <label class="form_left">Address Type</label>
            <select id="AddressType" name="AddressType" tabindex="130">
                <?php if ($mode == 'add') { $default = 'home'; } else { $default = strtolower($addresstype); } ?>
                <option value = "home" <?php if ($default == 'home') { echo 'selected'; } ?>>Home</option>
                <option value = "work" <?php if ($default == 'work') { echo 'selected'; } ?>>Work</option>
                <option value = "custom" <?php if ($default == 'custom') { echo 'selected'; } ?>>Custom</option>
                <option value = "other" <?php if ($default == 'other') { echo 'selected'; } ?>>Other</option>
            </select><br />

            <label class="form_left">Street Address</label>
            <input 
                type="text" 
                id="StreetAddress"                   
                class="form_input"             
                name="StreetAddress"                 
                title="Enter The Users Street Address" 
                placeholder="e.g. 12345 Ocean Way; Palms, Florida"         
                size="32"                       
                maxlength="128"                  
                tabindex="140"                   
                value="<?php echo htmlspecialchars($streetaddress); ?>"    
                <?php if ($streetaddress != '') { echo "required"; } ?>
            /><br />

            <label class="form_left">Zip Code</label>
            <input 
                type="text" 
                id="Zip"                   
                class="form_input"             
                name="Zip"                 
                title="Enter The Users Zip Code. Include '-' for full code" 
                pattern="\d{5}([\-]\d{4})?" 
                placeholder="e.g. 12345-6789"         
                size="32"                       
                maxlength="10"                  
                tabindex="150"                   
                value="<?php echo htmlspecialchars($zip); ?>"  
                <?php if ($zip != '') { echo "required"; } ?>
            /><br />

            <label class="form_left">Country</label>
            <select id="Country" name="Country" tabindex="160">
                <?php 
                    $rows = getCountryCodes();
                    if ($mode == 'add') { $default = 'United States'; } else { $default = $country; }
                    for ($i = 1; $i < count($rows); $i++){
                        if ($rows[$i][0] == $default) { echo "<option value=".$rows[$i][1]." selected>".$rows[$i][0]."</option>"; }
                        else { echo "<option value=".$rows[$i][1].">".$rows[$i][0]."</option>"; }
                    }
                ?>   
            </select><br />

            <label class="form_left">Primary Address</label>
            <input type="hidden" id="PrimaryAddress" name="PrimaryAddress" value="0"/>
            <input 
                type="radio" 
                id="PrimaryAddress"                   
                class="form_input"             
                name="PrimaryAddress"                                 
                tabindex="165"                
                value="0"
                checked
            /><br />

            <?php if($mode == 'edit') { for ($i = 1; $i <= $addresscount; $i++) { ?>
                <div id="NewAddress<?php echo $i; ?>"><br />
                    <label class="form_left">Address <?php echo ($i + 1); ?></label><div id="clearable"></div>
                    <label class="form_left">Address Type</label>
                    <select id="AddressType<?php echo $i; ?>" name="AddressType<?php echo $i; ?>" tabindex="130">
                        <option value = "home"<?php if(strtolower($extraaddresses[$i][0]) == 'home') { echo 'selected'; } ?>>Home</option>
                        <option value = "work"<?php if(strtolower($extraaddresses[$i][0]) == 'work') { echo 'selected'; } ?>>Work</option>
                        <option value = "custom"<?php if(strtolower($extraaddresses[$i][0]) == 'custom') { echo 'selected'; } ?>>Custom</option>
                        <option value = "other"<?php if(strtolower($extraaddresses[$i][0]) == 'other') { echo 'selected'; } ?>>Other</option>
                    </select><br />

                    <label class="form_left">Street Address</label>
                    <input 
                        type="text" 
                        id="StreetAddress<?php echo $i; ?>"                   
                        class="form_input"             
                        name="StreetAddress<?php echo $i; ?>"                 
                        title="Enter The Users Street Address" 
                        placeholder="e.g. 12345 Ocean Way; Palms, Florida"         
                        size="32"                       
                        maxlength="128"                  
                        tabindex="140"                   
                        value="<?php if ($extraaddresses[$i][2] != '') { echo htmlspecialchars($extraaddresses[$i][2]); }
                                else if ($extraaddresses[$i][1] != '') { echo htmlspecialchars($extraaddresses[$i][1]); }
                                else { echo ''; } ?>" 
                        <?php if ($extraaddresses[$i][2] != '' || $extraaddresses[$i][1] != '') { echo "required"; } ?>
                    /><br />

                    <label class="form_left">Zip Code</label>
                    <input 
                        type="text" 
                        id="Zip<?php echo $i; ?>"                   
                        class="form_input"             
                        name="Zip<?php echo $i; ?>"                 
                        title="Enter The Users Zip Code. Include '-' for full code" 
                        pattern="\d{5}([\-]\d{4})?" 
                        placeholder="e.g. 12345-6789"         
                        size="32"                       
                        maxlength="10"                  
                        tabindex="150"                   
                        value="<?php echo htmlspecialchars($extraaddresses[$i][3]); ?>"  
                        <?php if ($extraaddresses[$i][3] != '') { echo "required"; } ?>
                    /><br />

                    <label class="form_left">Country</label>
                    <select id="Country<?php echo $i; ?>" name="Country<?php echo $i; ?>" tabindex="160">
                    <?php 
                        $rows = getCountryCodes();
                        for ($j = 1; $j < count($rows); $j++){
                            if ($rows[$j][0] == $extraaddresses[$i][4]) { echo "<option value=".$rows[$j][1]." selected>".$rows[$j][0]."</option>"; }
                            else { echo "<option value=".$rows[$j][1].">".$rows[$j][0]."</option>"; }
                        }
                    ?>   
                    </select><br />

                    <label class="form_left">Primary Address</label>
                    <input 
                        type="radio" 
                        id="PrimaryAddress"                   
                        class="form_input"             
                        name="PrimaryAddress"                                 
                        tabindex="165"                
                        value="<?php echo $i; ?>"
                         <?php if($extraaddresses[$i][5] == 'True') echo 'checked'; ?>
                    /><br />
                </div>
            <?php } } ?>
            
            <input type="hidden" id="AddressCount" name="AddressCount" value="<?php echo htmlspecialchars($addresscount); ?>"/>

            <div id="NewAddressContainer"></div>
            <div class="form_left"><input value="Add Address" id="NewAddress" type="button"  onClick="addAddress()"></div>
            <div class="form_input"><input value="Remove Address" id="DeleteAddress" type="button"  onClick="removeAddress()"></div>
            <div id="clearable"></div>
        </div><br />
           
<script>
   
    <?php if($mode == 'add') { echo 'var addressCount = 1;'."\n"; } else { echo 'var addressCount = '.($addresscount + 1).';'."\n"; }?>
    var extraAddressCount = addressCount;
    var addressTypeID = 'NewAddress'.concat(addressCount);

    function addAddress(){      
        var newAddress = 
            '<div id="NewAddress' + addressCount + '"><br />'+
                '<label class="form_left">Address ' + (addressCount + 1) + '</label>'+
                '<div id="clearable"></div>'+
                '<label class="form_left">Type</label>'+
                '<select id="AddressType' + addressCount + '" name="AddressType' + addressCount + '" tabindex="130">'+
                    '<option value = "home" selected>Home</option>'+
                    '<option value = "work">Work</option>'+
                    '<option value = "custom">Custom</option>'+
                    '<option value = "other">Other</option>'+
                '</select><br />'+
                '<label class="form_left">Street Address</label>'+
                '<input '+
                    'type="text" '+
                    'id="StreetAddress' + addressCount + '"'+                   
                    'class="form_input"'+             
                    'name="StreetAddress' + addressCount + '"'+                 
                    'title="Enter The Users Street Address"'+ 
                    'placeholder="e.g. 12345 Ocean Way; Palms, Florida"'+         
                    'size="32"'+                       
                    'maxlength="128"'+                  
                    'tabindex="140"'+                   
                    'value=""'+                        
                '/><br />'+
                '<label class="form_left">Zip Code</label>'+
                '<input '+
                    'type="text"'+
                    'id="Zip' + addressCount + '"'+                   
                    'class="form_input"'+             
                    'name="Zip' + addressCount + '"'+                 
                    'title="Enter The Users Zip Code. Include \'-\' for full code"'+ 
                    'pattern="\\d{5}([\\-]\\d{4})?"'+ 
                    'placeholder="e.g. 12345-6789"'+         
                    'size="32"'+                       
                    'maxlength="10"'+                  
                    'tabindex="150"'+                   
                    'value=""'+                        
                '/><br />'+
                '<label class="form_left">Country</label>'+
                '<select id="Country' + addressCount + '" name="Country' + addressCount + '" tabindex="160">'+
                    <?php 
                        $rows = getCountryCodes();
                        for ($i = 1; $i < sizeof($rows); $i++){
                            if ($rows[$i][0] == "United States") { echo "'<option value=".$rows[$i][1]." selected>".$rows[$i][0]."</option>'+"; }
                            else { echo "'<option value=".$rows[$i][1].">".$rows[$i][0]."</option>'+"; }
                        }
                    ?>   
                '</select><br />'+
                '<label class="form_left">Primary Address</label>'+
                '<input '+
                    'type="radio"'+ 
                    'id="PrimaryAddress"'+                   
                    'class="form_input"'+             
                    'name="PrimaryAddress"'+                                 
                    'tabindex="165"'+                
                    'value="' + addressCount + '"'+
                '/><br />'+
            '</div>';
    
        var addressLimit = <?php echo $addressLimit; ?>;
        if (addressCount < addressLimit){
            var title = document.getElementById('NewAddress').value;
            var node = document.createElement('div');        
            node.innerHTML = newAddress;       
            document.getElementById('NewAddressContainer').appendChild(node); 
            document.getElementById('AddressCount').value = addressCount; 
        }
        
        addressCount++; 
    }
    
    function removeAddress(){        
        if (addressCount > extraAddressCount){
            addressCount--;
            addressTypeID = 'NewAddress'.concat(addressCount);
            var elementToRemove = document.getElementById(addressTypeID);
            elementToRemove.remove();
            document.getElementById('AddressCount').value = addressCount;
        } else {
            if (addressCount <= extraAddressCount && addressCount != 1) { <?php if ($mode == 'edit') { echo 'alert("This field can not be removed in edit mode, only updated.");'; } ?> }
        }  
    }
    
</script>
        
        <label class="spoiler" onclick="if(document.getElementById('PhoneSpoiler').style.display=='none') {
            document.getElementById('PhoneSpoiler').style.display='' }
            else { document.getElementById('PhoneSpoiler').style.display='none' } ">Phones</label>
        <div id="clearable"></div><br />
        
        <?php if($mode == 'add'){ ?> <div id="PhoneSpoiler" style="display:none">
        <?php } else { ?> <div id="PhoneSpoiler" style="display:"> <?php } ?>
            <label class="form_left">Phone 1</label><div id="clearable"></div>
            <label class="form_left">Phone Type</label>
            <select id="PhoneType" name="PhoneType" tabindex="170">
                <?php 
                    $rows = getPhoneTypes();
                    for ($i = 1; $i < count($rows); $i++){
                        if ($mode == 'add') { $default = 'mobile'; } else { $default = strtolower($phonetype); }
                        if ($rows[$i][0] == $default) { echo "<option value=".$rows[$i][0]." selected>".$rows[$i][1]."</option>"; }
                        else { echo "<option value=".$rows[$i][0].">".$rows[$i][1]."</option>"; }
                    }
                ?> 
            </select><br />

            <label class="form_left">Phone Number</label>
            <input 
                type="text" 
                id="Phone"                   
                class="form_input"             
                name="Phone"                 
                title="Enter The Users Phone Number. Do not include spaces or any characters other than digits." 
                pattern="[\d]*" 
                placeholder="e.g. 5555555555"         
                size="32"    
                minlength="10"
                maxlength="10"                  
                tabindex="180"                   
                value="<?php echo htmlspecialchars($phone); ?>" 
                <?php if ($phone != '') { echo "required"; } ?>
            /><br />

            <label class="form_left">Primary Phone</label>
            <input type="hidden" id="PrimaryPhone" name="PrimaryPhone" value="0"/>
            <input
                type="radio" 
                id="PrimaryPhone"                   
                class="form_input"             
                name="PrimaryPhone"                                 
                tabindex="190"                
                value="0"  
                checked
            /><br />
            <div id="clearable"></div>

            <?php if($mode == 'edit') { for ($i = 1; $i <= $phonecount; $i++) { ?>
                <div id="NewPhone<?php echo $i; ?>"><br />
                    <label class="form_left">Phone <?php echo ($i + 1); ?></label><div id="clearable"></div>
                    <label class="form_left">Phone Type</label>
                    <select id="PhoneType<?php echo $i; ?>" name="PhoneType<?php echo $i; ?>" tabindex="170">
                        <?php 
                            $rows = getPhoneTypes();
                            for ($j = 1; $j < count($rows); $j++){
                                if ($mode == 'add') { $default = 'mobile'; } else { $default = strtolower($extraphones[$i][0]); }
                                if ($rows[$j][0] == $default) { echo "<option value=".$rows[$j][0]." selected>".$rows[$j][1]."</option>"; }
                                else { echo "<option value=".$rows[$j][0].">".$rows[$j][1]."</option>"; }
                            }
                        ?> 
                    </select><br />

                    <label class="form_left">Phone Number</label>
                    <input 
                        type="text" 
                        id="Phone<?php echo $i; ?>"                   
                        class="form_input"             
                        name="Phone<?php echo $i; ?>"                 
                        title="Enter The Users Phone Number. Do not include spaces or any characters other than digits." 
                        pattern="[\d]*" 
                        placeholder="e.g. 5555555555"         
                        size="32"    
                        minlength="10"
                        maxlength="10"                  
                        tabindex="180"                   
                        value="<?php echo htmlspecialchars($extraphones[$i][1]); ?>"    
                        <?php if ($extraphones[$i][1] != '') { echo "required"; } ?>
                    /><br />

                    <label class="form_left">Primary Phone</label>
                    <input
                        type="radio" 
                        id="PrimaryPhone"                   
                        class="form_input"             
                        name="PrimaryPhone"                                 
                        tabindex="190"                
                        value="<?php echo $i; ?>"  
                        <?php if($extraphones[$i][2] == 'True') echo 'checked'; ?>
                    /><br />
                    <div id="clearable"></div>
                </div>
            <?php } } ?>
            
            <input type="hidden" id="PhoneCount" name="PhoneCount" value="<?php echo htmlspecialchars($phonecount); ?>"/>

            <div id="NewPhoneContainer"></div>
            <div class="form_left"><input value="Add Phone" id="NewPhone" type="button"  onClick="addPhone()"></div>
            <div class="form_input"><input value="Remove Phone" id="DeletePhone" type="button"  onClick="removePhone()"></div>
            <div id="clearable"></div>
        </div><br />
        
<script>
   
    <?php if($mode == 'add') { echo 'var phoneCount = 1;'."\n"; } else { echo 'var phoneCount = '.($phonecount + 1).';'."\n"; }?>
    var extraPhoneCount = phoneCount;
    var phoneTypeID = 'NewPhone'.concat(phoneCount);

    function addPhone(){      
        var newPhone = 
            '<div id="NewPhone' + phoneCount + '"><br />'+
                '<label class="form_left">Phone ' + (phoneCount + 1) + '</label><div id="clearable"></div>'+
                '<label class="form_left">Phone Type</label>'+
                '<select id="PhoneType' + phoneCount + '" name="PhoneType' + phoneCount + '" tabindex="170">'+
                    <?php 
                        $rows = getPhoneTypes();
                        for ($i = 1; $i < count($rows); $i++){
                            if ($rows[$i][0] == "mobile") { echo "'<option value=".$rows[$i][0]." selected>".$rows[$i][1]."</option>'+"; }
                            else { echo "'<option value=".$rows[$i][0].">".$rows[$i][1]."</option>'+"; }
                        }
                    ?> 
                '</select><br>'+

                '<label class="form_left">Phone Number</label>'+
                '<input id="Phone' + phoneCount + '" class="form_input" name="Phone' + phoneCount + '" title="Enter The Users Phone Number. Do not include spaces or any characters other than digits." pattern="[\\d]*" placeholder="e.g. 5555555555" size="32" minlength="10" maxlength="10" tabindex="180" value="" type="text"><br>'+

                '<label class="form_left">Primary Phone</label>'+
                '<input id="PrimaryPhone" class="form_input" name="PrimaryPhone" tabindex="190" value="' + phoneCount + '" type="radio"><br />' +
                '<div id="clearable"></div>'+
            '</div>';

        var phoneLimit = <?php echo $phoneLimit; ?>;
        if (phoneCount < phoneLimit){
            var title = document.getElementById('NewPhone').value;
            var node = document.createElement('div');        
            node.innerHTML = newPhone;       
            document.getElementById('NewPhoneContainer').appendChild(node); 
            document.getElementById('PhoneCount').value = phoneCount; 
        }
        
        phoneCount++; 
    }
    
    function removePhone(){  
        if (phoneCount > extraPhoneCount){
            phoneCount--;
            phoneTypeID = 'NewPhone'.concat(phoneCount);
            var elementToRemove = document.getElementById(phoneTypeID);
            elementToRemove.remove();
            document.getElementById('PhoneCount').value = phoneCount;
        } else {
            if (phoneCount <= extraPhoneCount && phoneCount != 1) { <?php if ($mode == 'edit') { echo 'alert("This field can not be removed in edit mode, only updated.");'; } ?> }
        }
    }
    
</script>
        
        <label class="spoiler" onclick="if(document.getElementById('AliasSpoiler').style.display=='none') {
            document.getElementById('AliasSpoiler').style.display='' }
            else { document.getElementById('AliasSpoiler').style.display='none' } ">Aliases</label>
        <div id="clearable"></div><br />
        
        <input type="hidden" name="OldAlias" id="OldAlias" value="<?php echo htmlspecialchars($alias); ?>"/>
        <?php if($mode == 'add'){ ?> <div id="AliasSpoiler" style="display:none">
        <?php } else { ?> <div id="AliasSpoiler" style="display:"> <?php } ?>
			<?php if ($mode == 'edit') { ?><input type="hidden" id="Alias" name="Alias" value="<?php echo htmlspecialchars($alias); ?>" /><?php } ?>
            <label class="form_left">Non Editable Alias</label><div id="clearable"></div>
            <label class="form_left">User Alias</label>
            <input 
                type="text" 
                id="Alias"                   
                class="form_input"             
                name="Alias"                 
                title="Enter your user alias"   
                pattern="^[a-zA-Z0-9_.+-]+$"
                placeholder="e.g. aliasEmail"         
                size="32"                       
                maxlength="60"                  
                tabindex="200"                   
                value="<?php echo htmlspecialchars($alias); ?>" 
                <?php if ($alias != '') { echo "required"; } ?>
                <?php if ($mode == 'edit') { ?>disabled<?php } ?>
            /><br />

            <input type="hidden" id="AliasDomain" name="AliasDomain" value="<?php $domain = getDomain(); echo htmlspecialchars($domain); ?>"/>

            <?php if($mode == 'edit') { for ($i = 1; $i <= $aliascount; $i++) { ?>
                <input type="hidden" name="OldAlias<?php echo $i; ?>" id="OldAlias<?php echo $i; ?>" value="<?php echo htmlspecialchars($extraaliases[$i][0]); ?>"/>
                <div id="NewAlias<?php echo $i; ?>"><br />
                    <label class="form_left">Alias <?php echo ($i + 1); ?></label><div id="clearable"></div>
                    <label class="form_left">User Alias</label>
                    <input 
                        type="text" 
                        id="Alias<?php echo $i; ?>"                   
                        class="form_input"             
                        name="Alias<?php echo $i; ?>"                 
                        title="Enter your user alias"   
                        pattern="^[a-zA-Z0-9_.+-]+$"
                        placeholder="e.g. aliasEmail"         
                        size="32"                       
                        maxlength="60"                  
                        tabindex="200"                   
                        value="<?php echo htmlspecialchars($extraaliases[$i][0]); ?>"       
                        <?php if ($extraaliases[$i][0] != '') { echo "required"; } ?>
                    /><br />

                    <input type="hidden" id="AliasDomain<?php echo $i; ?>" name="AliasDomain<?php echo $i; ?>" value="<?php $domain = getDomain(); echo htmlspecialchars($domain); ?>"/>
                </div>
            <?php } } ?>
            
            <input type="hidden" id="AliasCount" name="AliasCount" value="<?php echo htmlspecialchars($aliascount); ?>"/>
            
            <div id="NewAliasContainer"></div>
            <div class="form_left"><input value="Add Alias" id="NewAlias" type="button"  onClick="addAlias()"></div>
            <div class="form_input"><input value="Remove Alias" id="DeleteAlias" type="button"  onClick="removeAlias()"></div>
            <div id="clearable"></div>
        </div><br />
        
<script>
   
    <?php if($mode == 'add') { echo 'var aliasCount = 1;'."\n"; } else { echo 'var aliasCount = '.($aliascount + 1).';'."\n"; }?>
    var extraAliasCount = aliasCount;
    var aliasTypeID = 'NewAlias'.concat(aliasCount);

    function addAlias(){      
        var newAlias = 
            '<div id="NewAlias' + aliasCount + '"><br />'+
                '<label class="form_left">Alias ' + (aliasCount + 1) + '</label><div id="clearable"></div>'+
                '<label class="form_left">User Alias</label>'+
                '<input '+
                    'type="text"'+ 
                    'id="Alias' + aliasCount + '"'+                   
                    'class="form_input"'+             
                    'name="Alias' + aliasCount + '"'+                 
                    'title="Enter your user alias"'+  
                    'pattern="^[a-zA-Z0-9_.+-]+$"'+
                    'placeholder="e.g. aliasEmail"'+        
                    'size="32"'+                       
                    'maxlength="60"'+                  
                    'tabindex="200"'+                   
                    'value=""'+                        
                '/><br />'+
                '<input type="hidden" id="AliasDomain' + aliasCount + '" name="AliasDomain' + aliasCount + '" value="<?php $domain = getDomain(); echo htmlspecialchars($domain); ?>"/>'+
            '</div>';

        var aliasLimit = <?php echo $aliasLimit; ?>;
        if (aliasCount < aliasLimit){
            var title = document.getElementById('NewAlias').value;
            var node = document.createElement('div');        
            node.innerHTML = newAlias;       
            document.getElementById('NewAliasContainer').appendChild(node); 
            document.getElementById('AliasCount').value = aliasCount; 
        }
        
        aliasCount++; 
    }
    
    function removeAlias(){        
        if (aliasCount > extraAliasCount){
            aliasCount--;
            aliasTypeID = 'NewAlias'.concat(aliasCount);
            var elementToRemove = document.getElementById(aliasTypeID);
            elementToRemove.remove();
            document.getElementById('AliasCount').value = aliasCount;
        } else {
            if (aliasCount <= extraAliasCount && aliasCount != 1) { <?php if ($mode == 'edit') { echo 'alert("This field can not be removed in edit mode, only updated.");'; } ?> }
        }
    }
    
</script>
        
        <br /> 
        <input
            type="submit"
            id="SubmitForm"
            class="submit_button"
            name="SubmitForm"
            title="Submit the form"	
	    value="Submit"
            tabindex="220"
            required   
        />
        
    </form>
    <br /><br /> 
</div>

<script>
    <?php
        if (!empty($errors)){
            echo "alert(\"Please correct the following errors:\\n$errors\");";
        }
    ?>
</script>

<?php
    $filename = '../view/users/add_user.php';
    require '../view/includes/footer_include.php';
?>
