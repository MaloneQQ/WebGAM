<?php
    $title = "WebGAM - View User";
    $folder = "users";
    require '../view/includes/header_include.php';
?>

<div class="form">
    
    <br /><h1 class=text_center>View User</h1><br /><br />
        
    <label class="form_left">User Name</label>
    <?php $username = $_GET['username']?>
    <form enctype="multipart/form-data" action="./controller.php?action=view_user" method="post" name="ChangeUserForm">
        <select id="SelectUserName" name="SelectUserName" onchange="ChangeUserForm.submit();" method="post" tabindex="10">
            <?php 
            $rows = getUsers();
            for ($i = 1; $i < count($rows); $i++){
                if ($username == $rows[$i]) { echo "<option value=".$rows[$i]." selected>".$rows[$i]."</option>"; }
                else { echo "<option value=".$rows[$i].">".$rows[$i]."</option>"; }
            }?>
        </select>
    </form>
    
    <label class="form_left">First Name</label>
    <label class="form_input"><?php echo htmlspecialchars($firstname); ?></label><br />

    <label class="form_left">Last Name</label>
    <label class="form_input"><?php echo htmlspecialchars($lastname); ?></label><br /><br />

    <label class="form_left">User Image</label>
    <?php if (file_exists('../data_files/pictures/'.$username.'.png')) {  ?>
    <div class="form_input"><img src="../data_files/pictures/<?php echo $username; ?>.png" alt="Error displaying image." height="250" width="250" /></div>
    <?php } else { ?><label class="form_input">No image has been uploaded</label><?php }?>
    <div id="clearable"></div><br />
    
    <label class="form_left">Suspended</label>
    <label class="form_input"><?php echo htmlspecialchars($suspended); ?></label><br />

    <label class="form_left">Change Password Next Login</label>
    <label class="form_input"><?php echo htmlspecialchars($changepassword); ?></label><br />

    <label class="form_left">Global Address List</label>
    <label class="form_input"><?php echo htmlspecialchars($adduserglobal); ?></label><br />

    <label class="form_left">Admin</label>
    <label class="form_input"><?php echo htmlspecialchars($admin); ?></label><br /><br />

    <label class="form_left">Organizational Unit</label>
    <label class="form_input"><?php echo htmlspecialchars($ou); ?></label><br /><br />

    <label class="spoiler">Company Information</label>
    <div id="clearable"></div><br />
    
    <label class="form_left">Company</label>
    <label class="form_input"><?php echo htmlspecialchars($company); ?></label><br />

    <label class="form_left">Title</label>
    <label class="form_input"><?php echo htmlspecialchars($usertitle); ?></label><br />

    <label class="form_left">Department</label>
    <label class="form_input"><?php echo htmlspecialchars($department); ?></label><br />

    <label class="form_left">Manager</label>
    <?php 
        //check to see if the manager actually is a current user in order to display them
        $users = getUsers();
        $manager_exists = false;
        for ($i = 0; $i < count($users); $i++){
            if ($manager == $users[$i]) { $manager_exists = true; }
        }
        if (!$manager_exists) { $manager = ""; }
    ?>
    <label class="form_input"><?php echo htmlspecialchars($manager); ?></label><br /><br />
    
    <label class="spoiler">Addresses</label>
    <div id="clearable"></div><br />

    <?php if ($addresscount != 0) { ?>
        <label class="form_left">Address 1</label>
        <div id="clearable"></div>
    <?php } ?>
    
    <label class="form_left">Type</label>
    <label class="form_input"><?php echo htmlspecialchars($addresstype); ?></label><br />

    <label class="form_left">Street Address</label>
    <label class="form_input"><?php echo htmlspecialchars($streetaddress); ?></label><br />

    <label class="form_left">Zip Code</label>
    <label class="form_input"><?php echo htmlspecialchars($zip); ?></label><br />

    <label class="form_left">Country</label>
    <label class="form_input"><?php echo htmlspecialchars($country); ?></label><br />

    <label class="form_left">Primary Address</label>
    <label class="form_input"><?php echo htmlspecialchars($primaryaddress); ?></label><br /><br />

    <?php for ($i = 1; $i <= $addresscount; $i++) { ?>
        <label class="form_left">Address <?php echo ($i+1); ?></label>
        <div id="clearable"></div>    
    
        <label class="form_left">Type</label>
        <label class="form_input"><?php echo htmlspecialchars($extraaddresses[$i][0]); ?></label><br />

        <label class="form_left">Street Address</label>
        <label class="form_input"><?php 
            if ($extraaddresses[$i][2] != '') { echo htmlspecialchars($extraaddresses[$i][2]); }
            else if ($extraaddresses[$i][1] != '') { echo htmlspecialchars($extraaddresses[$i][1]); }
            else { echo ''; }
        ?></label><br />

        <label class="form_left">Zip Code</label>
        <label class="form_input"><?php echo htmlspecialchars($extraaddresses[$i][3]); ?></label><br />

        <label class="form_left">Country</label>
        <label class="form_input"><?php echo htmlspecialchars($extraaddresses[$i][4]); ?></label><br />

        <label class="form_left">Primary Address</label>
        <label class="form_input"><?php echo htmlspecialchars($extraaddresses[$i][5]); ?></label><br /><br />
    <?php } ?>
    
    <label class="spoiler">Phones</label>
    <div id="clearable"></div><br />
    
    <?php if ($phonecount != 0) { ?>
        <label class="form_left">Phone 1</label>
        <div id="clearable"></div>
    <?php } ?>
    
    <label class="form_left">Phone Type</label>
    <label class="form_input"><?php echo htmlspecialchars($phonetype); ?></label><br />

    <label class="form_left">Phone Number</label>
    <label class="form_input"><?php echo htmlspecialchars($phone); ?></label><br />

    <label class="form_left">Primary Phone</label>
    <label class="form_input"><?php echo htmlspecialchars($primaryphone); ?></label><br /><br />
    
    <?php for ($i = 1; $i <= $phonecount; $i++) { ?>
        <label class="form_left">Phone <?php echo ($i+1); ?></label>
        <div id="clearable"></div> 
        
        <label class="form_left">Phone Type</label>
        <label class="form_input"><?php echo htmlspecialchars($extraphones[$i][0]); ?></label><br />

        <label class="form_left">Phone Number</label>
        <label class="form_input"><?php echo htmlspecialchars($extraphones[$i][1]); ?></label><br />

        <label class="form_left">Primary Phone</label>
        <label class="form_input"><?php echo htmlspecialchars($extraphones[$i][2]); ?></label><br /><br />
    <?php } ?>
        
    <label class="spoiler">Aliases</label>
    <div id="clearable"></div><br />
    
    <?php if ($aliascount != 0) { ?>
    <label class="form_left">Alias 1</label>
    <div id="clearable"></div>
    <?php } ?>
    
    <label class="form_left">User Alias</label>
    <label class="form_input"><?php echo htmlspecialchars($alias); ?></label><br />
    
    <label class="form_left">Alias Domain</label>
    <label class="form_input"><?php echo htmlspecialchars($aliasdomain); ?></label><br /><br />
    
    <?php for ($i = 1; $i <= $aliascount; $i++) { ?>
        <label class="form_left">Alias <?php echo ($i+1); ?></label>
        <div id="clearable"></div> 
        
        <label class="form_left">User Alias</label>
        <label class="form_input"><?php echo htmlspecialchars($extraaliases[$i][0]); ?></label><br />

        <label class="form_left">Alias Domain</label>
        <label class="form_input"><?php echo htmlspecialchars($extraaliases[$i][1]); ?></label><br /><br />
    <?php } ?>
    
</div>
		
<?php
    $filename = '../view/users/view_user.php';
    require '../view/includes/footer_include.php';
?>
