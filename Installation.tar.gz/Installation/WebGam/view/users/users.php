<?php
    $title = "WebGAM - Users";
    $folder = "users";
    require '../view/includes/header_include.php';
?>

<div class="remove_form">
    
    <br /><h1 class=text_center>Users</h1><br /><br />
        
    <?php 
    $rows = getUsers();
    for ($i = 1; $i < count($rows); $i++){ ?>
        <label class="remove_form_left"><?php echo $rows[$i]; ?></label>
        <input type="hidden" name="User<?php echo $i; ?>" value="keep"/>
        <a class="form_input" href="./controller.php?action=view_user&username=<?php echo $rows[$i]; ?>">view</a>
        <a class="form_input_right" href="./controller.php?action=update_edit_user_form&username=<?php echo $rows[$i]; ?>">edit</a>
        <div id="clearable"></div>
    <?php } ?>
    <br /><br />
    
</div>
		
<?php
    $filename = '../view/users/users.php';
    require '../view/includes/footer_include.php';
?>
