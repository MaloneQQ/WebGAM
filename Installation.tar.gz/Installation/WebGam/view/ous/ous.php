<?php
    $title = "WebGAM - OUs";
    $folder = "ous";
    require '../view/includes/header_include.php';
?>

<div class="remove_form">
    
    <br /><h1 class=text_center>OUs</h1><br /><br />
        
    <?php 
    $rows = getOUs();
    for ($i = 1; $i < count($rows); $i++){ ?>
        <label class="remove_form_left"><?php echo $rows[$i]; ?></label>
        <input type="hidden" name="OU<?php echo $i; ?>" value="keep"/>
        <a class="form_input" href="./controller.php?action=view_ou&ouname=<?php echo $rows[$i]; ?>">view</a>
        <a class="form_input_right" href="./controller.php?action=update_edit_ou_form&ouname=<?php echo $rows[$i]; ?>">edit</a>
        <div id="clearable"></div>
    <?php } ?>
    <br /><br />
    
</div>

<?php 
	if (isset($_GET['gam_error'])){
		echo "<script>alert(\"GAM Error\\n\\nGAM currently does not support the\\nfunctionality to change a parent OU.\\n\\nAll other functionality is supported\\nand those changes have been\\nprocessed.\");</script>";
	}
?>

<?php
    $filename = '../view/ous/ous.php';
    require '../view/includes/footer_include.php';
?>
