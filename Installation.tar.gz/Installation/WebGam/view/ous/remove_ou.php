<?php
    $title = "WebGAM - Remove OU";
    $folder = "ous";
    require '../view/includes/header_include.php';
?>

<div class="remove_form">
    
    <br /><h1 class=text_center>Remove OU</h1><br /><br />
    
    <form enctype="multipart/form-data" action="./controller.php?action=process_remove_ou" method="post">
        
        <?php 
        $rows = getOUs();
        for ($i = 1; $i < count($rows); $i++){ ?>
            <label class="remove_form_left"><?php echo $rows[$i]; ?></label>
            <input type="hidden" name="OU<?php echo $i; ?>" value="keep"/>
            <input
                type="checkbox" 
                id="OU<?php echo $i; ?>"                   
                class="form_input"             
                name="OU<?php echo $i; ?>"  
                tabindex="<?php echo ($i+1)*10; ?>"                
                value="<?php echo $rows[$i]; ?>"                        
            /><br />
            <div id="clearable"></div>
        <?php } ?>
        <input type="hidden" id="OUCount" name="OUCount" value="<?php echo $i-1; ?>"/>
        
        <br /><br />
        <input
            type="submit"
            id="SubmitForm"
            class="submit_button"
            name="SubmitForm"
            title="Submit the form"	
	    value="Submit"
            tabindex="5"
            required   
        />
        
        <br /><br />
        
    </form>
    
</div>

<script>
    <?php
        if (!empty($errors)){
            echo "alert(\"Please correct the following errors:\\n$errors\");";
        }
    ?>
</script>

<?php
    $filename = '../view/ous/remove_ou.php';
    require '../view/includes/footer_include.php';
?>
