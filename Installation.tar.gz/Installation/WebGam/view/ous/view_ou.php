<?php
    $title = "WebGAM - View OU";
    $folder = "ous";
    require '../view/includes/header_include.php';
?>

<div class="form">

    <br /><h1 class="text_center">View OU</h1><br /><br />
    
    <label class="form_left">OU Name</label>
    <?php $ouname = $_GET['ouname']?>
    <form enctype="multipart/form-data" action="./controller.php?action=view_ou" method="post" name="ChangeOUForm">
        <select id="SelectOUName" name="SelectOUName" onchange="ChangeOUForm.submit();" method="post" tabindex="10">
            <?php 
            $rows = getOUs();
            for ($i = 1; $i < count($rows); $i++){ 
                if ($ouname == $rows[$i]) { echo "<option value=".$rows[$i]." selected>".$rows[$i]."</option>"; }
                else { echo "<option value=".$rows[$i].">".$rows[$i]."</option>"; }
            }?>
        </select>
    </form>

    <label class="form_left">Description</label>
    <textarea class="form_input" rows="2" cols="32" disabled><?php echo $oudescription; ?></textarea>
    <div id="clearable"></div><br />

    <label class="form_left">Parent Organization</label>
    <label class="form_input"><?php echo $parentou; ?></label>
    <div id="clearable"></div><br />
    
    <label class="form_left">OU Members</label>
    <select id="OUmembers" name="OUmembers[]" size="10" class="form_input selector" multiple="multiple">
        <?php 
            //only add the users who are in the ou
            $oupath = substr($oupath, 1);
            $sets = getOUmembers($oupath); //get the ou members
            for ($i = 0; $i < count($sets[0]); $i++){
                echo '<option value="'.$sets[0][$i].'">'.$sets[0][$i].'</option>';
            }
        ?>
    </select> 
        	
</div> 
		
<?php
    $filename = '../view/ous/view_ou.php';
    require '../view/includes/footer_include.php';
?>
