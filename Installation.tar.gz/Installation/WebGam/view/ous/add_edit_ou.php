<?php
    if ($mode == "add"){
        $title = "WebGAM - Add OU";
    } else {
        $title = "WebGAM - Edit OU";
    } 
    $folder = "ous";
    require '../view/includes/header_include.php';
?>
    
<div class="form">

    <br />
    <?php if ($mode == "add"){
        echo "<h1 class=\"text_center\">Add OU</h1>";
    } else {
        echo "<h1 class=\"text_center\">Edit OU</h1>";
    } ?>
    <br /><br />
    
    <?php if ($mode == "edit"){ ?>
        <?php $ouname = $_GET['ouname']?>
        <form enctype="multipart/form-data" action="./controller.php?action=update_edit_ou_form" method="post" name="UpdateEditOuForm">
            <label class="form_left">OU Name<span class="required">*</span></label>
            <select id="OUName" name="OUName" onchange="UpdateEditOuForm.submit();" method="post">
                <?php 
                $rows = getOUs();
                for ($i = 1; $i < count($rows); $i++){ 
                    if ($ouname == $rows[$i]) { echo "<option value=".$rows[$i]." selected>".$rows[$i]."</option>"; }
                    else { echo "<option value=".$rows[$i].">".$rows[$i]."</option>"; }
                }?>
            </select>
        </form>
    <?php } ?>
    
    <?php if ($mode == "add"){ ?>
        <form enctype="multipart/form-data" action="./controller.php?action=process_add_ou" onsubmit="selectAll('InOU'); selectAll('NotInOU');" method="post">
    <?php } else { ?>  
        <form enctype="multipart/form-data" action="./controller.php?action=process_edit_ou" onsubmit="selectAll('InOU'); selectAll('NotInOU');" method="post">  
        <input type="hidden" id="OUName" name="OUName" value="<?php echo $ouname; ?>"/>
    <?php } ?>
    
        <input type="hidden" name="Mode" value="<?php echo $mode; ?>"/>
	<input type="hidden" name="OUpath" value="<?php echo $oupath; ?>">
            
        <?php if ($mode == "add"){ ?>
            <label class="form_left">OU Name<span class="required">*</span></label>
            <input 
                type="text" 
                id="OUName"                   
                class="form_input"             
                name="OUName"                 
                title="Enter the name of the OU" 
                pattern="^[a-zA-Z0-9_.+-]+$"
                placeholder="e.g. Accounting"         
                size="32"                       
                maxlength="60"                  
                tabindex="10"                   
                value="<?php echo htmlspecialchars($ouname); ?>"                        
                required                         
            />
        <?php } ?>

        <label class="form_left">Description<span class="required">*</span></label>
        <input 
            type="text" 
            id="OUDescription"                   
            class="form_input"             
            name="OUDescription"                 
            title="Enter the description of the OU" 

            placeholder=""         
            size="32"                       
            maxlength="128"                  
            tabindex="20"                   
            value="<?php echo htmlspecialchars($oudescription); ?>"                        
            required                         
        />
        <div id="clearable"></div>
        <br />
        
        <label class="form_left">Parent Organization</label>
        <select id="ParentOU" class="singleselect" name="ParentOU" tabindex="30">
            <option value="/" selected>-- None --</option>
            <?php 
            $rows = getOUs();
	    $parents = array();
	    for ($i = 1; $i < count($rows); $i++){
		$ou = getOUInfo($rows[$i]);
		$parents[$i-1] = $ou[3]; //get the current ou parent from the array of ous
	    }
            for ($i = 0; $i < count($parents); $i++){
                if ($ouname != $rows[$i+1]) { //don't allow ou to be its own parent
                    if ($parentou == $parents[$i]) { echo "<option value=".$parents[$i]." selected>".$parents[$i]."</option>"; }
                    else { echo "<option value=".$parents[$i].">".$parents[$i]."</option>"; }
                } 
            }?>
        </select><br /><br />
        
        <label class="form_left">Organizational Unit Members</label><br /><br />
        <table>
            <tr>
                <td>
                    Users In OU<br/>
                    <select id="InOU" name="InOU[]" size="10" class="selector" multiple="multiple">
                        <?php
                            if ($mode == 'edit') {
                                //only add the users who are in the ou
                                $oupath = substr($oupath, 1);
                                $sets = getOUmembers($oupath); //get the ou members
                                for ($i = 0; $i < count($sets[0]); $i++){
                                    echo '<option value="'.$sets[0][$i].'">'.$sets[0][$i].'</option>';
                                }
                            }
                        ?>
                    </select>                
                </td>

                <td>
                    <input type="button" value=">>" onclick="swap('InOU','NotInOU')"><br/>
                    <br/>
                    <input type="button" value="<<" onclick="swap('NotInOU','InOU')"><br/>
                </td>

                <td>
                Users Not In OU<br/>
                <select id="NotInOU" name="NotInOU[]" size="10" class="selector" multiple="multiple">
                    <?php 
                        $rows = getUsers();
                        for ($i = 1; $i < count($rows); $i++){
                            if ($mode == 'add') { echo "<option value=".$rows[$i].">".$rows[$i]."</option>"; }
                        }
                        //only add the users who are not in the ou
                        if ($mode == 'edit'){
                            for ($i = 0; $i < count($sets[1]); $i++){
                                echo '<option value="'.$sets[1][$i].'">'.$sets[1][$i].'</option>';
                            }
                        }
                    ?>
                </select>                
                </td>
            </tr>
        </table>
        <br/>
        
        <input
            type="submit"
            id="SubmitForm"
            class="submit_button"
            name="SubmitForm"
            title="Submit the form"	
            value="Submit"
            tabindex="50"
            required   
        />

        <br /><br />
        
    </form>	
</div>
    
<script>
    <?php
        if (!empty($errors)){
            echo "alert(\"Please correct the following errors:\\n$errors\");";
        }
    ?>
</script>
    
<?php
    $filename = '../view/ous/add_edit_ou.php';
    require '../view/includes/footer_include.php';
?>
