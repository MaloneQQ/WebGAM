<?php
    $title = "WebGAM - Contacts";
    $folder = "contacts";
    require '../view/includes/header_include.php';
?>

<?php require '../view/includes/construction_include.php'; ?>
	
This is the main page for Contacts.

<?php
    $filename = '../view/contacts/contacts.php';
    require '../view/includes/footer_include.php';
?>
