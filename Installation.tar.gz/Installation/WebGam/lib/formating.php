<?php

    function formatDate($date){
        if ($phpDate = strtotime($date)) {
            return date("M d, Y", strtotime($date));
        } else {
            return "";
        }
    }
    
    function formatDateFull($date){
        if ($phpDate = strtotime($date)) {
            return date("F d, Y", strtotime($date));
        } else {
            return "";
        }
    }
    
    function formatPHPDate($date) {
        if ($phpDate = strtotime($date)) {
            return date('m/d/Y', $phpDate);
        } else {
            return "";
        }
    }

    function formatPhoneNumber($number) {
        $strlen = strlen( $number );
        if ($strlen != 10) { return $number; }
        $formatted_number = "(";
        for( $i = 0; $i <= $strlen; $i++ ) { 
            $char = substr( $number, $i, 1 );
            $formatted_number .= $char;
            if ($i == 2) { $formatted_number .= ") "; }
            if ($i == 5) { $formatted_number .= "-"; }
        }
        return $formatted_number;
    }

?>
