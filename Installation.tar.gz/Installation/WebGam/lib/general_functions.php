<?php

function checkLength($string, $minlength, $maxlength, $message){
    if (empty($string) || strlen($string) < $minlength || strlen($string) > $maxlength)
        return $message;
    return "";
}

function unQuote() {
    if (get_magic_quotes_gpc()) {
        function stripslashes_gpc(&$value) {
            $value = stripslashes($value);
        }
        array_walk_recursive($_GET, 'stripslashes_gpc');
        array_walk_recursive($_POST, 'stripslashes_gpc');
        array_walk_recursive($_COOKIE, 'stripslashes_gpc');
        array_walk_recursive($_REQUEST, 'stripslashes_gpc');
    }		
}

//path the the top of WebGAM on this mashine
function gamPath(){
    return '/var/www/html/WebGam/';
}

//maximum number of addresses a user can have
function maxAddresses(){
    return 10;
}

//maximum number of phones a user can have
function maxPhones(){
    return 10;
}

//maximum number of aliases that can be had
function maxAliases(){
    return 10;
}

//to run gam commands turn off debug mode
//to test output of forms and gam commands that will be run, turn on debug mode
function debugMode(){
    return false;
    //return true;
}

//for debugging purposes
//prints out all user data read from user CSV file
//useful for debugging view and edit user pages
function echoData(){
    //return true;
    return false;
}

//if a double period makes it into a email type input, remove it
function removeDoublePeriods($string){
    $strlen = strlen( $string );
    $purified = "";
    for( $i = 0; $i <= $strlen; $i++ ) { 
        $char = substr( $string, $i, 1 );
        if ($i != 0 && $char == '.') {
            $sub = substr( $string, ($i-1), 1);
            if ($sub != '.') { $purified .= $char; }
        } else { $purified .= $char; }
    }
    return $purified;
}

function callGam($directory, $command) {
    $oldpath = getcwd();
    chdir($directory);
    shell_exec($command);
    chdir($oldpath);
}

//removes an email domain from a string
//returns and array of both the email and the domain
function removeDomain($string){
    $front = ""; 
    $back = "";
    $foundbreak = false;
    $strlen = strlen( $string );
    for( $i = 0; $i <= $strlen; $i++ ) { 
        $char = substr( $string, $i, 1 );
        if ($char == '@') { $foundbreak = true; }
        else 
        { 
            if (!$foundbreak) { $front .= $char; }
            else { $back .= $char; }
        }
    }
    return array($front, $back);
}

?>
