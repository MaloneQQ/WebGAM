#!/bin/bash
#This script adds users to an OU
#Usage: Cd to bash directory, Type "./addToOU.sh -o OUname -u Username"

GAMCALL="python /opt/GAM/gam.py"

while getopts o:u: opt; do
  case $opt in
#Sets the OU
     o)
      OU="$OPTARG"
    ;;
#Sets the user to be added
     u)
       USER="$OPTARG"
    ;;

    \?)
      echo "Something went wrong"
      exit 1
    ;;
esac
done
	#Calls the GAM command to add a specified user to an OU
	$GAMCALL update user "$USER" org "$OU"


