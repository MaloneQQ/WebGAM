#!/bin/bash
#This file creates a OU with the selected options with information

GAMCALL="python /opt/GAM/gam.py"

while getopts o:d:p: opt; do
  case $opt in
    o)
      #Places the text after the -o option in the ORG variable
      ORG="$OPTARG"
    ;;
    d)
      #Places the text after the -d option in the DESC variable
      DESC="$OPTARG"
    ;;
    p)
      #Places the text after the -p option in the PARENT variable
      PARENT="$OPTARG"
    ;;
#This displays when something goes wrong and then displays the error code.
    \?)
      echo "Something went wrong"
      exit 1
    ;;
  esac
done
#If there is text in the DESC variable run the following command
if [ ! -z "$DESC" ] && [ ! -z "$PARENT" ]; then
	$GAMCALL create org "$ORG" parent "$PARENT" description "$DESC"
#Else run the command without the description
elif [ ! -z "$DESC" ]; then
	$GAMCALL create org "$ORG" description "$DESC"
elif [ ! -z "$PARENT" ]; then
	$GAMCALL create org "$ORG" parent "$PARENT"
else
	$GAMCALL create org "$ORG"
#End if else statement
fi
