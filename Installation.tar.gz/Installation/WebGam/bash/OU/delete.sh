#!/bin/bash
#This script takes in as many arguments as you need and deletes those OU's
#Usage: Cd to bash directory, Type "./delete.sh orgname orgname orgname"

GAMCALL="python /opt/GAM/gam.py"

if [ -z "$1" ]; then #gives error asking you to give an ordname for deletion
    echo 'You must provide a org to delete.'
else
	for i in "$@"; do #loop to delete all of the orgs.
		$GAMCALL delete org "$i"
done
    echo 'Organizations deleted. If you with to undo this option, use the undelete command.'
fi


