#!/bin/bash

GAMCALL="python /opt/GAM/gam.py"
MVFROM="/var/www/html/WebGam/bash/OU"
MVTO="/var/www/html/WebGam/data_files/csv"

#Runs the gam command to get the Organizational Units info and then saves it as a csv into the folder that the script is located in
$GAMCALL print orgs name description parent inherit>$MVTO/orgs.csv
