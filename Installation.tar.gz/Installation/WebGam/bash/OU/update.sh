#!/bin/bash

GAMCALL="python /opt/GAM/gam.py"

#This file updates an OU with the selected options with information
while getopts o:d:p: opt; do
  case $opt in
#updates Group email
    o)
      #Places the text after the -o option in the ORG variable
      ORG="$OPTARG"
    ;;
    d)
      #Places the text after the -d option in the DESC variable
      DESC="$OPTARG"
    ;;
    p)
      #Places the text after the -p option in the PARENT variable
      PARENT="$OPTARG"
    ;;
#This displays when something goes wrong and then displays the error code.
    \?)
      echo "Something went wrong"
      exit 1
    ;;
  esac
done
#If there is a description and a parent
if [ ! -z "$DESC" ] && [ ! -z "$PARENT" ]; then
	$GAMCALL update org "$ORG" parent "$PARENT" description "$DESC"
#Else if there is a description
elif [ ! -z "$DESC" ]; then
	$GAMCALL update org "$ORG" description "$DESC"
#Else if there is a parent
elif [ ! -z "$PARENT" ]; then
	$GAMCALL update org "$ORG" parent "$PARENT"
#Else there are no updates
else
	echo "There are no updates to be done"
#End if else statement
fi
