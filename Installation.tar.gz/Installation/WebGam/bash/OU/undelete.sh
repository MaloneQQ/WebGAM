#!/bin/bash
#Undeletes an OU
GAMCALL="python /opt/GAM/gam.py"

#If an org was not specified ask for an org name
if [ "$1" = "" ]; then
    echo 'You must provide a org to delete.'
#else undelete the specified org
else
    $GAMCALL undelete org $1
    echo 'Org ' $1 ' undeleted.'
fi
