#!/bin/bash
#This script will delete users from a group
#Usage: Cd to bash directory, Type "./removeUsers.sh -g groupname -u username"

GAMCALL="python /opt/GAM/gam.py"

while getopts g:u: opt; do
  case $opt in
#Sets the group
     g)
      GROUP="$OPTARG"
    ;;
#Sets the user
     u)
       USER="$OPTARG"
    ;;

    \?)
      echo "Something went wrong"
      exit 1
    ;;
esac
done
	$GAMCALL update group "$GROUP" remove "$USER" 


