#!/bin/bash
#This script takes in as many arguments as you need and deletes those groups
#Usage: Cd to bash directory, Type "./delete.sh groupname groupname groupname"

GAMCALL="python /opt/GAM/gam.py"

if [ -z "$1" ]; then #gives error asking you to give a groupname for deletion
   	echo 'You must provide a group to delete.'
else
	for i in "$@"; do #loop to delete all of the users.
		$GAMCALL delete group "$i"
done
    echo 'Group deleted. If you with to undo this option, use the undelete command.'
fi



