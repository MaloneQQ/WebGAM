#!/bin/bash
#This removes alias's

GAMCALL="python /opt/GAM/gam.py"

while getopts a: opt; do
  case $opt in
#Sets the alias to be deleted
    a)
      ALIAS="$OPTARG"
    ;;
    \?)
      echo "Something went wrong"
      exit 1
    ;;
  esac
done
	#creates/updates alias for the user
	$GAMCALL delete alias $ALIAS
