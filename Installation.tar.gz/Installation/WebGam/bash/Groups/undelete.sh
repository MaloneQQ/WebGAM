#!/bin/bash
#This script undeletes a specified user.
#Usuage "./undelete.sh username"

GAMCALL="python /opt/GAM/gam.py"

if [ "$1" = "" ]; then
    echo 'You must provide a group to delete.'
else
    $GAMCALL undelete group $1
    echo 'Group ' $1 ' undeleted.'
fi


