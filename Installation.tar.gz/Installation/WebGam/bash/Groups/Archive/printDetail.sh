#!/bin/bash
python /opt/GAM/gam.py print groups name description admincreated id aliases members owners managers managers settings
