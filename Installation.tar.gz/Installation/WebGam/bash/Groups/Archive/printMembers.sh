#!/bin/bash

# array of all the options for the info user command
options=(group)
# check to see if an argument has been given
# the first argument should be a user email
# if it is not, gam will return an error, and we will display it on the webpage
if [ "$1" = "" ]; then
    echo 'You must provide a user email.'
fi

# loop through the arguments given and the possible command options
# if an argument does not match, break from the loop and report a failure
i=1
failed=0
for var in "$@"
do
    if [ "$i" != "1" ]; then
        optionmatch=0
        for ops in "${options[@]}"
        do
            # if match found, set the flag
            if [ "$var" = "$ops" ]; then
                let optionmatch=1
            fi
        done 
        if [ "$optionmatch" = "0" ]; then # report a failed argument
            echo 'No match for given argument.'
            let failed=1
        fi
    fi

    # invalid argument found, break because no need to look at other arguments
    if [ "$failed" = "1" ]; then
        break
    fi

    ((i++)) 
done

# in webpage this should not be possible
# options will be selected by check boxes, and the correct argument will be given 
if [ "$failed" = "1" ]; then
    echo 'Invalid GAM command: argument did not match a given option.'
else
    python /opt/GAM/gam.py print group-members group $1
fi
