#!/bin/bash
#gam csv groupAdd.csv gam update group add member ~User
#
#This script can be used to add multiple members at once using a csv file.
#
COMMAND="csv /var/www/html/WebGam/data_files/groupAdd.csv gam update"
while getopts g:t: opt; do
  case $opt in
#Creates Group email
    g)
      GROUP="$OPTARG"
      COMMAND="$COMMAND group $GROUP"
    ;;
#This needs to be one of three options. It can be owner, member, manager. If it is anything else it will not work.
    t)
      TYPE="$OPTARG"
      COMMAND="$COMMAND add $TYPE"
    ;;
#This displays when something goes wrong and then displays the error code.

    \?)
      echo "Something went wrong"
      exit 1
    ;;

  esac
done
echo "$COMMAND"
python /opt/GAM/gam.py $COMMAND ~User
