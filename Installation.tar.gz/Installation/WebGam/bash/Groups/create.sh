#!/bin/bash
#LANG=en_EN.utf-8
#This file creates a group with the selected options with informaiton

GAMCALL="python /opt/GAM/gam.py"

while getopts e:n:d:a: opt; do
  case $opt in
#An email address for your new group. If your organization's Google Apps account has multiple domains, select the appropriate domain.
#Creates Group email
    e)
      GROUP="$OPTARG"
    ;;
#A name for the group. For details about permitted group names, see these guidelines(https://support.google.com/a/answer/33386).
#Creates Group Name
    n)
      NAME="$OPTARG"
    ;;
#Creates Description of the group. Needs to have double quotes. Should look like this ""Description is here"".
    d)
      DESCR="$OPTARG" 
    ;;
#Adds alias to the group that is being created.
#Will not work this will. Will need to be changed!!
    a)
      ALIAS="$OPTARG"
    ;;
#This displays when something goes wrong and then displays the error code.
    \?)
      echo "Something went wrong"
      exit 1
    ;;
#End of getting all of the options
  esac
done
#echo "$COMMAND"
#This finds out if the alias variable is empty and if it is not it adds an alias to the created user.
if [ ! -z "$DESCR" ] && [ ! -z "$ALIAS" ]; then
	#creates group and then adds description
	$GAMCALL create group "$GROUP" description "$DESCR"
	#creates alias for the user
	$GAMCALL create alias "$ALIAS" group "$GROUP"
elif [ ! -z "$DESCR" ]; then
	#creates group and then adds description
	$GAMCALL create group "$GROUP" description "$DESCR"
elif [ ! -z "$ALIAS" ]; then
	#creates group
	$GAMCALL create group "$GROUP"
	#creates alias for the user
	$GAMCALL create alias "$ALIAS" group "$GROUP"
else
	$GAMCALL create group "$GROUP"
#End if statement
fi
if [ ! -z "$NAME" ]; then
	#Add's name to the group
	$GAMCALL update group "$GROUP" name "$NAME"
fi
