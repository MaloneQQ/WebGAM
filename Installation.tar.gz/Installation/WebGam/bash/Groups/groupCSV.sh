#!/bin/bash

GAMCALL="python /opt/GAM/gam.py"
MVFROM="/var/www/html/WebGam/bash/Groups"
MVTO="/var/www/html/WebGam/data_files/csv"

#Runs the gam command to get the group info and then saves it as a csv into the folder that the script is located in
$GAMCALL print groups name description admincreated id aliases members owners managers >$MVTO/groups.csv

#The following gam command saves all of the information from every group and places it in a csv file
#gam print groups name description admincreated id aliases members owners managers settings > groups.csv
