#!/bin/bash
LANG=en_EN.utf-8
#This file updates a group with the selected options with informaiton

GAMCALL="python /opt/GAM/gam.py"

while getopts e:n:d:a: opt; do
  case $opt in
#An email address for your new group. If your organization's Google Apps account has multiple domains, select the appropriate domain.
#updates Group email
    e)
      GROUP="$OPTARG"
    ;;
#A name for the group. For details about permitted group names, see these guidelines(https://support.google.com/a/answer/33386).
#updates Group Name
    n)
      NAME="$OPTARG"
    ;;
#updates Description of the group. Needs to have double quotes. Should look like this ""Description is here"".
    d)
      DESCR="$OPTARG" 
    ;;
#Adds alias to the group that is being updated.
    a)
      ALIAS="$OPTARG"
    ;;
#This displays when something goes wrong and then displays the error code.
    \?)
      echo "Something went wrong"
      exit 1
    ;;
#End of getting all of the options
  esac
done
#echo "$COMMAND"
#This finds out if the alias variable is empty and if it is not it adds an alias to the updated user.
if [ ! -z "$DESCR" ] && [ ! -z "$ALIAS" ] && [ ! -z "$NAME" ]; then
	#updates group and then adds description
	$GAMCALL update group "$GROUP" description "$DESCR"
	#updates alias for the user
	$GAMCALL create alias "$ALIAS" group "$GROUP"
	#Add's name to the group
	$GAMCALL update group "$GROUP" name "$NAME"
elif [ ! -z "$DESCR" ] && [ ! -z "$ALIAS" ]; then
	#updates group and then adds description
	$GAMCALL update group "$GROUP" description "$DESCR"
	#updates alias for the user
	$GAMCALL create alias "$ALIAS" group "$GROUP"
elif [ ! -z "$DESCR" ] && [ ! -z "$NAME" ]; then
	#updates group and then adds description
	$GAMCALL update group "$GROUP" description "$DESCR"
	#Add's name to the group
	$GAMCALL update group "$GROUP" name "$NAME"
elif [ ! -z "$ALIAS" ] && [ ! -z "$NAME" ]; then
	#updates alias for the user
	$GAMCALL create alias "$ALIAS" group "$GROUP"
	#Add's name to the group
	$GAMCALL update group "$GROUP" name "$NAME"
elif [ ! -z "$DESCR" ]; then
	#updates group and then adds description
	$GAMCALL update group "$GROUP" description "$DESCR"
elif [ ! -z "$ALIAS" ]; then
	#updates alias for the user
	$GAMCALL create alias "$ALIAS" group "$GROUP"
elif [ ! -z "$NAME" ]; then
	#Add's name to the group
	$GAMCALL update group "$GROUP" name "$NAME"
fi
