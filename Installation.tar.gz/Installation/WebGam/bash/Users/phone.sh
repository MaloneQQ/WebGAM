#!/bin/bash
#This adds a phone to the user.
COMMAND="update"
GAMCALL="python /opt/GAM/gam.py"

while getopts u:t:n:p: opt; do
  case $opt in
#Sets the username
    u)
      USER="$OPTARG"
      COMMAND="$COMMAND user $USER"
    ;;
#Creates a phone type
#Must have options n,p and t to add a phone number. They have to be added in that order also
     t)
      PHONE_TYPE="$OPTARG"
      COMMAND="$COMMAND phone type $PHONE_TYPE"
    ;;
#This is the actual phone number attached to the phone type
     n)
      PHONE_NUMBER="$OPTARG"
      COMMAND="$COMMAND value $PHONE_NUMBER"
    ;;
#This sets the phone as a primary phone or not. The values can be primary|notprimary.
     p)
      PHONE_PRIMARY="$OPTARG"
      COMMAND="$COMMAND $PHONE_PRIMARY"
    ;;
    \?)
      echo "Something went wrong"
      exit 1
    ;;
  esac
done
echo "$COMMAND"
	#calls gam command to add phone to user.
	$GAMCALL $COMMAND
