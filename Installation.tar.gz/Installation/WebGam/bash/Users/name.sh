#!/bin/bash
#This creates a user's name.

#Variables
COMMAND="update"
GAMCALL="python /opt/GAM/gam.py"

while getopts u:f:l: opt; do
  case $opt in
#Sets the username
    u)
      USER="$OPTARG"
      COMMAND="$COMMAND user $USER"
    ;;
#Sets the users First Name
    f)
      FIRSTNAME="$OPTARG"
    ;;
#Sets the users Last Name
    l)
      LASTNAME="$OPTARG"
    ;;
    \?)
      echo "Something went wrong"
      exit 1
    ;;
  esac
done
echo "$COMMAND"
if [ ! -z "$FIRSTNAME" ] && [ ! -z "$LASTNAME" ]; then
	#Creates a first name and lastname for the user
	$GAMCALL $COMMAND firstname "$FIRSTNAME" lastname "$LASTNAME"
elif [ ! -z "$LASTNAME" ]; then
	#Creates a last name for the user
	$GAMCALL $COMMAND lastname "$LASTNAME"
elif [ ! -z "$FIRSTNAME" ]; then
	#Creates a first name for the user
	$GAMCALL $COMMAND firstname "$FIRSTNAME"
fi
