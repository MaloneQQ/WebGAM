#!/bin/bash
#This adds an address to the user.
#Note: To add an address to the user we are going to use the address.sh script to update the user. The address info is so large that this will make it easier.

#  [address type <address type> unstructured <unstructered address>
#  pobox <address pobox> extendedaddress <address extended address>
#  streetaddress <address street address> locality <address locality>
#  region <address region> postalcode <address postal code>
#  countrycode <address country code>
#  primary|notprimary]
GAMCALL="python /opt/GAM/gam.py"
COMMAND="update"

while getopts u:t:p:e:s:l:r:o:c:n: opt; do
  case $opt in
      #Sets the username
    u)
      USER="$OPTARG"
      COMMAND="$COMMAND user $USER"
    ;;
    t)
      #Should be custom, home, other or work.
      TYPE="$OPTARG"
      COMMAND="$COMMAND address type $TYPE"
    ;;
      #Sets the PO for the address
    p)
      POBOX="$OPTARG"
    ;;
      #If there is an extended address use this argument
    e)
      EXTENDED_ADDR="$OPTARG"
    ;;
      #This is to add a street address
    s)
      STREET_ADDR="$OPTARG"
    ;;
     #Sets the locality.
    l).
      LOCALITY="$OPTARG"
      COMMAND="$COMMAND locality $LOCALITY"
    ;;
      #Sets the region
    r)
      REGION="$OPTARG"
      COMMAND="$COMMAND region $REGION"
    ;;
    o)
      POSTAL_CODE="$OPTARG"
      #COMMAND="$COMMAND postalcode $POSTAL_CODE"
    ;;
    c)
      COUNTRY_CODE="$OPTARG"
      #COMMAND="$COMMAND countrycode $COUNTRY_CODE"
    ;;
      #Tells gam if the address is primary or not
    n)
      PRIMARY="$OPTARG"
    ;;
    \?)
      echo "Something went wrong"
      exit 1
    ;;
  esac
done
echo "$COMMAND"
if [ ! -z "$POBOX" ] && [ ! -z "$EXTENDED_ADDR" ] && [ ! -z "$STREET_ADDR" ]; then
	#Adds PO box, extended address, street address, postalcode, and country code
	$GAMCALL $COMMAND pobox "$POBOX" extendedaddress "$EXTENDED_ADDR" streetaddress "$STREET_ADDR" postalcode $POSTAL_CODE countrycode $COUNTRY_CODE $PRIMARY
elif [ ! -z "$POBOX" ] && [ ! -z "$EXTENDED_ADDR" ]; then
	#Adds PO box and extended address
	$GAMCALL $COMMAND pobox "$POBOX" extendedaddress "$EXTENDED_ADDR" $PRIMARY
elif [ ! -z "$EXTENDED_ADDR" ] && [ ! -z "$STREET_ADDR" ]; then
	#adds extended address, postal code and country code
	$GAMCALL $COMMAND extendedaddress "$EXTENDED_ADDR" streetaddress "$STREET_ADDR" postalcode $POSTAL_CODE countrycode $COUNTRY_CODE $PRIMARY
elif [ ! -z "$EXTENDED_ADDR" ]; then
	#adds an extended address
	$GAMCALL $COMMAND extendedaddress "$EXTENDED_ADDR" $PRIMARY
elif [ ! -z "$STREET_ADDR" ]; then
	#adds street address
	$GAMCALL $COMMAND streetaddress "$STREET_ADDR" postalcode $POSTAL_CODE countrycode $COUNTRY_CODE $PRIMARY
fi
