#!/bin/bash
#This creates a user.
#Note: To add an address to the user we are going to use the address.sh script to update the user. The address info is so large that this will make it easier.
COMMAND="create"
while getopts u:f:l:p:s:c:g:a:o:d:n:v:x:m:z:t:b:y: opt; do
  case $opt in
#Sets the username
    u)
      USER="$OPTARG"
      COMMAND="$COMMAND user $USER"
    ;;
#Sets the users First Name
    f)
      FIRSTNAME="$OPTARG"
      #COMMAND="$COMMAND firstname $FIRSTNAME"
    ;;
#Sets the users Last Name
    l)
      LASTNAME="$OPTARG"
      #COMMAND="$COMMAND lastname $LASTNAME"
    ;;
#Sets the users password
    p)
      PASSWORD="$OPTARG"
      #COMMAND="$COMMAND password $PASSWORD"
    ;;
#Suspends the user. Can be on or off
    s)
      SUSPENDED="$OPTARG"
      COMMAND="$COMMAND suspended $SUSPENDED"
    ;;
#This will cause the user to change their password at next login. Can be on or off
    c)
      CHANGEPASSWORD="$OPTARG"
      COMMAND="$COMMAND changepassword $CHANGEPASSWORD"
    ;;
#Add user to global address list or not. Can be on or off
    g)
      GAL="$OPTARG"
      COMMAND="$COMMAND gal $GAL"
    ;;
#Is an admin or not. Can be on or off
     a)
      ADMIN="$OPTARG"
      COMMAND="$COMMAND admin $ADMIN"
    ;;
#Adds an organizational unit
     o)
      ORG="$OPTARG"
    ;;
#Adds a job title. If adding a title the option o must be used right before t.
     t)
      TITLE="$OPTARG"
    ;;
#This sets the org as the primary org or not. The values can be primary|notprimary.
     b)
      ORG_PRIMARY="$OPTARG"
    ;;
#organization type must be domain_only, school, unknown or work.
     y)
      ORG_TYPE="$OPTARG"
    ;;
#adds an email
#This will only work when modifying user
    ## e)
      ##EMAIL="$OPTARG"
      ##COMMAND="$COMMAND email $EMAIL"
    ##;;
#Add's a department to a user
     d)
      DEPT="$OPTARG"
    ;;
#Creates a phone type
#Must have options n,v and x to add a phone number. They have to be added in that order also
     n)
      PHONE_TYPE="$OPTARG"
      COMMAND="$COMMAND phone type $PHONE_TYPE"
    ;;
#This is the actual phone number attached to the phone type
     v)
      PHONE_NUMBER="$OPTARG"
      COMMAND="$COMMAND value $PHONE_NUMBER"
    ;;
#This sets the phone as a primary phone or not. The values can be primary|notprimary.
     x)
      PHONE_PRIMARY="$OPTARG"
      COMMAND="$COMMAND $PHONE_PRIMARY"
    ;;
#Adds a manager to the users account. Must user email address.
     m)
      MANAGER="$OPTARG"
      COMMAND="$COMMAND relation manager $MANAGER"
    ;;
#Sets a variable ALIAS to be used later.Must be any email
     z)
      ALIAS="$OPTARG"
    ;;
    \?)
      echo "Something went wrong"
      exit 1
    ;;

  esac
done
echo "$COMMAND"
if [ ! -z "$FIRSTNAME" ] && [ ! -z "$LASTNAME" ]; then
	#Creates a first name and lastname for the user
	python /opt/GAM/gam.py $COMMAND firstname "$FIRSTNAME" lastname "$LASTNAME"
elif [ ! -z "$LASTNAME" ]; then
	#Creates a last name for the user
	python /opt/GAM/gam.py $COMMAND lastname "$LASTNAME"
elif [ ! -z "$FIRSTNAME" ]; then
	#Creates a first name for the user
	python /opt/GAM/gam.py $COMMAND firstname "$FIRSTNAME"
else #if no firstname or lastname use the regular command without it.
	python /opt/GAM/gam.py $COMMAND
fi
#This finds out if the alias variable is empty and if it is not it adds an alias to the created user.
if [ ! -z "$ALIAS" ]; then
	#creates alias for the user
	python /opt/GAM/gam.py create alias "$AlIAS" user $USER
fi
if [ ! -z "$PASSWORD" ]; then
	#Creates a password for the user
	python /opt/GAM/gam.py update user $USER password "$PASSWORD"
fi
if [ ! -z "$ORG" ] && [ ! -z "$TITLE" ] && [ ! -z "$DEPT" ]; then
	#Adds an organization to the user
	python /opt/GAM/gam.py update user $USER organization name "$ORG" type $ORG_TYPE title "$TITLE" department "$DEPT" $ORG_PRIMARY
elif [ ! -z "$ORG" ] && [ ! -z "$TITLE" ]; then
	#Creates a title for the user
	python /opt/GAM/gam.py update user $USER organization name "$ORG" type $ORG_TYPE title "$TITLE" $ORG_PRIMARY
elif [ ! -z "$ORG" ] && [ ! -z "$DEPT" ]; then
	#Adds the user to a department
	python /opt/GAM/gam.py update user $USER organization name "$ORG" type $ORG_TYPE department "$DEPT" $ORG_PRIMARY
fi
