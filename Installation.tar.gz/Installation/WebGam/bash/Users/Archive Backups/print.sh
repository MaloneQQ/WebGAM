#!/bin/bash
#Displays info about all of the users
python /opt/GAM/gam.py print users allfields









