#!/bin/bash
#Takes the specified data and exports it to a csv file
python /opt/GAM/gam.py report users > user2.csv
#Moves that csv file to the data_files folder
mv /var/www/html/WebGam/bash/Users/user2.csv /var/www/html/WebGam/data_files/user2.csv

#gam print users allfields > users.csv
#Getting all users in the organization (may take some time on a large Google Apps account)...

#users.csv contains:
#--
#Email,Firstname,Lastname,Fullname,Username,OU,Suspended,SuspensionReason,ChangePassword,AgreedToTerms,DelegatedAdmin,Admin,CreationTime,LastLoginTime,Aliases,NonEditableAliases,ID,PhotoURL,IncludeInGlobalAddressList
#jsmith@acme.com,Jon,Smith,Jon Smith,jsmith,/Sales,False,,False,True,False,False,2012-03-23T15:04:19.000Z,2013-05-06T16:02:36.000Z,,jsmith@acme alias.gov,106100537778424449519,,True
#--
