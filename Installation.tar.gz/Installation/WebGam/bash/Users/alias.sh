#!/bin/bash
#This adds an alias to the user

GAMCALL="python /opt/GAM/gam.py"

while getopts u:a: opt; do
  case $opt in
#Sets the users username
    u)
      USER="$OPTARG"
    ;;
#Sets the alias name
    a)
      ALIAS="$OPTARG"
    ;;
    \?)
      echo "Something went wrong"
      exit 1
    ;;
  esac
done
	#creates alias for the user
	$GAMCALL create alias $ALIAS user $USER
