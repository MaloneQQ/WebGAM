#!/bin/bash
#This script takes in an argument and user
#Usage: Cd to bash directory, Type "./picture.sh username picturename
#Note: Picture must be png, jpeg, 

GAMCALL="python /opt/GAM/gam.py"
PhotoLoc="/var/www/html/WebGam/data_files/pictures"

if [ ! -z "$1" ] && [ ! -z "$2" ]; then #uploads the file to the user
	$GAMCALL user $1 update photo $PhotoLoc/$2
elif [ -z "$1" ] && [ -z "$2" ]; then #Reports that a username and photo name was not available
	echo "Please enter a Username and Photo name"
elif [ -z "$2" ]; then #Reports that a photo name was not available
	echo "Please enter a Photo name"
elif [ -z "$1" ]; then #Reports that a username was not available
	echo "Please enter a username"
else #Oh no something went horribly wrong.
	echo "There is an error. Please review the input."
fi
