#!/bin/bash
#This script takes in as many arguments as you need and deletes those users
#Usage: Cd to bash directory, Type "./delete.sh username username username"

GAMCALL="python /opt/GAM/gam.py"

if [ -z "$1" ]; then #gives error asking you to give a username for deletion
    echo 'You must provide a user to delete.'
else
	for i in "$@"; do #loop to delete all of the users.
		$GAMCALL delete user "$i"
done
    echo 'Users deleted. If you with to undo this option, use the undelete command.'
fi


