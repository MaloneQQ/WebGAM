#!/bin/bash

#Locations
GAMCALL="python /opt/GAM/gam.py"
MVFROM="/var/www/html/WebGam/bash/Users"
MVTO="/var/www/html/WebGam/data_files/csv"

#Takes the specified data and exports it to a csv file
$GAMCALL print users firstname lastname username emails ou organizations relations suspended changepassword agreed2terms addresses phones admin gal aliases groups >$MVTO/user.csv


#gam print users [allfields] [custom all|list,of,schemas] [userview] [ims] [emails] [externalids] [relations] [addresses] [organizations] [phones] [licenses] [firstname] [lastname] [emailparts] [deleted_only] [orderby email|firstname|lastname] [ascending|descending] [domain] [query <query>] [fullname] [ou] [suspended] [changepassword] [agreed2terms] [admin] [gal] [id] [creationtime] [lastlogintime] [aliases] [groups] [todrive]
.

#users.csv contains:
#--
#Email,Firstname,Lastname,Fullname,Username,OU,Suspended,SuspensionReason,ChangePassword,AgreedToTerms,DelegatedAdmin,Admin,CreationTime,LastLoginTime,Aliases,NonEditableAliases,ID,PhotoURL,IncludeInGlobalAddressList
#jsmith@acme.com,Jon,Smith,Jon Smith,jsmith,/Sales,False,,False,True,False,False,2012-03-23T15:04:19.000Z,2013-05-06T16:02:36.000Z,,jsmith@acme alias.gov,106100537778424449519,,True
#--
