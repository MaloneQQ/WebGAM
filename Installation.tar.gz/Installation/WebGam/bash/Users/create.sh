#!/bin/bash
#This creates a user.
GAMCALL="python /opt/GAM/gam.py"
COMMAND="create"

while getopts u:s:c:g:a:m: opt; do
  case $opt in
#Sets the username
    u)
      USER="$OPTARG"
      COMMAND="$COMMAND user $USER"
    ;;
#Suspends the user. Can be on or off
    s)
      SUSPENDED="$OPTARG"
      COMMAND="$COMMAND suspended $SUSPENDED"
    ;;
#This will cause the user to change their password at next login. Can be on or off
    c)
      CHANGEPASSWORD="$OPTARG"
      COMMAND="$COMMAND changepassword $CHANGEPASSWORD"
    ;;
#Add user to global address list or not. Can be on or off
    g)
      GAL="$OPTARG"
      COMMAND="$COMMAND gal $GAL"
    ;;
#Is an admin or not. Can be on or off
     a)
      ADMIN="$OPTARG"
      COMMAND="$COMMAND admin $ADMIN"
    ;;
#Adds a manager to the users account. Must user email address.
     m)
      MANAGER="$OPTARG"
      COMMAND="$COMMAND relation manager $MANAGER"
    ;;
    \?)
      echo "Something went wrong"
      exit 1
    ;;
  esac
done
echo "$COMMAND"
	#Calls the gam command to create a user.
	$GAMCALL $COMMAND
