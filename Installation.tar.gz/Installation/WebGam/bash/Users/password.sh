#!/bin/bash
#This is used add/update a password for a user.

GAMCALL="python /opt/GAM/gam.py"

while getopts u:p: opt; do
  case $opt in
#Sets the username
    u)
      USER="$OPTARG"
    ;;
#Sets the users password
    p)
      PASSWORD="$OPTARG"
    ;;
    \?)
      echo "Something went wrong"
      exit 1
    ;;
  esac
done
	#Updates a password for the user
	$GAMCALL update user "$USER" password "$PASSWORD"
