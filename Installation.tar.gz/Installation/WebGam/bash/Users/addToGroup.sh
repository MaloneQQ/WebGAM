#!/bin/bash
#This script will add users to a group
#Usage: Cd to bash directory, Type "./addToGroup.sh -g groupname -t member -u username"

GAMCALL="python /opt/GAM/gam.py"

while getopts g:t:u: opt; do
  case $opt in
#Sets the group
     g)
      GROUP="$OPTARG"
    ;;
#Sets the type of user being added, Mainly member or manager
     t)
      TYPE="$OPTARG"
    ;;
#Sets the username to be added
     u)
       USER="$OPTARG"
    ;;

    \?)
      echo "Something went wrong"
      exit 1
    ;;
esac
done
	#Calls the correct gam commands to add a user to a group
	$GAMCALL update group "$GROUP" add "$TYPE" "$USER" 


