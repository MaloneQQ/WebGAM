#!/bin/bash
#This updates the organization information including title and department.

GAMCALL="python /opt/GAM/gam.py"

while getopts u:o:t:p:y:d: opt; do
  case $opt in
#Sets the user
     u)
      USER="$OPTARG"
    ;;
#Adds an organizational unit
     o)
      ORG="$OPTARG"
    ;;
#Adds a job title. If adding a title the option o must be used right before t.
     t)
      TITLE="$OPTARG"
    ;;
#This sets the org as the primary org or not. The values can be primary|notprimary.
     p)
      ORG_PRIMARY="$OPTARG"
    ;;
#organization type must be domain_only, school, unknown or work.
     y)
      ORG_TYPE="$OPTARG"
    ;;
#Add's a department to a user
     d)
      DEPT="$OPTARG"
    ;;
    \?)
      echo "Something went wrong"
      exit 1
    ;;
  esac
done
if [ ! -z "$ORG" ] && [ ! -z "$TITLE" ] && [ ! -z "$DEPT" ]; then
	#Adds an organization to the user
	$GAMCALL update user "$USER" organization name "$ORG" type $ORG_TYPE title "$TITLE" department "$DEPT" $ORG_PRIMARY
elif [ ! -z "$ORG" ] && [ ! -z "$TITLE" ]; then
	#Creates a title for the user
	$GAMCALL update user "$USER" organization name "$ORG" type $ORG_TYPE title "$TITLE" $ORG_PRIMARY
elif [ ! -z "$ORG" ] && [ ! -z "$DEPT" ]; then
	#Adds the user to a department
	$GAMCALL update user "$USER" organization name "$ORG" type $ORG_TYPE department "$DEPT" $ORG_PRIMARY
else
	echo "something isnt working"
fi
