#!/bin/bash
#This script takes in an argument and user
#Usage: Cd to bash directory, Type "./picture.sh username 

GAMCALL="python /opt/GAM/gam.py"

if [ ! -z "$1" ]; then #Deletes the users pictures.
	$GAMCALL user $1 delete photo
elif [ -z "$1" ]; then #Reports that a username and photo name was not available
	echo "Please enter a Username"
else #Oh no something went horribly wrong.
	echo "There is an error. Please review the input."
fi
