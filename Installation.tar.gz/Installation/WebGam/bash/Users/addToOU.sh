#!/bin/bash
#This script takes in as many arguments and an option. The option is what ou the users are added too
#The arguments are all of the users that are added to that OU
#Usage: Cd to bash directory, Type "./addToOU.sh -o OUname -u Username"

GAMCALL="python /opt/GAM/gam.py"

while getopts o:u: opt; do
  case $opt in
#Sets the OU
     o)
      OU="$OPTARG"
    ;;
#Sets the user to be added to the ou
     u)
       USER="$OPTARG"
    ;;

    \?)
      echo "Something went wrong"
      exit 1
    ;;
esac
done
	#Calls the gam command to add a user to an ou
	$GAMCALL update user "$USER" org "$OU"


