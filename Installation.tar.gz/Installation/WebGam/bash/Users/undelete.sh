#!/bin/bash
#This will undelete a user that has been previously deleted.
#If the argument is blank then display an error

GAMCALL="python /opt/GAM/gam.py"

if [ "$1" = "" ]; then
    echo 'You must provide a user to delete.'
else
#Undelete the user that is defined by the argument
    $GAMCALL undelete user $1
    echo 'User ' $1 ' undeleted.'
fi


