#!/bin/bash
#This resets networking
sudo ifdown --exclude=lo -a && sudo ifup --exclude=lo -a
