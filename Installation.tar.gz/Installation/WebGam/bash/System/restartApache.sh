#!/bin/bash
#This gracefully restarts apache. There is no noticable downtime associated with this.
sudo /etc/init.d/apache2 graceful
