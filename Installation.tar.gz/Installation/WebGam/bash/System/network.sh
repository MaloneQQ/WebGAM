#!/bin/bash
#auto lo eth0
#iface lo inet loopback
#iface eth0 inet static
#        address xxx.xxx.xxx.xxx(enter your ip here)
#        netmask xxx.xxx.xxx.xxx
#        gateway xxx.xxx.xxx.xxx(enter gateway ip here,usually #the address of the router)
#	 dns-nameservers x.x.x.x

#Check for dhcp or not needs added to make this complete.
while getopts a:n:g: opt; do
  case $opt in
#Sets the ip address
    a)
      ADDRESS="$OPTARG"
    ;;
#Sets the netmask
    n)
      NETMASK="$OPTARG"
    ;;
#Sets the gateway
    g)
      GATEWAY="$OPTARG"
    ;;
    \?)
      echo "Something went wrong"
      exit 1
    ;;
  esac
done
if [ ! -z "$ADDRESS" ]; then
	#Updates the IP address
	sudo sed -i "s/address.*/address $ADDRESS/g" /etc/network/interfaces
fi
if [ ! -z "$NETMASK" ]; then
	#Updates the Netmask
	sudo sed -i "s/netmask.*/netmask $NETMASK/g" /etc/network/interfaces
fi
if [ ! -z "$GATEWAY" ]; then
	#Updates the Gateway
	sudo sed -i "s/gateway.*/gateway $GATEWAY/g" /etc/network/interfaces
fi
