#!/bin/bash
#This script takes in as many arguments as you need and adds those nameservers

# File will have the following line that will need changed
#	 dns-nameservers x.x.x.x

#Usage: Cd to bash directory, Type "./nameserver.sh x.x.x.x x.x.x.x x.x.x.x" include spaces in between the server address

NAMESERVERS="dns-nameservers"
INTLOC="/etc/network/interfaces"

if [ -z "$1" ]; then #gives error asking you to give a nameserver for deletion
	echo 'You must provide a nameserver to add.'
else
	for i in "$@"; do #loop to add all nameservers.
		NAMESERVERS="$NAMESERVERS $i"
done
	sudo sed -i "s/dns-nameservers.*/$NAMESERVERS/g" $INTLOC
	echo 'Nameservers added'
fi



