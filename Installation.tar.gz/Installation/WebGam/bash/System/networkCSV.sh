#!/bin/bash
#Locations of where stuff is located
INTERFACE="/home/group/Desktop/interfaces"
MVFROM="/var/www/html/WebGam/bash/System"
MVTO="/var/www/html/WebGam/data_files/csv"

#stores the address, netmask, gateway, and dns-names in seperate csv files
sed -n '/address/p' $INTERFACE >$MVTO/address.csv
sed -n '/netmask/p' $INTERFACE >$MVTO/netmask.csv
sed -n '/gateway/p' $INTERFACE >$MVTO/gateway.csv
sed -n '/dns-names/p' $INTERFACE >$MVTO/dns-names.csv


#Moves that csv file to the data_files folder
#mv $MVFROM/address.csv $MVTO/address.csv
#mv $MVFROM/netmask.csv $MVTO/netmask.csv
#mv $MVFROM/gateway.csv $MVTO/gateway.csv
#mv $MVFROM/dns-names.csv $MVTO/dns-names.csv
