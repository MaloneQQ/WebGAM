<?php 
    $folder = "security";
    include "../view/includes/header_include.php"; 
?>

<div class="form">
    <script type="text/javascript" src="attributes.js"></script>
    <br /><h1 class="text_center">Security Control Panel</h1><br />