CREATE TABLE functions ( FunctionID INT NOT NULL AUTO_INCREMENT,
                         Name VARCHAR(64) NOT NULL,
                         Description TEXT,	 
                         PRIMARY KEY (FunctionID) );


CREATE TABLE roles ( RoleID INT NOT NULL AUTO_INCREMENT,
                     Name VARCHAR(32) NOT NULL,
                     Description TEXT,
                     PRIMARY KEY (RoleID) );


CREATE TABLE users ( UserID INT NOT NULL AUTO_INCREMENT,
                     FirstName VARCHAR(32) NOT NULL,
                     LastName VARCHAR(32) NOT NULL,
                     UserName VARCHAR(32) NOT NULL,
                     Password VARCHAR(40) NOT NULL,
                     Email VARCHAR(32) NOT NULL,
                     PRIMARY KEY (UserID) );

CREATE TABLE rolefunctions ( RoleID INT NOT NULL,
                             FunctionID INT NOT NULL,
                             FOREIGN KEY (RoleID) REFERENCES roles(RoleID) ON DELETE CASCADE,
                             FOREIGN KEY (FunctionID) REFERENCES functions(FunctionID) ON DELETE CASCADE );

CREATE TABLE userroles ( UserID INT NOT NULL,
                         RoleID INT NOT NULL,
                         FOREIGN KEY (UserID) REFERENCES users(UserID) ON DELETE CASCADE,
                         FOREIGN KEY (RoleID) REFERENCES roles(RoleID) ON DELETE CASCADE);
						 
INSERT INTO functions (Name, Description) VALUES ('SecurityManageUsers', 'Allows for reading users and interface to add, change, and delete.');
INSERT INTO functions (Name, Description) VALUES ('SecurityUserAdd', 'Allows for adding of users by enabling link on manage form.');
INSERT INTO functions (Name, Description) VALUES ('SecurityUserEdit', 'Allows for editing of users by enabling link on manage form.');
INSERT INTO functions (Name, Description) VALUES ('SecurityUserDelete', 'Allows for deleting of users by enabling checkbox on manage form.');
INSERT INTO functions (Name, Description) VALUES ('SecurityProcessUserAddEdit', 'Required to process an add, change, or delete of users.');
INSERT INTO functions (Name, Description) VALUES ('SecurityManageFunctions', 'Allows for reading functions and interface to add, change, and delete.');
INSERT INTO functions (Name, Description) VALUES ('SecurityFunctionAdd', 'Allows for adding of functions by enabling link on manage form.');
INSERT INTO functions (Name, Description) VALUES ('SecurityFunctionEdit', 'Allows for editing of functions by enabling link on manage form.');
INSERT INTO functions (Name, Description) VALUES ('SecurityFunctionDelete', 'Allows for deleting of functions by enabling checkbox on manage form.');
INSERT INTO functions (Name, Description) VALUES ('SecurityProcessFunctionAddEdit', 'Required to process an add, change, or delete of functions.');
INSERT INTO functions (Name, Description) VALUES ('SecurityManageRoles', 'Allows for reading roles and interface to add, change, and delete.');
INSERT INTO functions (Name, Description) VALUES ('SecurityRoleAdd', 'Allows for adding of roles by enabling link on manage form.');
INSERT INTO functions (Name, Description) VALUES ('SecurityRoleEdit', 'Allows for editing of roles by enabling link on manage form.');
INSERT INTO functions (Name, Description) VALUES ('SecurityRoleDelete', 'Allows for deleting of roles by enabling checkbox on manage form.');
INSERT INTO functions (Name, Description) VALUES ('SecurityProcessRoleAddEdit', 'Required to process an add, change, or delete of roles.');
INSERT INTO functions (Name, Description) VALUES ('SecurityLogin', 'Provide Username and Password');
INSERT INTO functions (Name, Description) VALUES ('SecurityLogOut', 'Exit the application.');
INSERT INTO functions (Name, Description) VALUES ('SecurityProcessLogin', 'Try to authorize a user login.');
INSERT INTO functions (Name, Description) VALUES ('SecurityHome', 'Default security page with login button.');
INSERT INTO functions (Name, Description) VALUES ('main', 'View the main page of WebGAM.');
INSERT INTO functions (Name, Description) VALUES ('users', 'View the main page for users.');
INSERT INTO functions (Name, Description) VALUES ('add_user', 'Go to the add user form.');
INSERT INTO functions (Name, Description) VALUES ('process_add_user', 'Submit the add user form.');
INSERT INTO functions (Name, Description) VALUES ('update_edit_user_form', 'Switch the user to edit.');
INSERT INTO functions (Name, Description) VALUES ('edit_user', 'Edit a users information.');
INSERT INTO functions (Name, Description) VALUES ('process_edit_user', 'Submit the edit user form.');
INSERT INTO functions (Name, Description) VALUES ('remove_user', 'Remove a user.');
INSERT INTO functions (Name, Description) VALUES ('process_remove_user', 'Perform the removal of a user.');
INSERT INTO functions (Name, Description) VALUES ('view_user', 'View a users information.');
INSERT INTO functions (Name, Description) VALUES ('groups', 'View the main page for groups');
INSERT INTO functions (Name, Description) VALUES ('add_group', 'Go to the add group form.');
INSERT INTO functions (Name, Description) VALUES ('process_add_group', 'Submit the add group form.');
INSERT INTO functions (Name, Description) VALUES ('update_edit_group_form', 'Edit a different group.');
INSERT INTO functions (Name, Description) VALUES ('edit_group', 'Edit a groups information.');
INSERT INTO functions (Name, Description) VALUES ('process_edit_group', 'Submit the edit group form.');
INSERT INTO functions (Name, Description) VALUES ('remove_group', 'Go to the remove group form.');
INSERT INTO functions (Name, Description) VALUES ('process_remove_group', 'Remove a group.');
INSERT INTO functions (Name, Description) VALUES ('view_group', 'View a groups information.');
INSERT INTO functions (Name, Description) VALUES ('ous', 'View the main page for ous.');
INSERT INTO functions (Name, Description) VALUES ('add_ou', 'View the add ou form.');
INSERT INTO functions (Name, Description) VALUES ('process_add_ou', 'Submit the add ou form.');
INSERT INTO functions (Name, Description) VALUES ('update_edit_ou_form', 'Go to a different ou to edit.');
INSERT INTO functions (Name, Description) VALUES ('edit_ou', 'View the edit ou form.');
INSERT INTO functions (Name, Description) VALUES ('process_edit_ou', 'Submit the edit ou form.');
INSERT INTO functions (Name, Description) VALUES ('remove_ou', 'View the remove ou form.');
INSERT INTO functions (Name, Description) VALUES ('process_remove_ou', 'Submit the remove ou form.');
INSERT INTO functions (Name, Description) VALUES ('view_ou', 'View an ou''s information.');
INSERT INTO functions (Name, Description) VALUES ('contacts', 'View the main page for contacts.');
INSERT INTO functions (Name, Description) VALUES ('system', 'View the main page for system settings.');
INSERT INTO functions (Name, Description) VALUES ('networking', 'View the network form.');
INSERT INTO functions (Name, Description) VALUES ('systems', 'View the system settings form.');
INSERT INTO functions (Name, Description) VALUES ('restart_server', 'Restart the server.');
INSERT INTO functions (Name, Description) VALUES ('restart_apache', 'Restart apache.');
INSERT INTO functions (Name, Description) VALUES ('process_networking', 'Submit the networking form.');

INSERT INTO roles (Name,Description) VALUES ('admin','Full privileges in WebGAM, but security restricted.');
INSERT INTO roles (Name,Description) VALUES ('developer','Full privileges in order to develop.');
INSERT INTO roles (Name,Description) VALUES ('guest','Features available to all visitors without logging in.');

INSERT INTO users (FirstName,LastName,UserName,Password,Email) VALUES ('WebGAM','Admin','admin',SHA1('admin'),'');
INSERT INTO users (FirstName,LastName,UserName,Password,Email) VALUES ('WebGAM','Developer','developer',SHA1('developer'),'');

INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 31);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 40);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 22);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 48);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 34);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 43);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 25);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 30);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 20);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 50);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 39);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 32);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 41);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 23);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 35);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 44);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 26);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 54);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 37);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 46);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 28);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 36);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 45);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 27);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 53);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 52);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 6);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 11);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 1);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 5);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 2);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 4);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 3);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 49);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 51);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 33);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 42);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 24);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 21);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 38);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 47);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 29);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 19);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 16);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 17);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (1, 18);
			
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 31);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 40);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 22);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 48);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 34);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 43);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 25);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 30);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 20);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 50);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 39);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 32);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 41);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 23);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 35);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 44);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 26);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 54);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 37);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 46);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 28);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 36);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 45);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 27);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 53);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 52);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 7);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 9);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 8);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 6);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 11);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 1);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 10);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 15);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 5);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 12);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 14);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 13);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 2);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 4);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 3);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 49);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 51);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 33);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 42);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 24);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 21);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 38);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 47);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 29);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 19);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 16);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 17);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (2, 18);

INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (3,11);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (3,16);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (3,17);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (3,18);
INSERT INTO rolefunctions (RoleID,FunctionID) VALUES (3,19);

INSERT INTO userroles (UserID,RoleID) VALUES (1,1);
INSERT INTO userroles (UserID,RoleID) VALUES (2,2);