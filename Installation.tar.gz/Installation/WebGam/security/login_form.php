<?php
	$title = "Login";
	require '../security/headerInclude.php';
?>
    <br /><h4>Login</h4><br />

    <form action="../security/index.php?action=SecurityProcessLogin" method="post">

        <label class="form_left">Username</label><input type="text" class="form_input" name="username" /><br/>
        <label class="form_left">Password</label><input type="password" class="form_input" name="password" /><br/><br/>
        <input type="hidden" name="RequestedPage" value="<?php echo $_GET['RequestedPage'] ?>" />

        <input type="submit" class="submit_button" value="Submit"/>

        <?php
            if (isset($_GET['LoginFailure'])) {
                echo '<p/><h4> Invalid Username or Password.  Please try again.</h4>';
            }
        ?>

    </form>

<?php
	require '../security/footerInclude.php';
?>