<?php
	$title = "Control Panel ";
	require '../security/headerInclude.php';

	require '../security/footerInclude.php';
?>

<div class="security_form">
    This is the security control panel.<br /><br /> To add or edit local WebGAM users, 
    select the 'Users' option in the tool bar.<br /><br /> To add or edit security functions,
    for instance, controller actions that users will be authorized to perform, 
    select the 'Functions' option in the tool bar.<br /><br /> To add or edit user roles, 
    including adding authorized functions to types of users, select the 'Roles' 
    option in the tool bar.
</div>

