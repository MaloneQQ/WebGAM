#!/bin/bash
#This is the installation file. It determines what OS is being run and installs GAM along with WebGam
#At the moment this script will only run on a Ubuntu 14.04LTS or higher machine.
	GAMDirectory="/opt/GAM"
	WebGamDir="/var/www/html/WebGam"
	INSTDIR=$(pwd)
	#Gets the Distro info
	DistInfo=$(cat /etc/issue)
	Distro=$(echo $DistInfo | awk '{ print $1 }')
	if [ "$Distro" = "Ubuntu" ]; then #if the server is ubuntu continue with the installation
###############Installing required software######################################
		#Update Ubuntu and repositories with cleanup
		apt-get update -y
		#apt-get upgrade -y
		#apt-get autoremove -y
		#Stores directory where apache2 is installed in variable
		APACHEINST=$(which apache2ctl)
		#If there is a directory where apache2 is installed
		if [ -z "$APACHEINST" ]; then
			apt-get install apache2 -y
		else #Install apache2
			echo "Apache2 is already installed"
		fi
		#Stores directory where php is installed in variable
		PHPINST=$(which php)
		#If there is a directory where php is installed
		if [ -z "$PHPINST" ]; then
			apt-get install php5 libapache2-mod-php5 php5-mcrypt -y
		else #Install php
			echo "PHP is already installed"
		fi
		#Stores directory where python2.7 is installed in variable
		PYTHONINST=$(which python2.7)
		#If there is a directory where python is installed
		if [ -z "$PYTHONINST" ]; then
			apt-get install python2.7 -y
		else #Install python2.7
			echo "Python 2.7 is already installed"
		fi
		#Stores directory where wget is installed in variable
		WGETINST=$(which wget)
		#If there is a directory where wget is installed
		if [ -z "$WGETINST" ]; then
			apt-get install wget -y
		else #Install wget
			echo "WGET is already installed"
		fi
		#Stores directory where unzip is installed in variable
		UNZIPINST=$(which unzip)
		#If there is a directory where unzip is installed
		if [ -z "$UNZIPINST" ]; then 
			apt-get install unzip -y
		else 
			echo "UNZIP is already installed"
		fi

#######################Install MySQL############################################
		#Stores directory where MySQL is installed in variable
		MYSQLINST=$(which mysql)
		#If there is a directory where unzip is installed
		if [ -z "$MYSQLINST" ]; then 
			WebGAMdb=WebGAM
			MySQLpass=W3bG@m
			MySQLuser=root
			echo mysql-server mysql-server/root_password password W3bG@m | sudo debconf-set-selections
			echo mysql-server mysql-server/root_password_again password W3bG@m | sudo debconf-set-selections
			sudo apt-get install mysql-server -y
			mysql -uroot -p$MySQLpass -e "create database $WebGAMdb"
			sudo apt-get install python-mysqldb -y
			sudo apt-get install php5-mysql -y
			cd prereqs
			python MysqlTableCreate.py localhost $MySQLuser $MySQLpass $WebGAMdb 
		else 
			echo "MySQL is already installed"
		fi

################################################################################

		#Restart required services
		#Stops apache service if it is running
		service apache2 stop
		#Starts the apache service
		service apache2 start
########################Move WebGam Folder to correct place#####################
		

		if [ -f "/var/www/html/WebGam_BAK.tar.gz" ]; then
			#Deletes old archive of webgam
			cd /var/www/html
			rm -R WebGam_BAK.tar.gz
		fi

		if [ -d "$WebGamDir/" ]; then
			#creates a copy of old GAM and WebGam
			cd /var/www/html
			#Compresses the old WebGam
			tar czf /var/www/html/WebGam_BAK.tar.gz WebGam/
			#Removes the old WebGam
			rm -R WebGam/
		fi
		if [ -f "/var/www/html/index.html" ]; then
			rm /var/www/html/index.html
		fi
		#Moves the redirect html file over to the html folder
		cp $INSTDIR/Redirect/index.html /var/www/html/index.html
		cp -R $INSTDIR/WebGam/ $WebGamDir/
######################Prepare old GAM for reinstallation#######################
		cd /opt
		if [ ! -d "/opt/backup/" ]; then
  			mkdir /opt/backup/
		#else 
		#	rm -R /opt/backup/
		fi
		#Should not need the following statements anymore
		#if [ -f "/opt/backup/GAM_BAK.tar.gz" ]; then
		#	rm /opt/backup/GAM_BAK.tar.gz
		#fi
		if [ -d "$GAMDirectory/" ]; then
			if [ -f "/opt/GAM/oauth2.txt" ]; then
				cp /opt/GAM/oauth2.txt /opt/backup/oauth2.txt
			fi
			tar czf /opt/backup/GAM_BAK.tar.gz GAM/
			rm -R $GAMDirectory/
		fi
############DOWNLOAD a version of GAM and move to folder######################
		#Changes the directory to the tmp folder, deletes any previously downloaded files and then downloads the newest GAM
		cd /tmp	
		if [ -f "master.zip" ]; then
			rm master.zip
		fi
		if [ -f "v3.61.zip" ]; then
			rm v3.61.zip
		fi
		if [ -f "v3.51.zip" ]; then
			rm v3.51.zip
		fi
		if [ -f "v3.45.zip" ]; then	
			rm v3.45.zip
		fi

#########Select which version of Gam the user wants to install###############
		for (( x=1; x<2; x++ ))
		do
		echo -n "Select the version of GAM to use: (1)3.61 (2)3.51 (3)3.45 (4)Latest: "
		read Gacpersion
		if echo "$Gacpersion" | grep -iq "^1" ;then
			echo 1	
			wget -nc https://github.com/jay0lee/GAM/archive/v3.61.zip
			#Unzips GAM
			unzip -o v3.61.zip
			cp -r /tmp/GAM-3.61 $GAMDirectory/
		elif echo "$Gacpersion" | grep -iq "^2" ;then
			echo 2
			wget -nc https://github.com/jay0lee/GAM/archive/v3.51.zip
			unzip -o v3.51.zip
			cp -r /tmp/GAM-3.51 $GAMDirectory/
		elif echo "$Gacpersion" | grep -iq "^3" ;then
			echo 3
			wget -nc https://github.com/jay0lee/GAM/archive/v3.45.zip
			unzip -o v3.45.zip
			cp -r /tmp/GAM-3.45 $GAMDirectory/
		elif echo "$Gacpersion" | grep -iq "^4" ;then
			echo 4
			wget -nc https://github.com/jay0lee/GAM/archive/master.zip
			#Unzips GAM
			unzip -o master.zip
			#Moves the source to the opt folder
			cp -r /tmp/GAM-master/src/ $GAMDirectory/
		else
			echo Please select which gam you would like to install
			x=($x-1)
		fi
		done
######################Restore old needed GAM files##########################
		if [ -d "/opt/backup" ]; then
			if [ -f "/opt/backup/oauth2.txt" ]; then
				cp /opt/backup/oauth2.txt $GAMDirectory/oauth2.txt
			fi
		fi

#Moves the nobrowser file to the gam folder so there is no gui needed for gam#
		cp $INSTDIR/GAMFiles/nobrowser.txt $GAMDirectory/nobrowser.txt
		cp $INSTDIR/GAMFiles/noupdatecheck.txt $GAMDirectory/noupdatecheck.txt
		
###############################Change Permissions###########################
		chmod -R 500 $WebGamDir
		chmod -R 700 $WebGamDir/bash
		chmod +x $WebGamDir/bash/Users/*.sh
		chmod +x $WebGamDir/bash/Groups/*.sh
		chmod +x $WebGamDir/bash/OU/*.sh
		chmod +x $WebGamDir/bash/System/*.sh
		chmod -R 700 $WebGamDir/data_files
		chown -R www-data:www-data $WebGamDir
		chmod -R 766 $GAMDirectory
		chmod +x $GAMDirectory/*.py
		chown -R www-data:www-data $GAMDirectory
####################WEBGAM is now installed!!!!#############################
		echo "You now have WebGam installed. Please navigate to the following webpage in order to setup your Oath file. https://github.com/jay0lee/GAM/wiki/CreatingClientSecretsFile"
	
	else
			echo "You are using an unsupported version of Linux."
	fi #End if else statement
