#!/bin/bash
WebGamDir=/var/www/html/WebGam
GamDir=/opt/GAM
#chmod -R 500 $WebGamDir
#chmod -R 700 $WebGamDir/bash
#chmod -R +x $WebGamDir/bash
#chmod -R 700 $WebGamDir/data_files
#chown -R www-data:www-data $WebGamDir
#chmod -R 700 $GamDir
#chmod -R +x $GamDir
#chown -R www-data:www-data $GamDir

chmod -R 500 $WebGamDir
chmod -R 700 $WebGamDir/bash
chmod +x $WebGamDir/bash/Users/*.sh
chmod +x $WebGamDir/bash/Groups/*.sh
chmod +x $WebGamDir/bash/OU/*.sh
chmod +x $WebGamDir/bash/System/*.sh
chmod -R 700 $WebGamDir/data_files
chown -R www-data:www-data $WebGamDir
chmod -R 700 $GamDir
chmod +x $GamDir/*.py
chown -R www-data:www-data $GamDir
