#!/bin/bash
WebGAMdb=WebGAM
MySQLpass=W3bG@m
MySQLuser=root

mysql -uroot -p$MySQLpass -e "drop database $WebGAMdb"
mysql -uroot -p$MySQLpass -e "create database $WebGAMdb"
cd ../prereqs
python MysqlTableCreate.py localhost $MySQLuser $MySQLpass $WebGAMdb 
